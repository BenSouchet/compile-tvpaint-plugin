

#include "plugdllx.h"
#include "demowindow.h"
#include "demo.h"



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Popup Subwindow


#define THE_BUTTON_X   450
#define THE_BUTTON_Y   140


#define START  4000


#define ID_TOP_LABEL         (START+001)
#define ID_THE_BUTTON_LABEL  (START+002)

#define OID_ON           0
#define OID_ID           1
#define OID_NAME         2
#define OID_SEPARATOR    3
#define OID_QUIET        5
#define OID_CHECK        6
#define OID_GHOST        7
#define OID_MULTI        8

#define ID_THE_BUTTON        (START+999)


static struct
{
    int   mOn;
    int   mID;
    char  mName[256];
    int   mSeparator;
    int   mQuiet;
    int   mCheck;
    int   mGhost;
    int   mMulti;
} sgToggles[10];



static void
DoPopup( PIFilter* iFilter, DWORD iReq )
{
	char  tmp[256];
	int  i;
	int  cnt = 0;
	PIPopup  pop[11];

	for( i = 0; i < 10; ++i )
	{
		int  f = 0;
		if( !sgToggles[i].mOn )
			continue;

		if( sgToggles[i].mSeparator )  f |= PIPOPMODE_SEPARATOR;
		if( sgToggles[i].mQuiet )      f |= PIPOPMODE_QUIET;
		if( sgToggles[i].mCheck )      f |= PIPOPMODE_CHECK;
		if( sgToggles[i].mGhost )      f |= PIPOPMODE_GHOST;
		if( sgToggles[i].mMulti )      f |= PIPOPMODE_MULTI;

		pop[cnt].Name  = sgToggles[i].mName;
		pop[cnt].ID    = sgToggles[i].mID;
		pop[cnt].Flags = f;

		cnt++;
	}

	i = TVPopup( iFilter, pop, cnt, 0 );
	sprintf( tmp, "POPUP SELECTION : %d", i );
	
	DemoDrawString( iFilter, iReq, ID_MESSAGES, tmp );
}


static void
AddLine( PIFilter* iFilter, DWORD iReq, int iIdx, int iY, int iStartID )
{
    char  tmp[256];

    TVAddButtonReq( iFilter, iReq,   9, iY,   0, 0, iStartID+OID_ON,        PIRBF_BUTTON_CHECK | (sgToggles[iIdx].mOn        ? PIRBF_BUTTON_SELECT : 0), NULL );
	TVSetButtonInfoText( iFilter, iReq, iStartID+OID_ON,        "Enable/disable this line" );
    sprintf( tmp, "%d", sgToggles[iIdx].mID );
    TVAddButtonReq( iFilter, iReq,  34, iY,  20, 0, iStartID+OID_ID,        PIRBF_BUTTON_TEXT_INT,                                                       tmp );
	TVSetButtonInfoText( iFilter, iReq, iStartID+OID_ID,        "'ID' field" );
    TVAddButtonReq( iFilter, iReq,  60, iY, 135, 0, iStartID+OID_NAME,      PIRBF_BUTTON_TEXT,                                         sgToggles[iIdx].mName );
	TVSetButtonInfoText( iFilter, iReq, iStartID+OID_NAME,      "'Name' field" );

    TVAddButtonReq( iFilter, iReq, 200, iY,  21, 0, iStartID+OID_SEPARATOR, PIRBF_BUTTON_STAT  | (sgToggles[iIdx].mSeparator ? PIRBF_BUTTON_SELECT : 0), "S"  );
	TVSetButtonInfoText( iFilter, iReq, iStartID+OID_SEPARATOR, "'Flags' field : PIPOPMODE_SEPARATOR" );
	TVAddButtonReq( iFilter, iReq, 225, iY,  21, 0, iStartID+OID_QUIET,     PIRBF_BUTTON_STAT  | (sgToggles[iIdx].mQuiet     ? PIRBF_BUTTON_SELECT : 0), "Q"  );
	TVSetButtonInfoText( iFilter, iReq, iStartID+OID_QUIET,     "'Flags' field : PIPOPMODE_QUIET" );
    TVAddButtonReq( iFilter, iReq, 250, iY,  21, 0, iStartID+OID_CHECK,     PIRBF_BUTTON_STAT  | (sgToggles[iIdx].mCheck     ? PIRBF_BUTTON_SELECT : 0), "C"  );
	TVSetButtonInfoText( iFilter, iReq, iStartID+OID_CHECK,     "'Flags' field : PIPOPMODE_CHECK" );
    TVAddButtonReq( iFilter, iReq, 275, iY,  21, 0, iStartID+OID_GHOST,     PIRBF_BUTTON_STAT  | (sgToggles[iIdx].mGhost     ? PIRBF_BUTTON_SELECT : 0), "G"  );
	TVSetButtonInfoText( iFilter, iReq, iStartID+OID_GHOST,     "'Flags' field : PIPOPMODE_GHOST" );
    TVAddButtonReq( iFilter, iReq, 300, iY,  21, 0, iStartID+OID_MULTI,     PIRBF_BUTTON_STAT  | (sgToggles[iIdx].mMulti     ? PIRBF_BUTTON_SELECT : 0), "M"  );
	TVSetButtonInfoText( iFilter, iReq, iStartID+OID_MULTI,     "'Flags' field : PIPOPMODE_MULTI" );
}


static void
RemoveLine( PIFilter* iFilter, DWORD iReq, int iStartID )
{
    TVRemoveButtonReq( iFilter, iReq, iStartID+OID_ON );
    TVRemoveButtonReq( iFilter, iReq, iStartID+OID_ID );
    TVRemoveButtonReq( iFilter, iReq, iStartID+OID_NAME );
    TVRemoveButtonReq( iFilter, iReq, iStartID+OID_SEPARATOR );
    TVRemoveButtonReq( iFilter, iReq, iStartID+OID_QUIET );
    TVRemoveButtonReq( iFilter, iReq, iStartID+OID_CHECK );
    TVRemoveButtonReq( iFilter, iReq, iStartID+OID_GHOST );
    TVRemoveButtonReq( iFilter, iReq, iStartID+OID_MULTI );
}


static void
Open( PIFilter* iFilter, DWORD iReq )
{
    int  y = gStartSubWindowY;

    static int first = 1;
    if( first )
    {
        int  i;
        first = 0;

        for( i = 0; i < 10; ++i )
        {
            sprintf( sgToggles[i].mName, "Item %2d", i+1 );
            sgToggles[i].mOn = 1;
            sgToggles[i].mID = i+1;
            sgToggles[i].mSeparator = 0;
            sgToggles[i].mQuiet = 0;
            sgToggles[i].mCheck = 0;
            sgToggles[i].mGhost = 0;
            sgToggles[i].mMulti = 0;
        }
    }

    TVAddButtonReq( iFilter, iReq, 0, y, 240, 20, ID_TOP_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "PIPOPMODE_*" ); y += 20;

    AddLine( iFilter, iReq, 0, y, START+100 );  y += 20;
    AddLine( iFilter, iReq, 1, y, START+110 );  y += 20;
    AddLine( iFilter, iReq, 2, y, START+120 );  y += 20;
    AddLine( iFilter, iReq, 3, y, START+130 );  y += 20;
    AddLine( iFilter, iReq, 4, y, START+140 );  y += 20;
    AddLine( iFilter, iReq, 5, y, START+150 );  y += 20;
    AddLine( iFilter, iReq, 6, y, START+160 );  y += 20;
    AddLine( iFilter, iReq, 7, y, START+170 );  y += 20;
    AddLine( iFilter, iReq, 8, y, START+180 );  y += 20;
    AddLine( iFilter, iReq, 9, y, START+190 );  y += 20;


    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y-30, 150, 20, ID_THE_BUTTON_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "What you get ..." ); y += 20;
    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y, 150, 0, ID_THE_BUTTON, PIRBF_BUTTON_POPUP, "Ga Bu Zo Meu" );
}


static void
Close( PIFilter* iFilter, DWORD iReq )
{
    TVRemoveButtonReq( iFilter, iReq, ID_TOP_LABEL );

    RemoveLine( iFilter, iReq, START+100 );
    RemoveLine( iFilter, iReq, START+110 );
    RemoveLine( iFilter, iReq, START+120 );
    RemoveLine( iFilter, iReq, START+130 );
    RemoveLine( iFilter, iReq, START+140 );
    RemoveLine( iFilter, iReq, START+150 );
    RemoveLine( iFilter, iReq, START+160 );
    RemoveLine( iFilter, iReq, START+170 );
    RemoveLine( iFilter, iReq, START+180 );
    RemoveLine( iFilter, iReq, START+190 );

    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON_LABEL );
    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );
}


static int
Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    switch( iEvent )
    {
	    case PICBREQ_BUTTON_UP:
        {
			if( iArgs[0] >= 4100  &&  iArgs[0] <= 4199 )
			{
				int  row = (((int)iArgs[0])%100)/10;
				int  col = ((int)iArgs[0])%10;

				switch( col )
				{
				case OID_ON:
				{
					sgToggles[row].mOn = !sgToggles[row].mOn;
					TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|(sgToggles[row].mOn ? PIRBF_BUTTON_SELECT : 0), NULL );
					return  1;
				}
				case OID_ID:
				{
					char  tmp[256];
					int  i;
					TVGetButtonString( iFilter, iReq, iArgs[0], tmp, 255 );
					sscanf( tmp, "%d", &i );
					if( i > 0 )
					{
						sgToggles[row].mID = i;
					}
					else
					{
						sprintf( tmp, "%d", sgToggles[row].mID );
						TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_TEXT_INT, tmp );
					}
					return  1;
				}
				case OID_NAME:
				{
					TVGetButtonString( iFilter, iReq, iArgs[0], sgToggles[row].mName, 255 );
					return  1;
				}
				case OID_SEPARATOR:
				{
					sgToggles[row].mSeparator = !sgToggles[row].mSeparator;
					TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|(sgToggles[row].mSeparator ? PIRBF_BUTTON_SELECT : 0), NULL );
					return  1;
				}
				case OID_QUIET:
				{
					sgToggles[row].mQuiet = !sgToggles[row].mQuiet;
					TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|(sgToggles[row].mQuiet ? PIRBF_BUTTON_SELECT : 0), NULL );
					return  1;
				}
				case OID_CHECK:
				{
					sgToggles[row].mCheck = !sgToggles[row].mCheck;
					TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|(sgToggles[row].mCheck ? PIRBF_BUTTON_SELECT : 0), NULL );
					return  1;
				}
				case OID_GHOST:
				{
					sgToggles[row].mGhost = !sgToggles[row].mGhost;
					TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|(sgToggles[row].mGhost ? PIRBF_BUTTON_SELECT : 0), NULL );
					return  1;
				}
				case OID_MULTI:
				{
					sgToggles[row].mMulti = !sgToggles[row].mMulti;
					TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|(sgToggles[row].mMulti ? PIRBF_BUTTON_SELECT : 0), NULL );
					return  1;
				}
				}
            }
        }
		break;

    	case PICBREQ_BUTTON_DOWN:
		{
			switch( iArgs[0] )
			{
			case ID_THE_BUTTON:
				DoPopup( iFilter, iReq );
				return  1;
			}
		}
		break;
    }
	
	return  0;
}




DemoWindow  gPopupWindow =
{
    Open,
    Close,
    Msg
};
