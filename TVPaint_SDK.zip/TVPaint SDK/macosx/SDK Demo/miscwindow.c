

#include "plugdllx.h"
#include "demowindow.h"
#include "demo.h"
#include "colorrange.h"
#include "colorpicker.h"



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Misc Subwindow


#define THE_BUTTON_X   120
#define THE_BUTTON_Y    70
#define THE_BUTTON_W   770
#define THE_BUTTON_H   180

#define START  10000


#define ID_TOP_LABEL         (START+001)
#define ID_THE_BUTTON_LABEL  (START+002)

#define ID_TICKS             (START+100)
#define ID_COORDS            (START+101)

#define ID_COLORRANGE_LABEL  (START+110)
#define ID_COLORRANGE        (START+111)
#define ID_COLORPICKER_LABEL (START+120)
#define ID_COLORPICKER       (START+121)

#define ID_THE_BUTTON        (START+999)




static struct
{
    int  mTicks;
    int  mCoords;

	ColorRange*   mColors;
	ColorPicker*  mPicker;
} sgToggles;



static void
Open( PIFilter* iFilter, DWORD iReq )
{
    int  x = 140;
    int  y = gStartSubWindowY;

    static int  first = 1;
    if( first )
    {
        first = 0;

        sgToggles.mTicks  = 0;
        sgToggles.mCoords = 0;

		sgToggles.mColors = ColorRangeNew( iFilter );
		sgToggles.mPicker = ColorPickerNew( iFilter );
    }
	else if( sgToggles.mTicks  ||  sgToggles.mCoords )
	{
		DemoDrawString( iFilter, iReq, ID_MESSAGES, "<<Autoreactivation of ticks and coords>>" );
		if( sgToggles.mTicks )
		{
			TVGrabTicks( iFilter, iReq, PITICKS_FLAG_ON );
		}
		if( sgToggles.mCoords )
		{
			TVGrabCoords( iFilter, iReq, 1 );
		}
	}

    x = 80;
    y = gStartSubWindowY + 25;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_TICKS,  PIRBF_BUTTON_CHECK|((sgToggles.mTicks)?  PIRBF_BUTTON_SELECT:0), "Grab Ticks"  ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_COORDS, PIRBF_BUTTON_CHECK|((sgToggles.mCoords)? PIRBF_BUTTON_SELECT:0), "Grab Coords" ); y += 20;

	x = 9;
	y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 90, 20, ID_COLORRANGE_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "Color Range" ); y += 20;
	TVAddButtonReq( iFilter, iReq, x, y, 90, 0, ID_COLORRANGE, PIRBF_BUTTON_NORMAL, NULL ); y += 20;
	TVPutButtonImage( iFilter, iReq, ID_COLORRANGE, sgToggles.mColors->MakeBlock( sgToggles.mColors, iFilter, 87, 13 ), 0 );

	x = 9;
	y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 90, 20, ID_COLORPICKER_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "Color Picker" ); y += 20;
	TVAddButtonReq( iFilter, iReq, x, y, 90, 0, ID_COLORPICKER, PIRBF_BUTTON_NORMAL, NULL ); y += 20;
	TVPutButtonImage( iFilter, iReq, ID_COLORPICKER, sgToggles.mPicker->MakeBlock( sgToggles.mPicker, iFilter, 87, 13 ), 0 );

    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y-30, 150, 20, ID_THE_BUTTON_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "What you get ..." ); y += 20;
    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y, THE_BUTTON_W, THE_BUTTON_H, ID_THE_BUTTON, PIRBF_BUTTON_INVERT, "" );
    TVPutButtonImage( iFilter, iReq, ID_THE_BUTTON, TVAllocPIBlock( iFilter, THE_BUTTON_W, THE_BUTTON_H, 0 ), 0 );
}


static void
Close( PIFilter* iFilter, DWORD iReq )
{
    TVRemoveButtonReq( iFilter, iReq, ID_TICKS );
    TVRemoveButtonReq( iFilter, iReq, ID_COORDS );

    TVRemoveButtonReq( iFilter, iReq, ID_COLORRANGE_LABEL );
    TVRemoveButtonReq( iFilter, iReq, ID_COLORRANGE );

    TVRemoveButtonReq( iFilter, iReq, ID_COLORPICKER_LABEL );
    TVRemoveButtonReq( iFilter, iReq, ID_COLORPICKER );

    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON_LABEL );
    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );

	if( sgToggles.mTicks  ||  sgToggles.mCoords )
	{
		DemoDrawString( iFilter, iReq, ID_MESSAGES, "<<Autodeactivation of ticks and coords>>" );
		if( sgToggles.mTicks )
		{
			TVGrabTicks( iFilter, iReq, PITICKS_FLAG_OFF );
		}
		if( sgToggles.mCoords )
		{
			TVGrabCoords( iFilter, iReq, 0 );
		}
	}
}


static int
Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    char  tmp[256];

    switch( iEvent )
    {
        case PICBREQ_BUTTON_UP:
        {
            switch( iArgs[0] )
            {
            case ID_TICKS:
				sgToggles.mTicks = !sgToggles.mTicks;
				TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|(sgToggles.mTicks?PIRBF_BUTTON_SELECT:0), NULL );
				if( sgToggles.mTicks )
				{
					TVGrabTicks( iFilter, iReq, PITICKS_FLAG_ON );
				}
				else
				{
					TVGrabTicks( iFilter, iReq, PITICKS_FLAG_OFF );
				}
				return  1;

            case ID_COORDS:
				sgToggles.mCoords = !sgToggles.mCoords;
				TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|(sgToggles.mCoords?PIRBF_BUTTON_SELECT:0), NULL );
				if( sgToggles.mCoords )
				{
					TVGrabCoords( iFilter, iReq, 1 );
				}
				else
				{
					TVGrabCoords( iFilter, iReq, 0 );
				}
				return  1;

			case ID_COLORRANGE:
				sgToggles.mColors->Grab( sgToggles.mColors, iFilter );
				TVPutButtonImage( iFilter, iReq, ID_COLORRANGE, sgToggles.mColors->MakeBlock( sgToggles.mColors, iFilter, 87, 13 ), 0 );
				return  1;

			case ID_COLORPICKER:
				sgToggles.mPicker->Grab( sgToggles.mPicker, iFilter );
				TVPutButtonImage( iFilter, iReq, ID_COLORPICKER, sgToggles.mPicker->MakeBlock( sgToggles.mPicker, iFilter, 87, 13 ), 0 );
				return  1;
            }
        }
		break;

	case PICBREQ_TICKS:
        sprintf( tmp, "Tick( id=%d, x=%7.2lf, y=%7.2lf, scrx=%7.2lf, scry=%7.2lf, pressure=%d, time=%d, ctrl=%d, reqx=%d, reqy=%d, iconic=%d )", (int)iArgs[0], ARG2FLOAT(1), ARG2FLOAT(2), ARG2FLOAT(3), ARG2FLOAT(4), (int)iArgs[5], (int)iArgs[6], (int)iArgs[7], (int)iArgs[8], (int)iArgs[9], (int)iArgs[10] );
		DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );
		return  1;

	case PICBREQ_COORD:
        sprintf( tmp, "Coord( id=%d, x=%7.2lf, y=%7.2lf, scrx=%7.2lf, scry=%7.2lf, pressure=%d, time=%d, ctrl=%d, reqx=%d, reqy=%d )", (int)iArgs[0], ARG2FLOAT(1), ARG2FLOAT(2), ARG2FLOAT(3), ARG2FLOAT(4), (int)iArgs[5], (int)iArgs[6], (int)iArgs[7], (int)iArgs[8], (int)iArgs[9] );
		DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );
		return  1;
    }
	
	return  0;
}




DemoWindow  gMiscWindow =
{
    Open,
    Close,
    Msg
};
