

#include "plugdllx.h"
#include "demowindow.h"
#include "demo.h"



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Req Subwindow


#define THE_BUTTON_X   350
#define THE_BUTTON_Y    70
#define THE_BUTTON_W   500
#define THE_BUTTON_H   180

#define START  7000


#define ID_TOP_LABEL         (START+001)
#define ID_THE_BUTTON_LABEL  (START+002)

#define ID_LOCK_REQ          (START+100)
#define ID_NO_DRAG_REQ       (START+101)
#define ID_NO_DEPTH_REQ      (START+102)
#define ID_NO_CLOSE_REQ      (START+103)
#define ID_CENTER_REQ        (START+104)
#define ID_RESIZE_REQ        (START+105)

#define ID_X                 (START+200)
#define ID_Y                 (START+201)
#define ID_W                 (START+202)
#define ID_H                 (START+203)

#define ID_THE_BUTTON        (START+999)


#define ID_CLOSE             (START+500)


static struct
{
    DWORD  mReq;

	DWORD  mBigReq;

    int  mX;
    int  mY;
    int  mW;
    int  mH;
	
    int  mLockReq;
    int  mNoDragReq;
    int  mNoDepthReq;
    int  mNoCloseReq;
    int  mCenterReq;
    int  mResizeReq;

	int  mOldFlags;
} sgToggles;


static int ReqMsg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs );


static void
MakeButton( PIFilter* iFilter, DWORD iReq )
{
    int  f = 0;

    if( sgToggles.mLockReq    )  f |= PIRF_LOCK_REQ;
    if( sgToggles.mNoDragReq  )  f |= PIRF_NO_DRAG_REQ;
    if( sgToggles.mNoDepthReq )  f |= PIRF_NO_DEPTH_REQ;
    if( sgToggles.mNoCloseReq )  f |= PIRF_NO_CLOSE_REQ;
    if( sgToggles.mCenterReq  )  f |= PIRF_CENTER_REQ;
    if( sgToggles.mResizeReq  )  f |= PIRF_RESIZE_REQ;

	if( f == sgToggles.mOldFlags )
	{
		if( sgToggles.mReq )
		{
			TVResizeReq( iFilter, sgToggles.mReq, sgToggles.mX, sgToggles.mY, sgToggles.mW, sgToggles.mH );
		}
	}
	else
	{
		if( sgToggles.mReq )
		{
			TVCloseReq( iFilter, sgToggles.mReq );
		}

		sgToggles.mReq = TVOpenReqEx( iFilter,
									  sgToggles.mW, sgToggles.mH, sgToggles.mX, sgToggles.mY,
									  f, "DEMO !!!", ReqMsg );
		sgToggles.mOldFlags = f;
	}
}


static int
ReqMsg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
	char  tmp[256];
	
    switch( iEvent )
    {
	case PICBREQ_BUTTON_UP:
		switch( iArgs[0] )
		{
		case ID_CLOSE:
			TVCloseReq( iFilter, iReq );
			sgToggles.mOldFlags = 1111111111; // != from all possible flag combinations
			sgToggles.mReq = 0;
			break;
		}
		break;
		
	case PICBREQ_OPEN://xywh
		sgToggles.mX = (int)iArgs[0];
		sgToggles.mY = (int)iArgs[1];
		sgToggles.mW = (int)iArgs[2];
		sgToggles.mH = (int)iArgs[3];
		sprintf( tmp, "PICBREQ_OPEN( x=%d, y=%d, w=%d, h=%d )", sgToggles.mX, sgToggles.mY, sgToggles.mW, sgToggles.mH );
		DemoDrawString( iFilter, sgToggles.mBigReq, ID_THE_BUTTON, tmp );

		TVAddButtonReq( iFilter, iReq, 5, 5, 40, 0, ID_CLOSE, PIRBF_BUTTON_ACTION, "Close" );
		break;

	case PICBREQ_CLOSE://xywhf
		sgToggles.mX = (int)iArgs[0];
		sgToggles.mY = (int)iArgs[1];
		sgToggles.mW = (int)iArgs[2];
		sgToggles.mH = (int)iArgs[3];
		sprintf( tmp, "PICBREQ_CLOSE( x=%d, y=%d, w=%d, h=%d )", sgToggles.mX, sgToggles.mY, sgToggles.mW, sgToggles.mH );
		DemoDrawString( iFilter, sgToggles.mBigReq, ID_THE_BUTTON, tmp );
		break;
		
	case PICBREQ_DRAG://xy
		sgToggles.mX = (int)iArgs[0];
		sgToggles.mY = (int)iArgs[1];
		sprintf( tmp, "PICBREQ_DRAG( x=%d, y=%d )", sgToggles.mX, sgToggles.mY );
		DemoDrawString( iFilter, sgToggles.mBigReq, ID_THE_BUTTON, tmp );
		if( sgToggles.mX < 20  ||  sgToggles.mX > 800  ||  sgToggles.mY < 20  ||  sgToggles.mY > 800 )
		{
			if( sgToggles.mX <  20 ) sgToggles.mX =  20;
			if( sgToggles.mX > 800 ) sgToggles.mX = 800;
			if( sgToggles.mY <  20 ) sgToggles.mY =  20;
			if( sgToggles.mY > 800 ) sgToggles.mY = 800;
			sprintf( tmp, ">>> Limited to : x=%d, y=%d", sgToggles.mX, sgToggles.mY );
			DemoDrawString( iFilter, sgToggles.mBigReq, ID_THE_BUTTON, tmp );
			TVResizeReq( iFilter, iReq, sgToggles.mX, sgToggles.mY, sgToggles.mW, sgToggles.mH );
		}

		sprintf( tmp, "%d", sgToggles.mX );
		TVPutButtonString( iFilter, sgToggles.mBigReq, ID_X, tmp );
		sprintf( tmp, "%d", sgToggles.mY );
		TVPutButtonString( iFilter, sgToggles.mBigReq, ID_Y, tmp );
		break;

	case PICBREQ_RESIZE://whxy
		sgToggles.mW = (int)iArgs[0];
		sgToggles.mH = (int)iArgs[1];
		sgToggles.mX = (int)iArgs[2];
		sgToggles.mY = (int)iArgs[3];
		sprintf( tmp, "PICBREQ_RESIZE( w=%d, h=%d, x=%d, y=%d )", sgToggles.mW, sgToggles.mH, sgToggles.mX, sgToggles.mY );
		DemoDrawString( iFilter, sgToggles.mBigReq, ID_THE_BUTTON, tmp );
		if( sgToggles.mW < 50  ||  sgToggles.mW > 400  ||  sgToggles.mH < 30  ||  sgToggles.mH > 400 )
		{
			if( sgToggles.mW <  50 ) sgToggles.mW = 50;
			if( sgToggles.mW > 400 ) sgToggles.mW = 400;
			if( sgToggles.mH <  30 ) sgToggles.mH = 30;
			if( sgToggles.mH > 400 ) sgToggles.mH = 400;
			sprintf( tmp, ">>> Limited to : w=%d, h=%d", sgToggles.mW, sgToggles.mH );
			DemoDrawString( iFilter, sgToggles.mBigReq, ID_THE_BUTTON, tmp );
		}

		sprintf( tmp, "%d", sgToggles.mX );
		TVPutButtonString( iFilter, sgToggles.mBigReq, ID_X, tmp );
		sprintf( tmp, "%d", sgToggles.mY );
		TVPutButtonString( iFilter, sgToggles.mBigReq, ID_Y, tmp );
		sprintf( tmp, "%d", sgToggles.mW );
		TVPutButtonString( iFilter, sgToggles.mBigReq, ID_W, tmp );
		sprintf( tmp, "%d", sgToggles.mH );
		TVPutButtonString( iFilter, sgToggles.mBigReq, ID_H, tmp );

		TVResizeReq( iFilter, iReq, sgToggles.mX, sgToggles.mY, sgToggles.mW, sgToggles.mH );
		break;
    }

	return  1;
}


static void
AddTextField( PIFilter* iFilter, DWORD iReq, int iX, int iY, int iID, char* iLabel, int iVal )
{
    char  tmp[256];

    TVAddButtonReq( iFilter, iReq, iX-5,  iY,  1, 0, iID+150, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, iLabel );
    TVChangeButtonName( iFilter, iReq, iID+150, iLabel, BUTTON_TEXT_OLEFT );

    sprintf( tmp, "%d", iVal );
    TVAddButtonReq( iFilter, iReq, iX,    iY, 40, 0, iID,     PIRBF_BUTTON_TEXT_INT,   tmp );

    TVAddButtonReq( iFilter, iReq, iX+45, iY,  0, 0, iID+100, PIRBF_BUTTON_MINISLIDER, NULL );
}


static void
RemoveTextField( PIFilter* iFilter, DWORD iReq, int iID )
{
    TVRemoveButtonReq( iFilter, iReq, iID+150 );
    TVRemoveButtonReq( iFilter, iReq, iID );
    TVRemoveButtonReq( iFilter, iReq, iID+100 );
}


static void
DoMiniSlider( PIFilter* iFilter, DWORD iReq, int iID, int iDelta, int* ioVal, int iMin, int iMax )
{
	char  tmp[256];
	
	*ioVal += iDelta;
	if( *ioVal < iMin )
		*ioVal = iMin;
	if( *ioVal > iMax )
		*ioVal = iMax;

	sprintf( tmp, "%d", *ioVal );
	TVPutButtonString( iFilter, iReq, iID-100, tmp );

	MakeButton( iFilter, iReq );
}


static void
DoTextField( PIFilter* iFilter, DWORD iReq, int iID, int* ioVal, int iMin, int iMax )
{
	char  tmp[256];
	
	TVGetButtonString( iFilter, iReq, iID, tmp, 255 );
	sscanf( tmp, "%d", ioVal );
	if( *ioVal < iMin )
	{
		*ioVal = iMin;
		sprintf( tmp, "%d", *ioVal );
		TVPutButtonString( iFilter, iReq, iID, tmp );
	}
	if( *ioVal > iMax )
	{
		*ioVal = iMax;
		sprintf( tmp, "%d", *ioVal );
		TVPutButtonString( iFilter, iReq, iID, tmp );
	}

	MakeButton( iFilter, iReq );
}


static void
Open( PIFilter* iFilter, DWORD iReq )
{
    int  x = 140;
    int  y = gStartSubWindowY;

	static int  first = 1;
    if( first )
    {
        first = 0;
        sgToggles.mReq = 0;


        sgToggles.mX = 50;
        sgToggles.mY = 50;
        sgToggles.mW = 100;
        sgToggles.mH = 100;

        sgToggles.mLockReq    = 0;
        sgToggles.mNoDragReq  = 0;
        sgToggles.mNoDepthReq = 0;
        sgToggles.mNoCloseReq = 0;
        sgToggles.mCenterReq  = 0;
        sgToggles.mResizeReq  = 0;

		sgToggles.mOldFlags = 1111111111; // != from all possible flag combinations
    }
	sgToggles.mBigReq = iReq;

    TVAddButtonReq( iFilter, iReq, 0, y, 200, 20, ID_TOP_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "PIRF_*" ); y += 20;

    x = 140;
    y = gStartSubWindowY + 25;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_LOCK_REQ,     PIRBF_BUTTON_CHECK|(sgToggles.mLockReq?     PIRBF_BUTTON_SELECT:0), "LOCK_REQ"     ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_NO_DRAG_REQ,  PIRBF_BUTTON_CHECK|(sgToggles.mNoDragReq?   PIRBF_BUTTON_SELECT:0), "NO_DRAG_REQ"  ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_NO_DEPTH_REQ, PIRBF_BUTTON_CHECK|(sgToggles.mNoDepthReq?  PIRBF_BUTTON_SELECT:0), "NO_DEPTH_REQ" ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_NO_CLOSE_REQ, PIRBF_BUTTON_CHECK|(sgToggles.mNoCloseReq?  PIRBF_BUTTON_SELECT:0), "NO_CLOSE_REQ" ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_CENTER_REQ,   PIRBF_BUTTON_CHECK|(sgToggles.mCenterReq?   PIRBF_BUTTON_SELECT:0), "CENTER_REQ"   ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_RESIZE_REQ,   PIRBF_BUTTON_CHECK|(sgToggles.mResizeReq?   PIRBF_BUTTON_SELECT:0), "RESIZE_REQ"   ); y += 20;

	x = 230;
	y = gStartSubWindowY + 25;
    AddTextField( iFilter, iReq, x, y, ID_X, "X",      sgToggles.mX );  y += 20;
    AddTextField( iFilter, iReq, x, y, ID_Y, "Y",      sgToggles.mY );  y += 20;
    AddTextField( iFilter, iReq, x, y, ID_W, "Width",  sgToggles.mW );  y += 20;
    AddTextField( iFilter, iReq, x, y, ID_H, "Height", sgToggles.mH );  y += 20;

    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y-30, 150, 20, ID_THE_BUTTON_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "What you get ..." ); y += 20;
    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y, THE_BUTTON_W, THE_BUTTON_H, ID_THE_BUTTON, PIRBF_BUTTON_INVERT, "" );
    TVPutButtonImage( iFilter, iReq, ID_THE_BUTTON, TVAllocPIBlock( iFilter, THE_BUTTON_W, THE_BUTTON_H, 0 ), 0 );
    DemoDrawString( iFilter, iReq, ID_THE_BUTTON, "<Nothing yet>" );

	MakeButton( iFilter, iReq );
}


static void
Close( PIFilter* iFilter, DWORD iReq )
{
    TVRemoveButtonReq( iFilter, iReq, ID_TOP_LABEL );

    TVRemoveButtonReq( iFilter, iReq, ID_LOCK_REQ );
    TVRemoveButtonReq( iFilter, iReq, ID_NO_DRAG_REQ );
    TVRemoveButtonReq( iFilter, iReq, ID_NO_DEPTH_REQ );
    TVRemoveButtonReq( iFilter, iReq, ID_NO_CLOSE_REQ );
    TVRemoveButtonReq( iFilter, iReq, ID_CENTER_REQ );
    TVRemoveButtonReq( iFilter, iReq, ID_RESIZE_REQ );

    RemoveTextField( iFilter, iReq, ID_X );
    RemoveTextField( iFilter, iReq, ID_Y );
    RemoveTextField( iFilter, iReq, ID_W );
    RemoveTextField( iFilter, iReq, ID_H );

    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON_LABEL );
    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );

	if( sgToggles.mReq )
	{
		TVCloseReq( iFilter, sgToggles.mReq );
		sgToggles.mOldFlags = 1111111111; // != from all possible flag combinations
		sgToggles.mReq = 0;
	}
}


static void
Click( PIFilter* iFilter, DWORD iReq, DWORD iWhich, int* ioBool )
{
    *ioBool = !*ioBool;

    TVChangeButtonReq( iFilter, iReq, iWhich, PIRBF_BUTTON_CHECK|(*ioBool?PIRBF_BUTTON_SELECT:0), NULL );
    MakeButton( iFilter, iReq );
}


static int
Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    switch( iEvent )
    {
        case PICBREQ_BUTTON_UP:
        {
            switch( iArgs[0] )
            {
            case ID_LOCK_REQ:
                Click( iFilter, iReq, iArgs[0], &sgToggles.mLockReq );
				return  1;
            case ID_NO_DRAG_REQ:
                Click( iFilter, iReq, iArgs[0], &sgToggles.mNoDragReq );
				return  1;
            case ID_NO_DEPTH_REQ:
                Click( iFilter, iReq, iArgs[0], &sgToggles.mNoDepthReq );
				return  1;
            case ID_NO_CLOSE_REQ:
                Click( iFilter, iReq, iArgs[0], &sgToggles.mNoCloseReq );
				return  1;
            case ID_CENTER_REQ:
                Click( iFilter, iReq, iArgs[0], &sgToggles.mCenterReq );
				return  1;
            case ID_RESIZE_REQ:
                Click( iFilter, iReq, iArgs[0], &sgToggles.mResizeReq );
				return  1;

			case ID_X:
				DoTextField( iFilter, iReq, iArgs[0], &sgToggles.mX, 20, 800 );
				return  1;
			case ID_Y:
				DoTextField( iFilter, iReq, iArgs[0], &sgToggles.mY, 20, 800 );
				return  1;
			case ID_W:
				DoTextField( iFilter, iReq, iArgs[0], &sgToggles.mW, 100, 400 );
				return  1;
			case ID_H:
				DoTextField( iFilter, iReq, iArgs[0], &sgToggles.mH, 100, 400 );
				return  1;
            }
        }
        break;

	    case PICBREQ_MINISLIDER:
        {
            switch( iArgs[0] )
            {
			case ID_X+100:
				DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgToggles.mX, 20, 800 );
				return  1;
			case ID_Y+100:
				DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgToggles.mY, 20, 800 );
				return  1;
			case ID_W+100:
				DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgToggles.mW, 50, 400 );
				return  1;
			case ID_H+100:
				DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgToggles.mH, 30, 400 );
				return  1;
			}
        }
        break;
    }
	
	return  0;
}




DemoWindow  gReqWindow =
{
    Open,
    Close,
    Msg
};
