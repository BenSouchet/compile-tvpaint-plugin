/**************************************************************************************/
/**************************************************************************************/
/*                                                                                    */
/*                                 DEMO FILTER                                        */
/*                                                                                    */
/**************************************************************************************/
/**************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "plugdllx.h"
#include "plugx.h"
#include "demowindow.h"

#ifdef WIN32
#include <malloc.h>
#endif

#define  CLAMP( x, a, b )  (((x)<(a)) ? (a) : (((x)>(b)) ? (b) : (x)))



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Aura interface


// sizes of some GUI components
#define REQUESTER_W        900
#define REQUESTER_H        380
#define POSX               103
#define SIZE               50
#define SUB_WINDOW_H       225

#define MESSAGES_W  (REQUESTER_W-19)
#define MESSAGES_H  100

// ID's of GUI components
#define ID_TABS            10

#define ID_SEP01           901
#define ID_SEP02           902


#include "demo.h"

/**************************************************************************************/
// all data needed by the plugin

static struct
{
    DWORD       mReq;       // Identification of the requester.  (=0 closed, !=0 requester ID)

    void*       mLocalFile; // file containing localized messages
}
Data =
{
    0,
    NULL
};


int  gStartSubWindowY = 0;


/**************************************************************************************/
//  Localisation

#define TXT_NAME            GetLocalString( iFilter, 100,    "SDK Demo filter" )

#define TXT_REQUESTER       GetLocalString( iFilter, 10000,  "Filter : Demo" )

#define TXT_ERROR01         GetLocalString( iFilter, 30000,  "Can't Open Requester !" )


static char*
GetLocalString( PIFilter* iFilter, int iNum, char* iDefault )
{
    char*  str;

    if( Data.mLocalFile == NULL )
        return  iDefault;

    str = TVGetLocalString( iFilter, Data.mLocalFile, iNum );
    if( str == NULL  ||  strlen( str ) == 0 )
        return  iDefault;

    return  str;
}


/**************************************************************************************/
// Utility functions

#define LINE_HEIGHT  14

void
DemoDrawString( PIFilter* iFilter, DWORD iReq, DWORD iID, const char* iString )
{
    PIBlock*  block = TVGetButtonImage( iFilter, iReq, iID, 0 );

    if( !block )
        return;

    memmove( block->Data, &block->Data[LINE_HEIGHT*block->Width], block->Width*(block->Height-LINE_HEIGHT)*sizeof(PIPixel) );
    memset( &block->Data[block->Width*(block->Height-LINE_HEIGHT)], 0, block->Width*LINE_HEIGHT*sizeof(PIPixel) );

    TVTextBlock( iFilter, block, 5, block->Height-5, (char*)iString, 0xFFFFFFFF );
    TVRefreshButtonImage( iFilter, iReq, iID, 0, 0, block->Width, block->Height );
}


static void
DrawMessage( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs, const char* iStr )
{
    char  tmp[256];

    switch( iEvent )
    {
    case PICBREQ_OPEN:
        sprintf( tmp, "%s: PICBREQ_OPEN<%d>( x=%d, y=%d, w=%d, h=%d )", iStr, (int)iReq, (int)iArgs[0], (int)iArgs[1], (int)iArgs[2], (int)iArgs[3] );
        break;

    case PICBREQ_CLOSE:
        sprintf( tmp, "%s: PICBREQ_CLOSE<%d>( x=%d, y=%d, w=%d, h=%d, shutdown=%d )", iStr, (int)iReq, (int)iArgs[0], (int)iArgs[1], (int)iArgs[2], (int)iArgs[3], (int)iArgs[4] );
        break;

    case PICBREQ_DRAG:
        sprintf( tmp, "%s: PICBREQ_DRAG<%d>( x=%d, y=%d )", iStr, (int)iReq, (int)iArgs[0], (int)iArgs[1] );
        break;

    case PICBREQ_KEY_DOWN:
        sprintf( tmp, "%s: PICBREQ_KEY_DOWN<%d>( ascii=%d )", iStr, (int)iReq, (int)iArgs[0] );
        break;

    case PICBREQ_FKEY_DOWN:
        sprintf( tmp, "%s: PICBREQ_FKEY_DOWN<%d>( ascii=%d )", iStr, (int)iReq, (int)iArgs[0] );
        break;

    case PICBREQ_RESIZE:
        sprintf( tmp, "%s: PICBREQ_RESIZE<%d>( w=%d, h=%d, x=%d, y=%d )", iStr, (int)iReq, (int)iArgs[0], (int)iArgs[1], (int)iArgs[2], (int)iArgs[3], (int)iArgs[4] );
        break;

    case PICBREQ_BUTTON_TEXT:
        sprintf( tmp, "%s: PICBREQ_BUTTON_TEXT<%d>()", iStr, (int)iReq );
        break;

    case PICBREQ_PROJECT_CHANGE:
        sprintf( tmp, "%s: PICBREQ_PROJECT_CHANGE<%d>()", iStr, (int)iReq );
        break;

    case PICBREQ_FILE_RESET:
        sprintf( tmp, "%s: PICBREQ_FILE_RESET<%d>()", iStr, (int)iReq );
        break;

    case PICBREQ_FILE_LOAD:
        sprintf( tmp, "%s: PICBREQ_FILE_LOAD<%d>()", iStr, (int)iReq );
        break;

    case PICBREQ_FILE_SAVE:
        sprintf( tmp, "%s: PICBREQ_FILE_SAVE<%d>()", iStr, (int)iReq );
        break;

    case PICBREQ_FILE_SAVE_AS:
        sprintf( tmp, "%s: PICBREQ_FILE_SAVE_AS<%d>()", iStr, (int)iReq );
        break;

    case PICBREQ_BUTTON_DOWN:
        sprintf( tmp, "%s: PICBREQ_BUTTON_DOWN<%d>( id=%d, x=%d, y=%d, mouse=%d, pressure=%d, time=%d, ctrl=%d )", iStr, (int)iReq, (int)iArgs[0], (int)iArgs[1], (int)iArgs[2], (int)iArgs[3], (int)iArgs[4], (int)iArgs[5], (int)iArgs[6] );
        break;

    case PICBREQ_BUTTON_UP:
        sprintf( tmp, "%s: PICBREQ_BUTTON_UP<%d>( id=%d, x=%d, y=%d, mouse=%d, pressure=%d, time=%d, ctrl=%d )", iStr, (int)iReq, (int)iArgs[0], (int)iArgs[1], (int)iArgs[2], (int)iArgs[3], (int)iArgs[4], (int)iArgs[5], (int)iArgs[6] );
        break;

    case PICBREQ_MOVE:
        sprintf( tmp, "%s: PICBREQ_MOVE<%d>( id=%d, x=%d, y=%d, mouse=%d, pressure=%d, time=%d, ctrl=%d )", iStr, (int)iReq, (int)iArgs[0], (int)iArgs[1], (int)iArgs[2], (int)iArgs[3], (int)iArgs[4], (int)iArgs[5], (int)iArgs[6] );
        break;

    case PICBREQ_COORD:
        sprintf( tmp, "%s: PICBREQ_COORD<%d>( id=%d, x=%7.2f, y=%7.2f, scrx=%7.2f, scry=%7.2f, pressure=%d, time=%d, ctrl=%d, reqx=%d, reqy=%d )", iStr, (int)iReq, (int)iArgs[0], ARG2FLOAT(1), ARG2FLOAT(2), ARG2FLOAT(3), ARG2FLOAT(4), (int)iArgs[5], (int)iArgs[6], (int)iArgs[7], (int)iArgs[8], (int)iArgs[9] );
        break;

    case PICBREQ_TICKS:
        sprintf( tmp, "%s: PICBREQ_TICKS<%d>( id=%d, x=%7.2f, y=%7.2f, scrx=%7.2f, scry=%7.2f, pressure=%d, time=%d, ctrl=%d, reqx=%d, reqy=%d, iconic=%d )", iStr, (int)iReq, (int)iArgs[0], ARG2FLOAT(1), ARG2FLOAT(2), ARG2FLOAT(3), ARG2FLOAT(4), (int)iArgs[5], (int)iArgs[6], (int)iArgs[7], (int)iArgs[8], (int)iArgs[9], (int)iArgs[10] );
        break;

    case PICBREQ_MINISLIDER:
        sprintf( tmp, "%s: PICBREQ_MINISLIDER<%d>( id=%d, delta=%d, time=%d, ctrl=%d )", iStr, (int)iReq, (int)iArgs[0], (int)iArgs[1], (int)iArgs[2], (int)iArgs[3] );
        break;

    case PICBREQ_SLIDER_MOVE:
        sprintf( tmp, "%s: PICBREQ_SLIDER_MOVE<%d>( id=%d, posx=%7.2f, posy=%7.2f, button=%d, time=%d, ctrl=%d )", iStr, (int)iReq, (int)iArgs[0], ARG2FLOAT(1), ARG2FLOAT(2), (int)iArgs[3], (int)iArgs[4], (int)iArgs[5] );
        break;

    case PICBREQ_SLIDER_RELEASE:
        sprintf( tmp, "%s: PICBREQ_SLIDER_RELEASE<%d>( id=%d, posx=%7.2f, posy=%7.2f, button=%d, time=%d, ctrl=%d )", iStr, (int)iReq, (int)iArgs[0], ARG2FLOAT(1), ARG2FLOAT(2), (int)iArgs[3], (int)iArgs[4], (int)iArgs[5] );
        break;

    case PICBREQ_TABS_CHANGE:
        sprintf( tmp, "%s: PICBREQ_TABS_CHANGE<%d>( id=%d, tab=%d, time=%d, ctrl=%d )", iStr, (int)iReq, (int)iArgs[0], (int)iArgs[1], (int)iArgs[2], (int)iArgs[3] );
        break;

    case PICMETA_CLOSE:
        sprintf( tmp, "%s: PICMETA_CLOSE<%d>()", iStr, (int)iReq );
        break;

    case PICMETA_POINT:
        sprintf( tmp, "%s: PICMETA_POINT<%d>( fx=%7.2lf, fy=%7.2lf, button=%d, pressure=%d )", iStr, (int)iReq, ARG2FLOAT(0), ARG2FLOAT(1), (int)iArgs[2], (int)iArgs[3] );
        break;

    case PICMETA_DRAW:
        sprintf( tmp, "%s: PICMETA_DRAW<%d>( fx=%7.2lf, fy=%7.2lf, button=%d, pressure=%d )", iStr, (int)iReq, ARG2FLOAT(0), ARG2FLOAT(1), (int)iArgs[2], (int)iArgs[3] );
        break;

    case PICMETA_LINE:
        sprintf( tmp, "%s: PICMETA_LINE<%d>( ofx=%7.2lf, ofy=%7.2lf, fx=%7.2lf, fy=%7.2lf, button=%d )", iStr, (int)iReq, ARG2FLOAT(0), ARG2FLOAT(1), ARG2FLOAT(2), ARG2FLOAT(3), (int)iArgs[4] );
        break;

    case PICMETA_RECT:
        sprintf( tmp, "%s: PICMETA_RECT<%d>( ofx=%7.2lf, ofy=%7.2lf, fx=%7.2lf, fy=%7.2lf, button=%d )", iStr, (int)iReq, ARG2FLOAT(0), ARG2FLOAT(1), ARG2FLOAT(2), ARG2FLOAT(3), (int)iArgs[4] );
        break;

    case PICMETA_CIRCLE:
        sprintf( tmp, "%s: PICMETA_CIRCLE<%d>( ofx=%7.2lf, ofy=%7.2lf, fr=%7.2lf, button=%d )", iStr, (int)iReq, ARG2FLOAT(0), ARG2FLOAT(1), ARG2FLOAT(2), (int)iArgs[3] );
        break;

    case PICMETA_ELLIPSE:
        sprintf( tmp, "%s: PICMETA_ELLIPSE<%d>( ofx=%7.2lf, ofy=%7.2lf, fa=%7.2lf, fb=%7.2lf, button=%d )", iStr, (int)iReq, ARG2FLOAT(0), ARG2FLOAT(1), ARG2FLOAT(2), ARG2FLOAT(3), (int)iArgs[4] );
        break;

    case PICMETA_PREVIEW:
        sprintf( tmp, "%s: PICMETA_PREVIEW<%d>( x=%d, y=%d, w=%d, h=%d )", iStr, (int)iReq, (int)iArgs[0], (int)iArgs[1], (int)iArgs[2], (int)iArgs[3] );
        break;

	case PICBREQ_VIDEO_CHANGE_PREV:
        sprintf( tmp, "%s: PICBREQ_VIDEO_CHANGE_PREV<%d>", iStr );
        break;

	case PICBREQ_VIDEO_CHANGE:
        sprintf( tmp, "%s: PICBREQ_VIDEO_CHANGE<%d>", iStr );
        break;

    default:
        sprintf( tmp, "%s: UNKNOWN MESSAGE <%d> !!", iStr, (int)iEvent );
        break;
    }

    DemoDrawString( iFilter, Data.mReq, ID_MESSAGES, tmp );
}



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////


static int  sgCurrentTabs = 0;


static int
ForwardMsg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    if( iReq == 0 )
        iReq = Data.mReq;

    switch( sgCurrentTabs )
    {
    case 0:
        // a button of the "button" subwindow
        return  gButtonWindow.Msg( iFilter, iEvent, iReq, iArgs );
    case 1:
        // a button of the "text" subwindow
        return  gTextWindow.Msg( iFilter, iEvent, iReq, iArgs );
    case 2:
        // a button of the "popup" subwindow
        return  gPopupWindow.Msg( iFilter, iEvent, iReq, iArgs );
    case 3:
        // a button of the "slider" subwindow
        return  gSliderWindow.Msg( iFilter, iEvent, iReq, iArgs );
    case 4:
        // a button of the "meta" subwindow
        return  gMetaWindow.Msg( iFilter, iEvent, iReq, iArgs );
    case 5:
        // a button of the "req" subwindow
        return  gReqWindow.Msg( iFilter, iEvent, iReq, iArgs );
    case 6:
        // a button of the "project" subwindow
        return  gProjectWindow.Msg( iFilter, iEvent, iReq, iArgs );
    case 7:
        // a button of the "george" subwindow
        return  gGeorgeWindow.Msg( iFilter, iEvent, iReq, iArgs );
    case 8:
        // a button of the "misc" subwindow
        return  gMiscWindow.Msg( iFilter, iEvent, iReq, iArgs );
    case 9:
        // a button of the "preview" subwindow
        return  gPreviewWindow.Msg( iFilter, iEvent, iReq, iArgs );
    }

    return  0;
}



static void
CloseWindowEx( PIFilter* iFilter, DWORD iReq )
{
    switch( sgCurrentTabs )
    {
    case 0: // Button
        gButtonWindow.Close( iFilter, iReq );
        break;
    case 1: // Text
        gTextWindow.Close( iFilter, iReq );
        break;
    case 2: // Popup
        gPopupWindow.Close( iFilter, iReq );
        break;
    case 3: // Slider
        gSliderWindow.Close( iFilter, iReq );
        break;
    case 4: // Meta
        gMetaWindow.Close( iFilter, iReq );
        break;
    case 5: // Req
        gReqWindow.Close( iFilter, iReq );
        break;
    case 6: // Project
        gProjectWindow.Close( iFilter, iReq );
        break;
    case 7: // George
        gGeorgeWindow.Close( iFilter, iReq );
        break;
    case 8: // Misc
        gMiscWindow.Close( iFilter, iReq );
        break;
    case 9: // Preview
        gPreviewWindow.Close( iFilter, iReq );
        break;
    }
}


static void
OpenWindow( PIFilter* iFilter, DWORD iReq )
{

    switch( sgCurrentTabs )
    {
    case 0: // Button
        gButtonWindow.Open( iFilter, iReq );
        break;
    case 1: // Text
        gTextWindow.Open( iFilter, iReq );
        break;
    case 2: // Popup
        gPopupWindow.Open( iFilter, iReq );
        break;
    case 3: // Slider
        gSliderWindow.Open( iFilter, iReq );
        break;
    case 4: // Meta
        gMetaWindow.Open( iFilter, iReq );
        break;
    case 5: // Req
        gReqWindow.Open( iFilter, iReq );
        break;
    case 6: // Project
        gProjectWindow.Open( iFilter, iReq );
        break;
    case 7: // George
        gGeorgeWindow.Open( iFilter, iReq );
        break;
    case 8: // Misc
        gMiscWindow.Open( iFilter, iReq );
        break;
    case 9: // Preview
        gPreviewWindow.Open( iFilter, iReq );
        break;
    }
}


/**************************************************************************************/
// The function to process the events of my requester.
// In this simple example this isn't really necessary, we could have
// processed all messages in PI_Msg, but this way of doing things
// is easier to extend
static int
Requester_Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    char  tmp[512];
    char*  tabNames[] =
    {
        "Button",
        "Text",
        "Popup",
        "Slider",
        "Meta",
        "Req",
        "Project",
        "George",
        "Misc",
        "Preview",
        NULL
    };

    DrawMessage( iFilter, iEvent, iReq, iArgs, "Requester_Msg" );

    if( ForwardMsg( iFilter, iEvent, iReq, iArgs ) )
        return  1;

    switch( iEvent )
    {
        case PICBREQ_OPEN:
        {
            int  y = 5;

            Data.mReq = iReq;

            TVSetReqTitle( iFilter, Data.mReq, TXT_REQUESTER );

            TVAddTabs( iFilter, Data.mReq, 9, y, REQUESTER_W-20-9, 20, ID_TABS, 10, 0, (const char**)tabNames );
            y += 21;
            TVAddButtonReq( iFilter, Data.mReq, 0, y, REQUESTER_W, 0, ID_SEP01, PIRBF_BUTTON_HSEPARATOR, NULL );
            y += 8;

            gStartSubWindowY = y;
            gButtonWindow.Open( iFilter, iReq );
            sgCurrentTabs = 0;
            y += SUB_WINDOW_H;

            y += 2;
            TVAddButtonReq( iFilter, Data.mReq, 0, y, REQUESTER_W, 0, ID_SEP02, PIRBF_BUTTON_HSEPARATOR, NULL );
            y += 8;

            TVAddButtonReq( iFilter, Data.mReq, 9, y, MESSAGES_W, MESSAGES_H, ID_MESSAGES, PIRBF_BUTTON_INVERT, "" );
            TVPutButtonImage( iFilter, Data.mReq, ID_MESSAGES, TVAllocPIBlock( iFilter, MESSAGES_W, MESSAGES_H, 0 ), 0 );
            DemoDrawString( iFilter, Data.mReq, ID_MESSAGES, "<Nothing yet>" );
            y += 52;
        }
        break;

        case PICBREQ_CLOSE:
        {
            CloseWindowEx( iFilter, iReq );

            Data.mReq = 0;

            sprintf( tmp, "%d", (int)(iArgs[4]) );
            TVWriteUserString( iFilter, iFilter->PIName, "Open", tmp );
        }
        break;

        case PICBREQ_TABS_CHANGE:
        {
            switch( iArgs[0] )
            {
            case ID_TABS:
                if( (int)iArgs[1] != sgCurrentTabs )
                {
                    CloseWindowEx( iFilter, iReq );
                    sgCurrentTabs = iArgs[1];
                    OpenWindow( iFilter, iReq );
                }
                break;
            }
        }
        break;
    }

    return  1;
}


////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// The functions directly called by Aura through the plugin interface



/**************************************************************************************/
// "About" function, you can also open a much nicer requester

void FAR PASCAL
PI_About( PIFilter* iFilter )
{
    char  text[256];

    sprintf( text,
             "%s V%d,%d\nby S�bastien Miglio\nCopyright TVPaintD�veloppement\n20 january 2000",
             iFilter->PIName, iFilter->PIVersion, iFilter->PIRevision );

    TVWarning( iFilter, text );
}


/**************************************************************************************/
// Function called FIRST for the initialization of the filter

int FAR PASCAL
PI_Open( PIFilter* iFilter )
{
    char  tmp[256];

    // load the .loc file
    // we don't really cares if it fails here, since we do in GetLocalString()
    Data.mLocalFile = TVOpenLocalFile( iFilter, "sdk-fade.loc", 0 );

    strcpy( iFilter->PIName, TXT_NAME );
    iFilter->PIVersion  = 1;
    iFilter->PIRevision = 0;

    // If this plugin was the one open at Aura shutdown, re-open it
    TVReadUserString( iFilter, iFilter->PIName, "Open", tmp, "0", 255 );
    if( atoi( tmp ) )
    {
        PI_Parameters( iFilter, NULL );
    }

    return  1; // everything wen't well
}


/**************************************************************************************/
// Aura shutdown: we make all the necessary cleanup

void FAR PASCAL
PI_Close( PIFilter* iFilter )
{
    if( Data.mLocalFile )
    {
        TVCloseLocalFile( iFilter, Data.mLocalFile );
    }

    if( Data.mReq )
    {
        TVCloseReq( iFilter, Data.mReq );
    }
}


/**************************************************************************************/
// we have something to do !

int FAR PASCAL
PI_Parameters( PIFilter* iFilter, char* iArg )
{
    if( iArg )
    {
        // Nothing
    }
    else
    {
        // If the requester is not open, we open it.
        if( Data.mReq == 0 )
        {
            //DWORD  req = TVOpenFilterReqEx( iFilter, REQUESTER_W, REQUESTER_H, Requester_Msg, NULL, PIRF_STANDARD_REQ, 0 );
            //if( req == 0 )
            {

	            DWORD req = TVOpenReqEx( iFilter, REQUESTER_W, REQUESTER_H, 100,100, PIRF_STANDARD_REQ, "", Requester_Msg );
	            if( req == 0 )
		        {
			        TVWarning( iFilter, TXT_ERROR01 );
				    return  0;
				}
            }
        }
        else
        {
            TVReqToFront( iFilter, Data.mReq );
        }
    }

    return  1;
}


/**************************************************************************************/
// something happenned that needs our attention.

int FAR PASCAL
PI_Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    DrawMessage( iFilter, iEvent, iReq, iArgs, "PI_Msg" );

    if( ForwardMsg( iFilter, iEvent, iReq, iArgs ) )
        return  1;

    // Nothing to do here...

    return  1;
}


/**************************************************************************************/
// Start of the 'execution' of the filter for a new sequence.
// - iNumImages contains the total number of frames to be processed.
// Here you should allocate memory that is used for all frames,
// and precompute all the stuff that doesn't change from frame to frame.

int FAR PASCAL
PI_SequenceStart( PIFilter* iFilter, int iNum )
{
    // In this simple example we don't have anything to allocate/precompute.

    // 1 means 'continue', 0 means 'error, abort' (like 'not enough memory')
    return  1;
}


// Here you should cleanup what you've done in PI_SequenceStart

void FAR PASCAL
PI_SequenceFinish( PIFilter* iFilter )
{
    // nothing special to cleanup
}


/**************************************************************************************/

int FAR PASCAL
PI_Start( PIFilter* iFilter, double iPos, double iSize )
{
    // In this simple example we don't have anything to allocate/precompute.

    // 1 means 'continue', 0 means 'error, abort' (like 'not enough memory')
    return  1;
}


void FAR PASCAL
PI_Finish( PIFilter* iFilter )
{
    // nothing special to cleanup
}


/**************************************************************************************/

int FAR PASCAL
PI_Work( PIFilter* iFilter )
{
    // we never call TVExecute()...

    return  1;
}



