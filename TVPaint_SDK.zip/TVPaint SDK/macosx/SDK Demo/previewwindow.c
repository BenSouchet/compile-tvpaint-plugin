

#include "plugdllx.h"
#include "demowindow.h"
#include "demo.h"
#include "preview.h"



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Preview Subwindow


#define THE_BUTTON_X   350
#define THE_BUTTON_Y    70
#define THE_BUTTON_SIZE   128
/////#define THE_BUTTON_H   128

#define START  11000


#define ID_TOP_LABEL         (START+001)
#define ID_THE_BUTTON_LABEL  (START+002)

#define ID_FULLSCREEN        (START+100)
#define ID_ICONIC            (START+101)

#define ID_THE_BUTTON        (START+999)



enum PreviewType
{
    kNone,
    kFullScreen,
    kIconic
};


static struct
{
    int  mType;

    Preview*  mPreview;
} sgToggles;



static void
Negative( const PIBlock* iSrc, PIBlock* oDst )
{
    int  i;

    // some initializations
    int  size = oDst->Width * oDst->Height;
    PIPixel*  src = iSrc->Data;
    PIPixel*  dst = oDst->Data;

    // get the offsets of the channels in the pixel
    int  ro = iSrc->r;
    int  go = iSrc->g;
    int  bo = iSrc->b;
    int  ao = iSrc->a;

    // loop over all the pixels, here we don't care about their x/y positions...
    for( i = 0; i < size; ++i )
    {
        // get the source alpha channel
        int  a = src->c[ao];

        if( a != 0 )
        {
            // if not fully transparent...
            if( a == 255 )
            {
                // if fully opaque, the channel values are the color values
                // (see the SDK docs for the meaning of this sentence :)

                dst->c[ro] = 255-src->c[ro];
                dst->c[go] = 255-src->c[go];
                dst->c[bo] = 255-src->c[bo];
                dst->c[ao] = 255;
            }
            else
            {
                // if neither fully transparent nor fully opaque,
                // the channel values have to be computed from the color values and the alpha channel
                // (see the SDK docs for the meaning of this sentence :)

                int  r = (src->c[ro] * 255) / a;
                int  g = (src->c[go] * 255) / a;
                int  b = (src->c[bo] * 255) / a;

                dst->c[ro] = ((255-r) * a) / 255;
                dst->c[go] = ((255-g) * a) / 255;
                dst->c[bo] = ((255-b) * a) / 255;
                dst->c[ao] = a;
            }
        }
        else
        {
            // if fully transparent, destination will also be fully transparent
            dst->l = 0x00000000;
        }

        // and on to the next pixel..
        ++src;
        ++dst;
    }
}




static void
DoPreview( PIFilter* iFilter, DWORD iReq )
{
    switch( sgToggles.mType )
    {
    case kNone:
    {
        TVPutButtonImage( iFilter, iReq, ID_THE_BUTTON, NULL, 0 );
    }
    break;

    case kFullScreen:
    {
        TVPutButtonImage( iFilter, iReq, ID_THE_BUTTON, NULL, 0 );

        TVSendCmd( iFilter, "tv_lockmouse 2", NULL );
        Negative( iFilter->Undo, iFilter->Current );
        TVUpdateDisplay( iFilter, iFilter->WorkArea_x1, iFilter->WorkArea_y1, iFilter->WorkArea_x2, iFilter->WorkArea_y2 );
        memcpy( iFilter->Current->Data, iFilter->Undo->Data, iFilter->Current->Width*iFilter->Current->Height*sizeof(ULONG) );
        TVSendCmd( iFilter, "tv_unlockmouse", NULL );
    }
    break;

    case kIconic:
    {
        sgToggles.mPreview->StartPreview( sgToggles.mPreview, iFilter );
        Negative( sgToggles.mPreview->mSrc, sgToggles.mPreview->mDst );
        sgToggles.mPreview->FinishPreview( sgToggles.mPreview, iFilter );
    }
    break;
    }
}


static void
Open( PIFilter* iFilter, DWORD iReq )
{
    int  x = 140;
    int  y = gStartSubWindowY;

    static int  first = 1;
    if( first )
    {
        first = 0;

        sgToggles.mType = kNone;
        sgToggles.mPreview = NULL;
    }

    TVAddButtonReq( iFilter, iReq, 0, y, 200, 20, ID_TOP_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "Preview" ); y += 20;

    x = 140;
    y = gStartSubWindowY + 25;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_FULLSCREEN, PIRBF_BUTTON_CHECK|((sgToggles.mType==kFullScreen)? PIRBF_BUTTON_SELECT:0), "Full Screen Preview" ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_ICONIC,     PIRBF_BUTTON_CHECK|((sgToggles.mType==kIconic)?     PIRBF_BUTTON_SELECT:0), "Iconic Preview"      ); y += 20;

    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y-30, 150, 20, ID_THE_BUTTON_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "What you get ..." ); y += 20;

    if( sgToggles.mPreview )
    {
        PreviewDelete( iFilter, sgToggles.mPreview );
    }
    sgToggles.mPreview = PreviewNew( iFilter, iReq, ID_THE_BUTTON, THE_BUTTON_X, THE_BUTTON_Y, THE_BUTTON_SIZE );

    if( sgToggles.mType != kNone )
    {
		if( sgToggles.mType == kFullScreen )
            TVInstallFunction( iFilter, PIDRAW_PREVIEW );
        DoPreview( iFilter, iReq );
    }
}


static void
Close( PIFilter* iFilter, DWORD iReq )
{
    TVRemoveButtonReq( iFilter, iReq, ID_TOP_LABEL );

    TVRemoveButtonReq( iFilter, iReq, ID_FULLSCREEN );
    TVRemoveButtonReq( iFilter, iReq, ID_ICONIC );

    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON_LABEL );
    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );

    if( sgToggles.mType == kFullScreen )
    {
        TVCloseFunction( iFilter );
    }

    if( sgToggles.mPreview )
    {
        PreviewDelete( iFilter, sgToggles.mPreview );
        sgToggles.mPreview = NULL;
    }
}


static int
Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    switch( iEvent )
    {
    case PICMETA_CLOSE:
        TVChangeButtonReq( iFilter, iReq, ID_FULLSCREEN, PIRBF_BUTTON_CHECK, NULL );
        TVChangeButtonReq( iFilter, iReq, ID_ICONIC,     PIRBF_BUTTON_CHECK, NULL );
        sgToggles.mType = kNone;
        return  1;

    case PICMETA_PREVIEW:
        DoPreview( iFilter, iReq );
        return  1;

    case PICBREQ_PROJECT_CHANGE:
        DoPreview( iFilter, iReq );
        return  1;

    case PICBREQ_BUTTON_UP:
    {
        switch( iArgs[0] )
        {
        case ID_FULLSCREEN:
            if( sgToggles.mType == kFullScreen )
            {
                TVCloseFunction( iFilter );
                DoPreview( iFilter, iReq );
            }
            else
            {
                TVInstallFunction( iFilter, PIDRAW_PREVIEW );
                TVChangeButtonReq( iFilter, iReq, ID_FULLSCREEN, PIRBF_BUTTON_CHECK|PIRBF_BUTTON_SELECT, NULL );
                TVChangeButtonReq( iFilter, iReq, ID_ICONIC,     PIRBF_BUTTON_CHECK,                     NULL );
                sgToggles.mType = kFullScreen;
                DoPreview( iFilter, iReq );
            }
            return  1;

        case ID_ICONIC:
            if( sgToggles.mType == kIconic )
            {
				TVChangeButtonReq( iFilter, iReq, ID_FULLSCREEN, PIRBF_BUTTON_CHECK, NULL );
				TVChangeButtonReq( iFilter, iReq, ID_ICONIC,     PIRBF_BUTTON_CHECK, NULL );
				sgToggles.mType = kNone;
                DoPreview( iFilter, iReq );
            }
            else
            {
                TVChangeButtonReq( iFilter, iReq, ID_FULLSCREEN, PIRBF_BUTTON_CHECK,                     NULL );
                TVChangeButtonReq( iFilter, iReq, ID_ICONIC,     PIRBF_BUTTON_CHECK|PIRBF_BUTTON_SELECT, NULL );
                sgToggles.mType = kIconic;
                DoPreview( iFilter, iReq );
            }
            return  1;
        }
    }
    break;
    }

    return  0;
}




DemoWindow  gPreviewWindow =
{
    Open,
    Close,
    Msg
};
