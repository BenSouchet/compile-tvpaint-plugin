

#include "plugdllx.h"
#include "demowindow.h"



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Button Subwindow


#define THE_BUTTON_X   450
#define THE_BUTTON_Y   140


#define START  2000


#define ID_TOP_LABEL         (START+001)
#define ID_THE_BUTTON_LABEL  (START+002)

#define ID_NORMAL            (START+100)
#define ID_POPUP             (START+101)
#define ID_CHECK             (START+102)
#define ID_TEXT              (START+103)
#define ID_TEXT_INT          (START+104)
#define ID_MINISLIDER        (START+105)
#define ID_HSEPARATOR        (START+106)
#define ID_VSEPARATOR        (START+107)
#define ID_FRAME             (START+108)
#define ID_HIDE              (START+109)

#define ID_IMMEDIATE         (START+120)
#define ID_REPEAT            (START+121)
#define ID_RIGHT             (START+122)

#define ID_FLAT              (START+130)
#define ID_INVERT            (START+131)
#define ID_QUIET             (START+132)
#define ID_SELECT            (START+133)

#define ID_TEXT_ACTIVE       (START+140)
#define ID_TEXT_LOCK         (START+141)

#define ID_ACTION            (START+150)
#define ID_DRAG              (START+151)
#define ID_DIALOG            (START+152)
#define ID_STAT              (START+153)

#define ID_THE_BUTTON        (START+200)



static int sgToggles[100];


static void
MakeButton( PIFilter* iFilter, DWORD iReq )
{
    int  flags = 0;
    int  w = 150;
    int  h = 20;
    char*  str = "Ga Bu Zo Meu";

    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );

    if( sgToggles[ID_NORMAL     %100] )  flags |= PIRBF_BUTTON_NORMAL;
    if( sgToggles[ID_POPUP      %100] )  flags |= PIRBF_BUTTON_POPUP;
    if( sgToggles[ID_CHECK      %100] )  flags |= PIRBF_BUTTON_CHECK, w = h = 0;
    if( sgToggles[ID_TEXT       %100] )  flags |= PIRBF_BUTTON_TEXT;
    if( sgToggles[ID_TEXT_INT   %100] )  flags |= PIRBF_BUTTON_TEXT_INT;
    if( sgToggles[ID_MINISLIDER %100] )  flags |= PIRBF_BUTTON_MINISLIDER, w = h = 0;
    if( sgToggles[ID_HSEPARATOR %100] )  flags |= PIRBF_BUTTON_HSEPARATOR;
    if( sgToggles[ID_VSEPARATOR %100] )  flags |= PIRBF_BUTTON_VSEPARATOR;
    if( sgToggles[ID_FRAME      %100] )  flags |= PIRBF_BUTTON_FRAME;
    if( sgToggles[ID_HIDE       %100] )  flags |= PIRBF_BUTTON_HIDE;
		  
    if( sgToggles[ID_IMMEDIATE  %100] )  flags |= PIRBF_BUTTON_IMMEDIATE;
    if( sgToggles[ID_REPEAT     %100] )  flags |= PIRBF_BUTTON_REPEAT;
    if( sgToggles[ID_RIGHT      %100] )  flags |= PIRBF_BUTTON_RIGHT;
		  
    if( sgToggles[ID_FLAT       %100] )  flags |= PIRBF_BUTTON_FLAT;
    if( sgToggles[ID_INVERT     %100] )  flags |= PIRBF_BUTTON_INVERT;
    if( sgToggles[ID_QUIET      %100] )  flags |= PIRBF_BUTTON_QUIET;
    if( sgToggles[ID_SELECT     %100] )  flags |= PIRBF_BUTTON_SELECT;
		  
    if( sgToggles[ID_TEXT_ACTIVE%100] )  flags |= PIRBF_BUTTON_TEXT_ACTIVE;
    if( sgToggles[ID_TEXT_LOCK  %100] )  flags |= PIRBF_BUTTON_TEXT_LOCK;
		  
    if( sgToggles[ID_ACTION     %100] )  flags |= PIRBF_BUTTON_ACTION;
    if( sgToggles[ID_DRAG       %100] )  flags |= PIRBF_BUTTON_DRAG;
    if( sgToggles[ID_DIALOG     %100] )  flags |= PIRBF_BUTTON_DIALOG;
    if( sgToggles[ID_STAT       %100] )  flags |= PIRBF_BUTTON_STAT;

    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y, w, h, ID_THE_BUTTON, flags, str );
}


static void
Open( PIFilter* iFilter, DWORD iReq )
{
    int  x = 140;
    int  y = gStartSubWindowY;

    static int  first = 1;
    if( first )
    {
        first = 0;
        sgToggles[ID_NORMAL%100] = 1;
    }

    TVAddButtonReq( iFilter, iReq, 0, y, 360, 20, ID_TOP_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "PIRBF_BUTTON_*" ); y += 20;

    x = 100;
    y = gStartSubWindowY + 25;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_NORMAL,      PIRBF_BUTTON_CHECK|(sgToggles[ID_NORMAL     %100]?PIRBF_BUTTON_SELECT:0), "NORMAL"      ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_POPUP,       PIRBF_BUTTON_CHECK|(sgToggles[ID_POPUP      %100]?PIRBF_BUTTON_SELECT:0), "POPUP"       ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_CHECK,       PIRBF_BUTTON_CHECK|(sgToggles[ID_CHECK      %100]?PIRBF_BUTTON_SELECT:0), "CHECK"       ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_TEXT,        PIRBF_BUTTON_CHECK|(sgToggles[ID_TEXT       %100]?PIRBF_BUTTON_SELECT:0), "TEXT"        ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_TEXT_INT,    PIRBF_BUTTON_CHECK|(sgToggles[ID_TEXT_INT   %100]?PIRBF_BUTTON_SELECT:0), "TEXT_INT"    ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_MINISLIDER,  PIRBF_BUTTON_CHECK|(sgToggles[ID_MINISLIDER %100]?PIRBF_BUTTON_SELECT:0), "MINISLIDER"  ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_HSEPARATOR,  PIRBF_BUTTON_CHECK|(sgToggles[ID_HSEPARATOR %100]?PIRBF_BUTTON_SELECT:0), "HSEPARATOR"  ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_VSEPARATOR,  PIRBF_BUTTON_CHECK|(sgToggles[ID_VSEPARATOR %100]?PIRBF_BUTTON_SELECT:0), "VSEPARATOR"  ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_FRAME,       PIRBF_BUTTON_CHECK|(sgToggles[ID_FRAME      %100]?PIRBF_BUTTON_SELECT:0), "FRAME"       ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_HIDE,        PIRBF_BUTTON_CHECK|(sgToggles[ID_HIDE       %100]?PIRBF_BUTTON_SELECT:0), "HIDE"        ); y += 20;
																					 
    x = 220;																		 
    y = gStartSubWindowY + 25;														 
																					 
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_IMMEDIATE,   PIRBF_BUTTON_CHECK|(sgToggles[ID_IMMEDIATE  %100]?PIRBF_BUTTON_SELECT:0), "IMMEDIATE"     ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_REPEAT,      PIRBF_BUTTON_CHECK|(sgToggles[ID_REPEAT     %100]?PIRBF_BUTTON_SELECT:0), "REPEAT"        ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_RIGHT,       PIRBF_BUTTON_CHECK|(sgToggles[ID_RIGHT      %100]?PIRBF_BUTTON_SELECT:0), "RIGHT"         ); y += 20;
    y += 20;																		 
																					 
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_FLAT,        PIRBF_BUTTON_CHECK|(sgToggles[ID_FLAT       %100]?PIRBF_BUTTON_SELECT:0), "FLAT"      ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_INVERT,      PIRBF_BUTTON_CHECK|(sgToggles[ID_INVERT     %100]?PIRBF_BUTTON_SELECT:0), "INVERT"    ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_QUIET,       PIRBF_BUTTON_CHECK|(sgToggles[ID_QUIET      %100]?PIRBF_BUTTON_SELECT:0), "QUIET"     ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_SELECT,      PIRBF_BUTTON_CHECK|(sgToggles[ID_SELECT     %100]?PIRBF_BUTTON_SELECT:0), "SELECT"    ); y += 20;
																					 
    x = 340;																		 
    y = gStartSubWindowY + 25;														 
																					 
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_TEXT_ACTIVE, PIRBF_BUTTON_CHECK|(sgToggles[ID_TEXT_ACTIVE%100]?PIRBF_BUTTON_SELECT:0), "TEXT_ACTIVE" ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_TEXT_LOCK,   PIRBF_BUTTON_CHECK|(sgToggles[ID_TEXT_LOCK  %100]?PIRBF_BUTTON_SELECT:0), "TEXT_LOCK"   ); y += 20;
    y += 40;																		 
																					 
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_ACTION,      PIRBF_BUTTON_CHECK|(sgToggles[ID_ACTION     %100]?PIRBF_BUTTON_SELECT:0), "ACTION"    ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_DRAG,        PIRBF_BUTTON_CHECK|(sgToggles[ID_DRAG       %100]?PIRBF_BUTTON_SELECT:0), "DRAG"      ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_DIALOG,      PIRBF_BUTTON_CHECK|(sgToggles[ID_DIALOG     %100]?PIRBF_BUTTON_SELECT:0), "DIALOG"    ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_STAT,        PIRBF_BUTTON_CHECK|(sgToggles[ID_STAT       %100]?PIRBF_BUTTON_SELECT:0), "STAT"      ); y += 20;

    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y-30, 150, 20, ID_THE_BUTTON_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "What you get ..." ); y += 20;
    MakeButton( iFilter, iReq );
}


static void
Close( PIFilter* iFilter, DWORD iReq )
{
    TVRemoveButtonReq( iFilter, iReq, ID_TOP_LABEL );

    TVRemoveButtonReq( iFilter, iReq, ID_NORMAL );
    TVRemoveButtonReq( iFilter, iReq, ID_POPUP );
    TVRemoveButtonReq( iFilter, iReq, ID_CHECK );
    TVRemoveButtonReq( iFilter, iReq, ID_TEXT );
    TVRemoveButtonReq( iFilter, iReq, ID_TEXT_INT );
    TVRemoveButtonReq( iFilter, iReq, ID_MINISLIDER );
    TVRemoveButtonReq( iFilter, iReq, ID_HSEPARATOR );
    TVRemoveButtonReq( iFilter, iReq, ID_VSEPARATOR );
    TVRemoveButtonReq( iFilter, iReq, ID_FRAME );
    TVRemoveButtonReq( iFilter, iReq, ID_HIDE );

    TVRemoveButtonReq( iFilter, iReq, ID_IMMEDIATE );
    TVRemoveButtonReq( iFilter, iReq, ID_REPEAT );
    TVRemoveButtonReq( iFilter, iReq, ID_RIGHT );

    TVRemoveButtonReq( iFilter, iReq, ID_FLAT );
    TVRemoveButtonReq( iFilter, iReq, ID_INVERT );
    TVRemoveButtonReq( iFilter, iReq, ID_QUIET );
    TVRemoveButtonReq( iFilter, iReq, ID_SELECT );

    TVRemoveButtonReq( iFilter, iReq, ID_TEXT_ACTIVE );
    TVRemoveButtonReq( iFilter, iReq, ID_TEXT_LOCK );

    TVRemoveButtonReq( iFilter, iReq, ID_ACTION );
    TVRemoveButtonReq( iFilter, iReq, ID_DRAG );
    TVRemoveButtonReq( iFilter, iReq, ID_DIALOG );
    TVRemoveButtonReq( iFilter, iReq, ID_STAT );

    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON_LABEL );
    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );
}


static int
Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    int  id = iArgs ? (((int)iArgs[0])%100) : 0;
    int  i, f;

    switch( iEvent )
    {
        case PICBREQ_BUTTON_UP:
        {
            if( ((int)iArgs[0])/100 == (START/100)+1 )
            {
                // clear the 'radio boxes'
                if( id < 20 )
                {
                    if( sgToggles[id] )
                        break;

                    for( i = ID_NORMAL; i < ID_IMMEDIATE; ++i )
                    {
                        TVChangeButtonReq( iFilter, iReq, i, PIRBF_BUTTON_CHECK, NULL );
                        sgToggles[i%100] = 0;
                    }
                }
                if( id >= 50  &&  id < 60 )
                {
                    if( !sgToggles[id] )
                    {
                        for( i = ID_ACTION; i < ID_STAT+1; ++i )
                        {
                            TVChangeButtonReq( iFilter, iReq, i, PIRBF_BUTTON_CHECK, NULL );
                            sgToggles[i%100] = 0;
                        }
                    }
                }

                sgToggles[id] = !sgToggles[id];
                f = sgToggles[id] ? PIRBF_BUTTON_SELECT : 0;
                TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|f, NULL );

                MakeButton( iFilter, iReq );
				return  1;
            }
        }
		break;
    }

	return  0;
}




DemoWindow  gButtonWindow =
{
    Open,
    Close,
    Msg
};
