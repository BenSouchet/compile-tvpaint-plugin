
#ifndef __demo_HH
#define __demo_HH

#include <stdio.h>


#define ARG2FLOAT(x)  (((int)iArgs[x])/65536.)


#define ID_MESSAGES        1000


extern void  DemoDrawString( PIFilter* iFilter, DWORD iReq, DWORD iID, const char* iString );

#endif
	
