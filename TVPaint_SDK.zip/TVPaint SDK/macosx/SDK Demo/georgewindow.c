

#include "plugdllx.h"
#include "demowindow.h"
#include "demo.h"



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// George Subwindow


#define THE_BUTTON_X     9
#define THE_BUTTON_Y    85
#define THE_BUTTON_W   880
#define THE_BUTTON_H   165

#define START  9000


#define ID_TOP_LABEL         (START+001)

#define ID_COMMAND           (START+100)
#define ID_EXECUTE           (START+101)
#define ID_HISTORY           (START+102)

#define ID_THE_BUTTON        (START+999)


enum  Constants
{
	kMaxHistory = 50
};


static struct
{
	char*  mHistory[kMaxHistory];

	char  mCommand[512];
} sgToggles;


static void
Open( PIFilter* iFilter, DWORD iReq )
{
    int  x = 9;
    int  y = gStartSubWindowY;

    static int  first = 1;
    if( first )
    {
		int  i;
        first = 0;

		for( i = 0; i < kMaxHistory; ++i )
		{
			sgToggles.mHistory[i] = NULL;
		}

		strcpy( sgToggles.mCommand, "" );
    }

    TVAddButtonReq( iFilter, iReq, 9, y, 80, 20, ID_TOP_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "Command :" ); y += 20;
    TVChangeButtonName( iFilter, iReq, ID_TOP_LABEL, "Command :", BUTTON_TEXT_ILEFT );

    x = 9;
    y = gStartSubWindowY + 25;
    TVAddButtonReq( iFilter, iReq, x, y, 740, 0, ID_COMMAND, PIRBF_BUTTON_TEXT,   sgToggles.mCommand   ); x += 750;
    TVAddButtonReq( iFilter, iReq, x, y,  60, 0, ID_EXECUTE, PIRBF_BUTTON_ACTION, "Execute" ); x += 70;
    TVAddButtonReq( iFilter, iReq, x, y,  60, 0, ID_HISTORY, PIRBF_BUTTON_POPUP,  "History" ); 

    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y, THE_BUTTON_W, THE_BUTTON_H, ID_THE_BUTTON, PIRBF_BUTTON_INVERT, "" );
    TVPutButtonImage( iFilter, iReq, ID_THE_BUTTON, TVAllocPIBlock( iFilter, THE_BUTTON_W, THE_BUTTON_H, 0 ), 0 );
    DemoDrawString( iFilter, iReq, ID_THE_BUTTON, "<Nothing yet>" );
}


static void
Close( PIFilter* iFilter, DWORD iReq )
{
    TVRemoveButtonReq( iFilter, iReq, ID_TOP_LABEL );

    TVRemoveButtonReq( iFilter, iReq, ID_COMMAND );
    TVRemoveButtonReq( iFilter, iReq, ID_EXECUTE );
    TVRemoveButtonReq( iFilter, iReq, ID_HISTORY );

    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );
}


static void
Execute( PIFilter* iFilter, DWORD iReq, int iHistory )
{
	int   i, j;
	char  result[512];
	char  tmp[1024];
	
	if( strlen( sgToggles.mCommand ) == 0 )
	{
		DemoDrawString( iFilter, iReq, ID_THE_BUTTON, "<<Empty command>>" );
		return;
	}

	for( i = 0; i < kMaxHistory; ++i )
	{
		if( !sgToggles.mHistory[i] )
			break;

		if( !strcmp( sgToggles.mCommand, sgToggles.mHistory[i] ) )
		{
			free( sgToggles.mHistory[i] );
			for( j = i; j < kMaxHistory-1; ++j )
			{
				sgToggles.mHistory[j] = sgToggles.mHistory[j+1];
			}
			sgToggles.mHistory[kMaxHistory-1] = NULL;
			break;
		}
	}
	
	if( sgToggles.mHistory[kMaxHistory-1] )
	{
		free( sgToggles.mHistory[kMaxHistory-1] );
	}
	
	for( i = kMaxHistory-1; i > 0; --i )
	{
		sgToggles.mHistory[i] = sgToggles.mHistory[i-1];
	}
	
	sgToggles.mHistory[0] = strdup( sgToggles.mCommand );

	strcpy( result, "<No result>" );

	strcpy( tmp, "CMD: " ); strcat( tmp, sgToggles.mCommand );
	DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );

	if( TVSendCmd( iFilter, sgToggles.mCommand, result ) )
	{
		strcpy( tmp, "RES: " ); strcat( tmp, result );
		DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );
	}
	else
	{
		DemoDrawString( iFilter, iReq, ID_THE_BUTTON, "<<Command failed>>" );
	}
}


static void
DoHistory( PIFilter* iFilter, DWORD iReq )
{
	int  i;
	int  cnt = 0;
	PIPopup  pop[kMaxHistory];

	for( i = 0; i < kMaxHistory; ++i )
	{
		if( !sgToggles.mHistory[i] )
			break;

		pop[cnt].Name  = sgToggles.mHistory[i];
		pop[cnt].ID    = i+1;
		pop[cnt].Flags = 0;

		cnt++;
	}
	
	if( cnt == 0 )
	{
		pop[0].Name  = "<Empty>";
		pop[0].ID    = 1;
		pop[0].Flags = PIPOPMODE_QUIET;
		TVPopup( iFilter, pop, 1, 0 );
		return;
	}

	i = TVPopup( iFilter, pop, cnt, 0 );

	if( i >= 1 )
	{
		strcpy( sgToggles.mCommand, sgToggles.mHistory[i-1] );
		TVPutButtonString( iFilter, iReq, ID_COMMAND, sgToggles.mCommand );
		TVChangeButtonReq( iFilter, iReq, ID_COMMAND, PIRBF_BUTTON_TEXT|PIRBF_BUTTON_TEXT_ACTIVE, NULL );
	}
}


static int
Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    switch( iEvent )
    {
        case PICBREQ_BUTTON_UP:
        {
            switch( iArgs[0] )
            {
			case ID_COMMAND:
				if( iArgs[3] == 4 ) // user pressed [ENTER]
				{
					TVGetButtonString( iFilter, iReq, ID_COMMAND, sgToggles.mCommand, 511 );
					Execute( iFilter, iReq, 1 );
					return  1;
				}
				break;

			case ID_EXECUTE:
				TVGetButtonString( iFilter, iReq, ID_COMMAND, sgToggles.mCommand, 511 );
				Execute( iFilter, iReq, 1 );
				return  1;
            }
        }
		break;

        case PICBREQ_BUTTON_DOWN:
        {
            switch( iArgs[0] )
            {
			case ID_HISTORY:
				DoHistory( iFilter, iReq );
				return  1;
            }
        }
		break;
    }
	
	return  0;
}




DemoWindow  gGeorgeWindow =
{
    Open,
    Close,
    Msg
};
