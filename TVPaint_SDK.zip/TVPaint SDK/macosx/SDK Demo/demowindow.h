


#ifndef __demowindow_HH
#define __demowindow_HH


typedef struct
{
	void  (*Open)( PIFilter* iFilter, DWORD iReq );
	void  (*Close)( PIFilter* iFilter, DWORD iReq );
	int   (*Msg)( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs );
} DemoWindow;



extern DemoWindow  gButtonWindow;
extern DemoWindow  gTextWindow;
extern DemoWindow  gPopupWindow;
extern DemoWindow  gSliderWindow;
extern DemoWindow  gMetaWindow;
extern DemoWindow  gReqWindow;
extern DemoWindow  gProjectWindow;
extern DemoWindow  gGeorgeWindow;
extern DemoWindow  gMiscWindow;
extern DemoWindow  gPreviewWindow;


extern int  gStartSubWindowY;


#endif

