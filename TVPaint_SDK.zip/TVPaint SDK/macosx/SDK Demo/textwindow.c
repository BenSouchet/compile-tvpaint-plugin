

#include "plugdllx.h"
#include "demowindow.h"



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Text Subwindow


#define THE_BUTTON_X   450
#define THE_BUTTON_Y   140


#define START  3000


#define ID_TOP_LABEL         (START+001)
#define ID_THE_BUTTON_LABEL  (START+002)

#define ID_IRIGHT   		 (START+100)
#define ID_ILEFT    		 (START+101)
#define ID_ORIGHT   		 (START+102)
#define ID_OLEFT    		 (START+103)
		 
#define ID_ITOP     		 (START+110)
#define ID_IBOTTOM  		 (START+111)
#define ID_OTOP     		 (START+112)
#define ID_OBOTTOM  		 (START+113)


#define ID_THE_BUTTON        (START+200)



static int sgToggles[100];


static void
MakeButton( PIFilter* iFilter, DWORD iReq )
{
    int  flags = 0;
    char*  str = "Ga Bu Zo Meu";

    if( sgToggles[ID_IRIGHT  %100] )  flags |= BUTTON_TEXT_IRIGHT;
    if( sgToggles[ID_ILEFT   %100] )  flags |= BUTTON_TEXT_ILEFT;
    if( sgToggles[ID_ORIGHT  %100] )  flags |= BUTTON_TEXT_ORIGHT;
    if( sgToggles[ID_OLEFT   %100] )  flags |= BUTTON_TEXT_OLEFT;
		  
    if( sgToggles[ID_ITOP    %100] )  flags |= BUTTON_TEXT_ITOP;
    if( sgToggles[ID_IBOTTOM %100] )  flags |= BUTTON_TEXT_IBOTTOM;
    if( sgToggles[ID_OTOP    %100] )  flags |= BUTTON_TEXT_OTOP;
    if( sgToggles[ID_OBOTTOM %100] )  flags |= BUTTON_TEXT_OBOTTOM;

    TVChangeButtonName( iFilter, iReq, ID_THE_BUTTON, str, flags );
}


static void
Open( PIFilter* iFilter, DWORD iReq )
{
    int  x = 140;
    int  y = gStartSubWindowY;

    TVAddButtonReq( iFilter, iReq, 0, y, 240, 20, ID_TOP_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "BUTTON_TEXT_*" ); y += 20;

    x = 100;
    y = gStartSubWindowY + 25;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_IRIGHT,  PIRBF_BUTTON_CHECK|(sgToggles[ID_IRIGHT   %100]?PIRBF_BUTTON_SELECT:0), "IRIGHT"  ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_ILEFT,   PIRBF_BUTTON_CHECK|(sgToggles[ID_ILEFT    %100]?PIRBF_BUTTON_SELECT:0), "ILEFT"   ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_ORIGHT,  PIRBF_BUTTON_CHECK|(sgToggles[ID_ORIGHT   %100]?PIRBF_BUTTON_SELECT:0), "ORIGHT"  ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_OLEFT,   PIRBF_BUTTON_CHECK|(sgToggles[ID_OLEFT    %100]?PIRBF_BUTTON_SELECT:0), "OLEFT"   ); y += 20;
																				 
    x = 220;																	 
    y = gStartSubWindowY + 25;													 
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_ITOP,    PIRBF_BUTTON_CHECK|(sgToggles[ID_ITOP     %100]?PIRBF_BUTTON_SELECT:0), "ITOP"    ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_IBOTTOM, PIRBF_BUTTON_CHECK|(sgToggles[ID_IBOTTOM  %100]?PIRBF_BUTTON_SELECT:0), "IBOTTOM" ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_OTOP,    PIRBF_BUTTON_CHECK|(sgToggles[ID_OTOP     %100]?PIRBF_BUTTON_SELECT:0), "OTOP"    ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_OBOTTOM, PIRBF_BUTTON_CHECK|(sgToggles[ID_OBOTTOM  %100]?PIRBF_BUTTON_SELECT:0), "OBOTTOM" ); y += 20;
    y += 20;

    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y-50, 150, 20, ID_THE_BUTTON_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "What you get ..." ); y += 20;
    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y, 150, 40, ID_THE_BUTTON, PIRBF_BUTTON_NORMAL, "Ga Bu Zo Meu" );
    MakeButton( iFilter, iReq );
}


static void
Close( PIFilter* iFilter, DWORD iReq )
{
    TVRemoveButtonReq( iFilter, iReq, ID_TOP_LABEL );

    TVRemoveButtonReq( iFilter, iReq, ID_IRIGHT );
    TVRemoveButtonReq( iFilter, iReq, ID_ILEFT );
    TVRemoveButtonReq( iFilter, iReq, ID_ORIGHT );
    TVRemoveButtonReq( iFilter, iReq, ID_OLEFT );
	
    TVRemoveButtonReq( iFilter, iReq, ID_ITOP );
    TVRemoveButtonReq( iFilter, iReq, ID_IBOTTOM );
    TVRemoveButtonReq( iFilter, iReq, ID_OTOP );
    TVRemoveButtonReq( iFilter, iReq, ID_OBOTTOM );
    
    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON_LABEL );
    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );
}


static int
Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    int  id = iArgs ? (((int)iArgs[0])%100) : 0;
    int  i, f;

    switch( iEvent )
    {
        case PICBREQ_BUTTON_UP:
        {
            if( ((int)iArgs[0])/100 == (START/100)+1 )
            {
                if( id >= 00  &&  id < 10 )
                {
                    if( !sgToggles[id] )
                    {
                        for( i = ID_IRIGHT; i < ID_OLEFT+1; ++i )
                        {
                            TVChangeButtonReq( iFilter, iReq, i, PIRBF_BUTTON_CHECK, NULL );
                            sgToggles[i%100] = 0;
                        }
                    }
                }

                if( id >= 10  &&  id < 20 )
                {
                    if( !sgToggles[id] )
                    {
                        for( i = ID_ITOP; i < ID_OBOTTOM+1; ++i )
                        {
                            TVChangeButtonReq( iFilter, iReq, i, PIRBF_BUTTON_CHECK, NULL );
                            sgToggles[i%100] = 0;
                        }
                    }
                }

                sgToggles[id] = !sgToggles[id];
                f = sgToggles[id] ? PIRBF_BUTTON_SELECT : 0;
                TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|f, NULL );

                MakeButton( iFilter, iReq );
            }
			return  1;
        }
		break;
    }

	return  0;
}




DemoWindow  gTextWindow =
{
    Open,
    Close,
    Msg
};
