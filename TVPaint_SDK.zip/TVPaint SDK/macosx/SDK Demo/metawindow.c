

#include "plugdllx.h"
#include "demowindow.h"
#include "demo.h"



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Meta Subwindow


#define THE_BUTTON_X   350
#define THE_BUTTON_Y    70
#define THE_BUTTON_W   500
#define THE_BUTTON_H   180

#define START  6000


#define ID_TOP_LABEL         (START+001)
#define ID_THE_BUTTON_LABEL  (START+002)

#define ID_POINT             (START+100)
#define ID_DRAW              (START+101)
#define ID_LINE              (START+102)
#define ID_RECT              (START+103)
#define ID_CIRCLE            (START+104)
#define ID_ELLIPSE           (START+105)
#define ID_PREVIEW           (START+106)

#define ID_PREVIEW_BRUSH     (START+110)
#define ID_NO_INTERPOLATION  (START+111)
#define ID_REFRESH_PREVIEW   (START+112)


#define ID_THE_BUTTON        (START+999)


static struct
{
    int  mCurrentMeta;

    int  mCurrentToggle;

    int  mPreviewBrush;
    int  mNoInterpolation;
    int  mRefreshPreview;
} sgToggles;


static void
Open( PIFilter* iFilter, DWORD iReq )
{
    int  x = 140;
    int  y = gStartSubWindowY;

    static int  first = 1;
    if( first )
    {
        first = 0;
        sgToggles.mCurrentMeta     = 0;
        sgToggles.mCurrentToggle   = 0;
        sgToggles.mPreviewBrush    = 0;
        sgToggles.mNoInterpolation = 0;
        sgToggles.mRefreshPreview  = 0;
    }

    TVAddButtonReq( iFilter, iReq, 0, y, 340, 20, ID_TOP_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "PIDRAW_*" ); y += 20;

    x = 40;
    y = gStartSubWindowY + 25;
    TVAddButtonReq( iFilter, iReq, x, y, 100, 0, ID_POINT,    PIRBF_BUTTON_NORMAL|PIRBF_BUTTON_STAT|((sgToggles.mCurrentToggle==ID_POINT  )?PIRBF_BUTTON_SELECT:0), "POINT"   ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 100, 0, ID_DRAW,     PIRBF_BUTTON_NORMAL|PIRBF_BUTTON_STAT|((sgToggles.mCurrentToggle==ID_DRAW   )?PIRBF_BUTTON_SELECT:0), "DRAW"    ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 100, 0, ID_LINE,     PIRBF_BUTTON_NORMAL|PIRBF_BUTTON_STAT|((sgToggles.mCurrentToggle==ID_LINE   )?PIRBF_BUTTON_SELECT:0), "LINE"    ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 100, 0, ID_RECT,     PIRBF_BUTTON_NORMAL|PIRBF_BUTTON_STAT|((sgToggles.mCurrentToggle==ID_RECT   )?PIRBF_BUTTON_SELECT:0), "RECT"    ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 100, 0, ID_CIRCLE,   PIRBF_BUTTON_NORMAL|PIRBF_BUTTON_STAT|((sgToggles.mCurrentToggle==ID_CIRCLE )?PIRBF_BUTTON_SELECT:0), "CIRCLE"  ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 100, 0, ID_ELLIPSE,  PIRBF_BUTTON_NORMAL|PIRBF_BUTTON_STAT|((sgToggles.mCurrentToggle==ID_ELLIPSE)?PIRBF_BUTTON_SELECT:0), "ELLIPSE" ); y += 20;

    y += 10;
    TVAddButtonReq( iFilter, iReq, x, y, 100, 0, ID_PREVIEW,  PIRBF_BUTTON_NORMAL|PIRBF_BUTTON_STAT|((sgToggles.mCurrentToggle==ID_PREVIEW)?PIRBF_BUTTON_SELECT:0), "PREVIEW" ); y += 20;

    x = 280;
    y = gStartSubWindowY + 25;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_PREVIEW_BRUSH,    PIRBF_BUTTON_CHECK|(sgToggles.mPreviewBrush?   PIRBF_BUTTON_SELECT:0), "PREVIEW_BRUSH"    ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_NO_INTERPOLATION, PIRBF_BUTTON_CHECK|(sgToggles.mNoInterpolation?PIRBF_BUTTON_SELECT:0), "NO_INTERPOLATION" ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_REFRESH_PREVIEW,  PIRBF_BUTTON_CHECK|(sgToggles.mRefreshPreview? PIRBF_BUTTON_SELECT:0), "REFRESH_PREVIEW"  ); y += 20;

    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y-30, 150, 20, ID_THE_BUTTON_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "What you get ..." ); y += 20;
    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y, THE_BUTTON_W, THE_BUTTON_H, ID_THE_BUTTON, PIRBF_BUTTON_INVERT, "" );
    TVPutButtonImage( iFilter, iReq, ID_THE_BUTTON, TVAllocPIBlock( iFilter, THE_BUTTON_W, THE_BUTTON_H, 0 ), 0 );
    DemoDrawString( iFilter, iReq, ID_THE_BUTTON, "<Nothing yet>" );
}


static void
Close( PIFilter* iFilter, DWORD iReq )
{
    TVRemoveButtonReq( iFilter, iReq, ID_TOP_LABEL );

    TVRemoveButtonReq( iFilter, iReq, ID_POINT );
    TVRemoveButtonReq( iFilter, iReq, ID_DRAW );
    TVRemoveButtonReq( iFilter, iReq, ID_LINE );
    TVRemoveButtonReq( iFilter, iReq, ID_RECT );
    TVRemoveButtonReq( iFilter, iReq, ID_CIRCLE );
    TVRemoveButtonReq( iFilter, iReq, ID_ELLIPSE );
    TVRemoveButtonReq( iFilter, iReq, ID_PREVIEW );

	TVRemoveButtonReq( iFilter, iReq, ID_PREVIEW_BRUSH );
	TVRemoveButtonReq( iFilter, iReq, ID_NO_INTERPOLATION );
	TVRemoveButtonReq( iFilter, iReq, ID_REFRESH_PREVIEW );

    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON_LABEL );
    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );
}


static void
DoSelection( PIFilter* iFilter, DWORD iReq, int iWhich, int iWhat )
{
    if( sgToggles.mCurrentToggle == iWhich )
    {
        // deselection
        sgToggles.mCurrentToggle = 0;
		sgToggles.mCurrentMeta = 0;
        TVChangeButtonFlags( iFilter, iReq, iWhich, PIRBF_BUTTON_NORMAL|PIRBF_BUTTON_STAT );
        TVCloseFunction( iFilter );
    }
    else
    {
        // selection
		int  f = iWhat;

        // first deselect current one...
        if( sgToggles.mCurrentToggle )
        {
            TVChangeButtonFlags( iFilter, iReq, sgToggles.mCurrentToggle, PIRBF_BUTTON_NORMAL|PIRBF_BUTTON_STAT );
        }

        // select new one
        sgToggles.mCurrentToggle = iWhich;
		sgToggles.mCurrentMeta = iWhat;
        TVChangeButtonFlags( iFilter, iReq, sgToggles.mCurrentToggle, PIRBF_BUTTON_NORMAL|PIRBF_BUTTON_STAT|PIRBF_BUTTON_SELECT );
		f |= sgToggles.mPreviewBrush ?    PIDRAW_PREVIEW_BRUSH :    0;
		f |= sgToggles.mNoInterpolation ? PIDRAW_NO_INTERPOLATION : 0;
		f |= sgToggles.mRefreshPreview ?  PIDRAW_REFRESH_PREVIEW :  0;
        TVInstallFunction( iFilter, f );
    }
}


static void
RedoSelection( PIFilter* iFilter, DWORD iReq )
{
	int f = sgToggles.mCurrentMeta;

	f |= sgToggles.mPreviewBrush ?    PIDRAW_PREVIEW_BRUSH :    0;
	f |= sgToggles.mNoInterpolation ? PIDRAW_NO_INTERPOLATION : 0;
	f |= sgToggles.mRefreshPreview ?  PIDRAW_REFRESH_PREVIEW :  0;
	TVInstallFunction( iFilter, f );
}


static int
Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    char  tmp[256];
	int   f = 0;

    switch( iEvent )
    {
        case PICBREQ_BUTTON_UP:
        {
            switch( iArgs[0] )
            {
            case ID_POINT:
                DoSelection( iFilter, iReq, iArgs[0], PIDRAW_POINT );
				return  1;
            case ID_DRAW:
                DoSelection( iFilter, iReq, iArgs[0], PIDRAW_DRAW );
				return  1;
            case ID_LINE:
                DoSelection( iFilter, iReq, iArgs[0], PIDRAW_LINE );
				return  1;
            case ID_RECT:
                DoSelection( iFilter, iReq, iArgs[0], PIDRAW_RECT );
				return  1;
            case ID_CIRCLE:
                DoSelection( iFilter, iReq, iArgs[0], PIDRAW_CIRCLE );
				return  1;
            case ID_ELLIPSE:
                DoSelection( iFilter, iReq, iArgs[0], PIDRAW_ELLIPSE );
				return  1;
            case ID_PREVIEW:
                DoSelection( iFilter, iReq, iArgs[0], PIDRAW_PREVIEW );
				return  1;

			case ID_PREVIEW_BRUSH:
                sgToggles.mPreviewBrush = !sgToggles.mPreviewBrush;
                f = sgToggles.mPreviewBrush ? PIRBF_BUTTON_SELECT : 0;
                TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|f, NULL );
                RedoSelection( iFilter, iReq );
				return  1;
			case ID_NO_INTERPOLATION:
                sgToggles.mNoInterpolation = !sgToggles.mNoInterpolation;
                f = sgToggles.mNoInterpolation ? PIRBF_BUTTON_SELECT : 0;
                TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|f, NULL );
                RedoSelection( iFilter, iReq );
				return  1;
			case ID_REFRESH_PREVIEW:
                sgToggles.mRefreshPreview = !sgToggles.mRefreshPreview;
                f = sgToggles.mRefreshPreview ? PIRBF_BUTTON_SELECT : 0;
                TVChangeButtonReq( iFilter, iReq, iArgs[0], PIRBF_BUTTON_CHECK|f, NULL );
                RedoSelection( iFilter, iReq );
				return  1;
            }
        }
        break;

        case PICMETA_CLOSE:
            sprintf( tmp, "PICMETA_CLOSE" );
            DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );
			return  1;

        case PICMETA_POINT:
            sprintf( tmp, "PICMETA_POINT( fx=%7.2lf, fy=%7.2lf, button=%d, pressure=%d)", ARG2FLOAT(0), ARG2FLOAT(1), (int)iArgs[2], (int)iArgs[3] );
            DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );
			return  1;

        case PICMETA_DRAW:
            sprintf( tmp, "PICMETA_DRAW( fx=%7.2lf, fy=%7.2lf, button=%d, pressure=%d)", ARG2FLOAT(0), ARG2FLOAT(1), (int)iArgs[2], (int)iArgs[3] );
            DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );
			return  1;

        case PICMETA_LINE:
            sprintf( tmp, "PICMETA_LINE( ofx=%7.2lf, ofy=%7.2lf, fx=%7.2lf, fy=%7.2lf, button=%d)", ARG2FLOAT(0), ARG2FLOAT(1), ARG2FLOAT(2), ARG2FLOAT(3), (int)iArgs[4] );
            DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );
			return  1;

        case PICMETA_RECT:
            sprintf( tmp, "PICMETA_RECT( ofx=%7.2lf, ofy=%7.2lf, fx=%7.2lf, fy=%7.2lf, button=%d)", ARG2FLOAT(0), ARG2FLOAT(1), ARG2FLOAT(2), ARG2FLOAT(3), (int)iArgs[4] );
            DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );
			return  1;

        case PICMETA_CIRCLE:
            sprintf( tmp, "PICMETA_CIRCLE( ofx=%7.2lf, ofy=%7.2lf, fr=%7.2lf, button=%d)", ARG2FLOAT(0), ARG2FLOAT(1), ARG2FLOAT(2), (int)iArgs[3] );
            DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );
			return  1;

        case PICMETA_ELLIPSE:
            sprintf( tmp, "PICMETA_ELLIPSE( ofx=%7.2lf, ofy=%7.2lf, fa=%7.2lf, fb=%7.2lf, button=%d)", ARG2FLOAT(0), ARG2FLOAT(1), ARG2FLOAT(2), ARG2FLOAT(3), (int)iArgs[4] );
            DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );
			return  1;

        case PICMETA_PREVIEW:
            sprintf( tmp, "PICMETA_PREVIEW( x=%d, y=%d, w=%d, h=%d)", (int)iArgs[0], (int)iArgs[1], (int)iArgs[2], (int)iArgs[3] );
            DemoDrawString( iFilter, iReq, ID_THE_BUTTON, tmp );
			return  1;
    }

	return  0;
}




DemoWindow  gMetaWindow =
{
    Open,
    Close,
    Msg
};
