

#include "plugdllx.h"
#include "demowindow.h"
#include "demo.h"



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Project Subwindow


#define THE_BUTTON_X   350
#define THE_BUTTON_Y    70
#define THE_BUTTON_W   500
#define THE_BUTTON_H   180

#define START  8000


#define ID_TOP_LABEL         (START+001)
#define ID_THE_BUTTON_LABEL  (START+002)

#define ID_BRUSH             (START+100)
#define ID_DISPLAY           (START+101)
#define ID_UNDO              (START+102)
#define ID_SPARE             (START+103)
#define ID_CURRENT           (START+104)
#define ID_FRONT             (START+105)
#define ID_BACK              (START+106)

#define ID_X                 (START+200)
#define ID_Y                 (START+201)
#define ID_W                 (START+202)
#define ID_H                 (START+203)

#define ID_THE_BUTTON        (START+999)




static struct
{
    int  mX;
    int  mY;
    int  mW;
    int  mH;

    int  mLayer;

} sgToggles;



static void
MakeButton( PIFilter* iFilter, DWORD iReq )
{
    int  f = 0;
	PIBlock*  block = TVGetButtonImage( iFilter, iReq, ID_THE_BUTTON, 0 );

    if( sgToggles.mLayer == ID_BRUSH   )  f = CB_READ_BRUSH;
    if( sgToggles.mLayer == ID_DISPLAY )  f = CB_READ_DISPLAY;
    if( sgToggles.mLayer == ID_UNDO    )  f = CB_READ_UNDO;
    if( sgToggles.mLayer == ID_SPARE   )  f = CB_READ_SPARE;
    if( sgToggles.mLayer == ID_CURRENT )  f = CB_READ_CURRENT;
    if( sgToggles.mLayer == ID_FRONT   )  f = CB_READ_FRONT;
    if( sgToggles.mLayer == ID_BACK    )  f = CB_READ_BACK;

	if( block )
	{
		// we don't need to check validity 'coz sgToggles.m{W,H} are bounded by the block size...
		int  x = (block->Width-sgToggles.mW)/2;
		int  y = (block->Height-sgToggles.mH)/2;
		int  ret;

		// clear the block;
		memset( block->Data, 0, block->Width*block->Height*sizeof(ULONG) );

		ret = TVReadLayerData( iFilter, block->Data + x + y*block->Width,
							   sgToggles.mX, sgToggles.mY, sgToggles.mW, sgToggles.mH,
							   block->Width - sgToggles.mW,
							   f );
		if( !ret )
		{
			DemoDrawString( iFilter, iReq, ID_THE_BUTTON, "Nothing read !!" );
		}
		TVRefreshButtonImage( iFilter, iReq, ID_THE_BUTTON, 0, 0, THE_BUTTON_W, THE_BUTTON_H );
	}
}


static void
AddTextField( PIFilter* iFilter, DWORD iReq, int iX, int iY, int iID, char* iLabel, int iVal )
{
    char  tmp[256];

    TVAddButtonReq( iFilter, iReq, iX-5,  iY,  1, 0, iID+150, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, iLabel );
    TVChangeButtonName( iFilter, iReq, iID+150, iLabel, BUTTON_TEXT_OLEFT );

    sprintf( tmp, "%d", iVal );
    TVAddButtonReq( iFilter, iReq, iX,    iY, 40, 0, iID,     PIRBF_BUTTON_TEXT_INT,   tmp );

    TVAddButtonReq( iFilter, iReq, iX+45, iY,  0, 0, iID+100, PIRBF_BUTTON_MINISLIDER, NULL );
}


static void
RemoveTextField( PIFilter* iFilter, DWORD iReq, int iID )
{
    TVRemoveButtonReq( iFilter, iReq, iID+150 );
    TVRemoveButtonReq( iFilter, iReq, iID );
    TVRemoveButtonReq( iFilter, iReq, iID+100 );
}


static void
DoMiniSlider( PIFilter* iFilter, DWORD iReq, int iID, int iDelta, int* ioVal, int iMin, int iMax )
{
    char  tmp[256];

    *ioVal += iDelta;
    if( *ioVal < iMin )
        *ioVal = iMin;
    if( *ioVal > iMax )
        *ioVal = iMax;

    sprintf( tmp, "%d", *ioVal );
    TVPutButtonString( iFilter, iReq, iID-100, tmp );

    MakeButton( iFilter, iReq );
}


static void
DoTextField( PIFilter* iFilter, DWORD iReq, int iID, int* ioVal, int iMin, int iMax )
{
    char  tmp[256];

    TVGetButtonString( iFilter, iReq, iID, tmp, 255 );
    sscanf( tmp, "%d", ioVal );
    if( *ioVal < iMin )
    {
        *ioVal = iMin;
        sprintf( tmp, "%d", *ioVal );
        TVPutButtonString( iFilter, iReq, iID, tmp );
    }
    if( *ioVal > iMax )
    {
        *ioVal = iMax;
        sprintf( tmp, "%d", *ioVal );
        TVPutButtonString( iFilter, iReq, iID, tmp );
    }

    MakeButton( iFilter, iReq );
}


static void
Open( PIFilter* iFilter, DWORD iReq )
{
    int  x = 140;
    int  y = gStartSubWindowY;

    static int  first = 1;
    if( first )
    {
        first = 0;

        sgToggles.mX = 50;
        sgToggles.mY = 50;
        sgToggles.mW = 100;
        sgToggles.mH = 100;

        sgToggles.mLayer = ID_CURRENT;
    }

    TVAddButtonReq( iFilter, iReq, 0, y, 200, 20, ID_TOP_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "CB_READ_*" ); y += 20;

    x = 140;
    y = gStartSubWindowY + 25;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_BRUSH,   PIRBF_BUTTON_CHECK|((sgToggles.mLayer==ID_BRUSH)?  PIRBF_BUTTON_SELECT:0), "BRUSH"   ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_DISPLAY, PIRBF_BUTTON_CHECK|((sgToggles.mLayer==ID_DISPLAY)?PIRBF_BUTTON_SELECT:0), "DISPLAY" ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_UNDO,    PIRBF_BUTTON_CHECK|((sgToggles.mLayer==ID_UNDO)?   PIRBF_BUTTON_SELECT:0), "UNDO"    ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_SPARE,   PIRBF_BUTTON_CHECK|((sgToggles.mLayer==ID_SPARE)?  PIRBF_BUTTON_SELECT:0), "SPARE"   ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_CURRENT, PIRBF_BUTTON_CHECK|((sgToggles.mLayer==ID_CURRENT)?PIRBF_BUTTON_SELECT:0), "CURRENT" ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_FRONT,   PIRBF_BUTTON_CHECK|((sgToggles.mLayer==ID_FRONT)?  PIRBF_BUTTON_SELECT:0), "FRONT"   ); y += 20;
    TVAddButtonReq( iFilter, iReq, x, y, 0, 0, ID_BACK,    PIRBF_BUTTON_CHECK|((sgToggles.mLayer==ID_BACK)?   PIRBF_BUTTON_SELECT:0), "BACK"    ); y += 20;

    x = 230;
    y = gStartSubWindowY + 25;
    AddTextField( iFilter, iReq, x, y, ID_X, "X",      sgToggles.mX );  y += 20;
    AddTextField( iFilter, iReq, x, y, ID_Y, "Y",      sgToggles.mY );  y += 20;
    AddTextField( iFilter, iReq, x, y, ID_W, "Width",  sgToggles.mW );  y += 20;
    AddTextField( iFilter, iReq, x, y, ID_H, "Height", sgToggles.mH );  y += 20;

    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y-30, 150, 20, ID_THE_BUTTON_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "What you get ..." ); y += 20;
    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y, THE_BUTTON_W, THE_BUTTON_H, ID_THE_BUTTON, PIRBF_BUTTON_INVERT, "" );
    TVPutButtonImage( iFilter, iReq, ID_THE_BUTTON, TVAllocPIBlock( iFilter, THE_BUTTON_W, THE_BUTTON_H, 0 ), 0 );

    MakeButton( iFilter, iReq );
}


static void
Close( PIFilter* iFilter, DWORD iReq )
{
    TVRemoveButtonReq( iFilter, iReq, ID_TOP_LABEL );

    TVRemoveButtonReq( iFilter, iReq, ID_BRUSH );
    TVRemoveButtonReq( iFilter, iReq, ID_DISPLAY );
    TVRemoveButtonReq( iFilter, iReq, ID_UNDO );
    TVRemoveButtonReq( iFilter, iReq, ID_SPARE );
    TVRemoveButtonReq( iFilter, iReq, ID_CURRENT );
    TVRemoveButtonReq( iFilter, iReq, ID_FRONT );
    TVRemoveButtonReq( iFilter, iReq, ID_BACK );

    RemoveTextField( iFilter, iReq, ID_X );
    RemoveTextField( iFilter, iReq, ID_Y );
    RemoveTextField( iFilter, iReq, ID_W );
    RemoveTextField( iFilter, iReq, ID_H );

    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON_LABEL );
    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );
}


static void
Click( PIFilter* iFilter, DWORD iReq, DWORD iWhich )
{
    int  i;

    if( (DWORD)sgToggles.mLayer == iWhich )
        return;

    for( i = ID_BRUSH; i <= ID_BACK; ++i )
    {
        TVChangeButtonReq( iFilter, iReq, i, PIRBF_BUTTON_CHECK, NULL );
    }
    TVChangeButtonReq( iFilter, iReq, iWhich, PIRBF_BUTTON_CHECK|PIRBF_BUTTON_SELECT, NULL );
    sgToggles.mLayer = iWhich;
    MakeButton( iFilter, iReq );
}


static int
Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    switch( iEvent )
    {
        case PICBREQ_PROJECT_CHANGE:
			MakeButton( iFilter, iReq );
			return  1;

        case PICBREQ_BUTTON_UP:
        {
            switch( iArgs[0] )
            {
            case ID_BRUSH:
            case ID_DISPLAY:
            case ID_UNDO:
            case ID_SPARE:
            case ID_CURRENT:
            case ID_FRONT:
            case ID_BACK:
                Click( iFilter, iReq, iArgs[0] );
				return  1;

            case ID_X:
                DoTextField( iFilter, iReq, iArgs[0], &sgToggles.mX, 0, iFilter->ImageWidth );
				return  1;
            case ID_Y:
                DoTextField( iFilter, iReq, iArgs[0], &sgToggles.mY, 0, iFilter->ImageHeight );
				return  1;
            case ID_W:
                DoTextField( iFilter, iReq, iArgs[0], &sgToggles.mW, 10, THE_BUTTON_W );
				return  1;
            case ID_H:
                DoTextField( iFilter, iReq, iArgs[0], &sgToggles.mH, 10, THE_BUTTON_H );
				return  1;
            }
        }
		break;
			
        case PICBREQ_MINISLIDER:
        {
            switch( iArgs[0] )
            {
            case ID_X+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgToggles.mX, 0, iFilter->ImageWidth );
				return  1;
            case ID_Y+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgToggles.mY, 0, iFilter->ImageHeight );
				return  1;
            case ID_W+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgToggles.mW, 10, THE_BUTTON_W );
				return  1;
            case ID_H+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgToggles.mH, 10, THE_BUTTON_H );
				return  1;
            }
        }
		break;
    }
	
	return  0;
}




DemoWindow  gProjectWindow =
{
    Open,
    Close,
    Msg
};
