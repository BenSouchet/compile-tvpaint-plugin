

#include "plugdllx.h"
#include "demowindow.h"
#include "demo.h"



////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Slider Subwindow


#define THE_BUTTON_X   450
#define THE_BUTTON_Y   140


#define START  5000


#define ID_TOP_LABEL         (START+001)
#define ID_THE_BUTTON_LABEL  (START+002)

#define ID_WIDTH             (START+100)
#define ID_HEIGHT            (START+101)

#define ID_MAXX              (START+110)
#define ID_NUMX              (START+111)
#define ID_POSX              (START+112)

#define ID_MAXY              (START+120)
#define ID_NUMY              (START+121)
#define ID_POSY              (START+122)


#define ID_THE_BUTTON        (START+999)


static struct
{
    int   mWidth;
    int   mHeight;

    int   mMaxX;
    int   mNumX;
    int   mPosX;

    int   mMaxY;
    int   mNumY;
    int   mPosY;
} sgSliderWindow;


static void
MakeButton( PIFilter* iFilter, DWORD iReq, int iChange )
{
    if( iChange )
    {
        TVChangeSliderReq( iFilter, iReq, ID_THE_BUTTON,
                           sgSliderWindow.mMaxX, sgSliderWindow.mNumX, sgSliderWindow.mPosX, 
                           sgSliderWindow.mMaxY, sgSliderWindow.mNumY, sgSliderWindow.mPosY
            );
    }
    else
    {
        TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );

        TVAddSliderReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y,
                        sgSliderWindow.mWidth, sgSliderWindow.mHeight,
                        ID_THE_BUTTON, 0,
                        sgSliderWindow.mMaxX, sgSliderWindow.mNumX, sgSliderWindow.mPosX, 
                        sgSliderWindow.mMaxY, sgSliderWindow.mNumY, sgSliderWindow.mPosY
            );
    }
}


static void
AddTextField( PIFilter* iFilter, DWORD iReq, int iX, int iY, int iID, char* iLabel, int iVal )
{
    char  tmp[256];

    TVAddButtonReq( iFilter, iReq, iX-5,  iY,  1, 0, iID+150, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, iLabel );
    TVChangeButtonName( iFilter, iReq, iID+150, iLabel, BUTTON_TEXT_OLEFT );

    sprintf( tmp, "%d", iVal );
    TVAddButtonReq( iFilter, iReq, iX,    iY, 40, 0, iID,     PIRBF_BUTTON_TEXT_INT,   tmp );
//    TVSetButtonInfoText( iFilter, iReq, iStartID+OID_MULTI,     "'Flags' field : PIPOPMODE_MULTI" );

    TVAddButtonReq( iFilter, iReq, iX+45, iY,  0, 0, iID+100, PIRBF_BUTTON_MINISLIDER, NULL );
}


static void
RemoveTextField( PIFilter* iFilter, DWORD iReq, int iID )
{
    TVRemoveButtonReq( iFilter, iReq, iID+150 );
    TVRemoveButtonReq( iFilter, iReq, iID );
    TVRemoveButtonReq( iFilter, iReq, iID+100 );
}


static void
Open( PIFilter* iFilter, DWORD iReq )
{
    int  y = gStartSubWindowY;

    static int first = 1;
    if( first )
    {
        first = 0;

        sgSliderWindow.mWidth  = 200;
        sgSliderWindow.mHeight = 20;
        
        sgSliderWindow.mMaxX = 200;
        sgSliderWindow.mNumX = 10;
        sgSliderWindow.mPosX = 50;
        
        sgSliderWindow.mMaxY = 0;
        sgSliderWindow.mNumY = 0;
        sgSliderWindow.mPosY = 0;
    }

    TVAddButtonReq( iFilter, iReq, 0, y, 340, 20, ID_TOP_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "TVAddSliderReq(...)" ); y += 20;

    y += 20;
    AddTextField( iFilter, iReq, 120, y, ID_WIDTH,  "Width",  sgSliderWindow.mWidth );  y += 20;

    y += 20;
    AddTextField( iFilter, iReq, 120, y, ID_MAXX,   "MaxX",   sgSliderWindow.mMaxX );  y += 20;
    AddTextField( iFilter, iReq, 120, y, ID_NUMX,   "NumX",   sgSliderWindow.mNumX );  y += 20;
    AddTextField( iFilter, iReq, 120, y, ID_POSX,   "PosX",   sgSliderWindow.mPosX );  y += 20;

    y = gStartSubWindowY + 20 + 20;
    AddTextField( iFilter, iReq, 300, y, ID_HEIGHT, "Height", sgSliderWindow.mHeight );  y += 20;

    y += 20;
    AddTextField( iFilter, iReq, 300, y, ID_MAXY,   "MaxY",   sgSliderWindow.mMaxY );  y += 20;
    AddTextField( iFilter, iReq, 300, y, ID_NUMY,   "NumY",   sgSliderWindow.mNumY );  y += 20;
    AddTextField( iFilter, iReq, 300, y, ID_POSY,   "PosY",   sgSliderWindow.mPosY );  y += 20;

    TVAddButtonReq( iFilter, iReq, THE_BUTTON_X, THE_BUTTON_Y-30, 150, 20, ID_THE_BUTTON_LABEL, PIRBF_BUTTON_FLAT|PIRBF_BUTTON_QUIET, "What you get ..." ); y += 20;
    MakeButton( iFilter, iReq, 0 );
}


static void
Close( PIFilter* iFilter, DWORD iReq )
{
    TVRemoveButtonReq( iFilter, iReq, ID_TOP_LABEL );

    RemoveTextField( iFilter, iReq, ID_WIDTH );
    RemoveTextField( iFilter, iReq, ID_MAXX );
    RemoveTextField( iFilter, iReq, ID_NUMX );
    RemoveTextField( iFilter, iReq, ID_POSX );
    RemoveTextField( iFilter, iReq, ID_HEIGHT );
    RemoveTextField( iFilter, iReq, ID_MAXY );
    RemoveTextField( iFilter, iReq, ID_NUMY );
    RemoveTextField( iFilter, iReq, ID_POSY );

    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON_LABEL );
    TVRemoveButtonReq( iFilter, iReq, ID_THE_BUTTON );
}


static void
DoMiniSlider( PIFilter* iFilter, DWORD iReq, int iID, int iDelta, int* ioVal, int iMin, int iMax, int iChange, int iMake )
{
    char  tmp[256];
    
    *ioVal += iDelta;
    if( *ioVal < iMin )
        *ioVal = iMin;
    if( *ioVal > iMax )
        *ioVal = iMax;

    sprintf( tmp, "%d", *ioVal );
    TVPutButtonString( iFilter, iReq, iID-100, tmp );

	if( iMake )
	{
		MakeButton( iFilter, iReq, iChange );
	}
}


static void
DoTextField( PIFilter* iFilter, DWORD iReq, int iID, int* ioVal, int iMin, int iMax, int iChange )
{
    char  tmp[256];
    
    TVGetButtonString( iFilter, iReq, iID, tmp, 255 );
    sscanf( tmp, "%d", ioVal );
    if( *ioVal < iMin )
    {
        *ioVal = iMin;
        sprintf( tmp, "%d", *ioVal );
        TVPutButtonString( iFilter, iReq, iID, tmp );
    }
    if( *ioVal > iMax )
    {
        *ioVal = iMax;
        sprintf( tmp, "%d", *ioVal );
        TVPutButtonString( iFilter, iReq, iID, tmp );
    }

    MakeButton( iFilter, iReq, iChange );
}


static int
Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    char  tmp[256];

    switch( iEvent )
    {
        case PICBREQ_BUTTON_UP:
        {
            switch( iArgs[0] )
            {
            case ID_WIDTH:
                DoTextField( iFilter, iReq, iArgs[0], &sgSliderWindow.mWidth, 20, 300, 0 );
                return  1;
            case ID_HEIGHT:
                DoTextField( iFilter, iReq, iArgs[0], &sgSliderWindow.mHeight, 20, 100, 0 );
                return  1;

            case ID_MAXX:
                DoTextField( iFilter, iReq, iArgs[0], &sgSliderWindow.mMaxX, 0, 1000, 1 );
                return  1;
            case ID_NUMX:
                DoTextField( iFilter, iReq, iArgs[0], &sgSliderWindow.mNumX, 0, 200, 1 );
                return  1;
            case ID_POSX:
                DoTextField( iFilter, iReq, iArgs[0], &sgSliderWindow.mPosX, 0, 1000, 1 );
                return  1;

            case ID_MAXY:
                DoTextField( iFilter, iReq, iArgs[0], &sgSliderWindow.mMaxY, 0, 1000, 1 );
                return  1;
            case ID_NUMY:
                DoTextField( iFilter, iReq, iArgs[0], &sgSliderWindow.mNumY, 0, 200, 1 );
                return  1;
            case ID_POSY:
                DoTextField( iFilter, iReq, iArgs[0], &sgSliderWindow.mPosY, 0, 1000, 1 );
                return  1;

            // minisliders...
            case ID_WIDTH+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], 0, &sgSliderWindow.mWidth, 20, 300, 0, 1 );
                return  1;
            case ID_HEIGHT+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], 0, &sgSliderWindow.mHeight, 20, 100, 0, 1 );
                return  1;
            }
        }
        break;

        case PICBREQ_MINISLIDER:
        {
            switch( iArgs[0] )
            {
            case ID_WIDTH+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgSliderWindow.mWidth, 20, 300, 0, 0 );
                return  1;
            case ID_HEIGHT+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgSliderWindow.mHeight, 20, 100, 0, 0 );
                return  1;

            case ID_MAXX+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgSliderWindow.mMaxX, 0, 1000, 1, 1 );
                return  1;
            case ID_NUMX+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgSliderWindow.mNumX, 0, 200, 1, 1 );
                return  1;
            case ID_POSX+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgSliderWindow.mPosX, 0, 1000, 1, 1 );
                return  1;

            case ID_MAXY+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgSliderWindow.mMaxY, 0, 1000, 1, 1 );
                return  1;
            case ID_NUMY+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgSliderWindow.mNumY, 0, 200, 1, 1 );
                return  1;
            case ID_POSY+100:
                DoMiniSlider( iFilter, iReq, iArgs[0], iArgs[1], &sgSliderWindow.mPosY, 0, 1000, 1, 1 );
                return  1;
            }
        }
        break;

        case PICBREQ_SLIDER_MOVE:
        {
            switch( iArgs[0] )
            {
            case ID_THE_BUTTON:
                sgSliderWindow.mPosX = iArgs[1];
                sgSliderWindow.mPosY = iArgs[2];
                sprintf( tmp, "%d", (int)iArgs[1] );
                TVPutButtonString( iFilter, iReq, ID_POSX, tmp );
                sprintf( tmp, "%d", (int)iArgs[2] );
                TVPutButtonString( iFilter, iReq, ID_POSY, tmp );
                return  1;
            }
        }
        break;
    }

    return  0;
}




DemoWindow  gSliderWindow =
{
    Open,
    Close,
    Msg
};
