////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// A preview "object"


#ifndef __preview_H
#define __preview_H


#include  "plugdllx.h"


typedef struct Preview
{
	DWORD  mReq;
	DWORD  mID;
	int    mX;
	int    mY;
	int    mSize;

	PIBlock*  mSrc;
	PIBlock*  mDst;

	// methods
	int  (*StartPreview)( struct Preview* ioPreview, PIFilter* iFilter );
	int  (*FinishPreview)( struct Preview* ioPreview, PIFilter* iFilter );

} Preview;


extern  Preview*  PreviewNew( PIFilter* iFilter, DWORD iReq, DWORD iID, int iX, int iY, int iSize );
extern  void      PreviewDelete( PIFilter* iFilter, Preview* iPreview );


#endif


