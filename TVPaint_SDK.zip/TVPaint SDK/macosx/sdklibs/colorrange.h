////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// A color range "object"


#ifndef __colorrange_H
#define __colorrange_H


#include  "plugdllx.h"


typedef struct ColorRange
{
    PIPixel  mColors[256];

	// methods
	void  (*Load)( struct ColorRange* ioRange, PIFilter* iFilter );
	void  (*Save)( const struct ColorRange* iRange,  PIFilter* iFilter );
	void  (*Grab)( struct ColorRange* oRange,  PIFilter* iFilter);
	
	PIBlock*  (*MakeBlock)( const struct ColorRange* iRange, PIFilter* iFilter, int iW, int iH );

} ColorRange;


extern  ColorRange*  ColorRangeNew( PIFilter* iFilter );
extern  void         ColorRangeDelete( PIFilter* iFilter, ColorRange* iRange );


#endif


