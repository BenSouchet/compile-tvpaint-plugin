/**************************************************************************************/
/**************************************************************************************/
/*                                                                                    */
/*                                     FADE                                           */
/*                                                                                    */
/**************************************************************************************/
/**************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

#include "plugdllx.h"
#include "plugx.h"

#ifdef WIN32
#include <malloc.h>
#endif

#define  CLAMP( x, a, b )  (((x)<(a)) ? (a) : (((x)>(b)) ? (b) : (x)))


////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// The heart of the filter.
// This function does the real work, everything else is just sugar
// to make it look nice in Aura.

// This function fades a block of pixels.
// mFactor = 0 : don't change anything
// mFactor = 1 : fully transparent

typedef struct
{
    double  mFactor;
} FadeParams;


static void
Fade( const PIBlock* iSrc, PIBlock* oDst, FadeParams iParams )
{
    // some sanity checks
    if( !iSrc  ||  !oDst )
        return;
    if( iSrc->Width != oDst->Width  ||  iSrc->Height != oDst->Height )
        return;

    // if there is no processing to do, just copy the pixels !
    if( iParams.mFactor == 0.0 )
	{
		// et voila !
		memcpy( oDst->Data, iSrc->Data, oDst->Height*oDst->Width*sizeof(PIPixel) );
	}

    // fully transparent, optimize !
    else if( iParams.mFactor == 1.0 )
    {
        PIPixel*  dst = oDst->Data;

        int  x, y;

        for( y = 0; y < oDst->Height; ++y )
        {
            for( x = 0; x < oDst->Width; ++x )
            {
                // this is a common trick in Aura Pixel processing.
                // if a pixel is fully tranparent, all of R, G, B and A are 0,
                // so we just assign 0x00000000 to pixel.l instead of
                // assigning all four channels separately
                dst->l = 0x00000000;
                ++dst;
            }
        }
        // in fact, in this precise case where the whole block has to be
        // cleared to fully transparent, we could even do :
        // memset( dst, 0, oDst->Height*oDst->Width*sizeof(PIPixel) );
    }

	// usual case...
    else
    {
        PIPixel*  src = iSrc->Data;
        PIPixel*  dst = oDst->Data;

        int  factor = (int)((1.0-iParams.mFactor)*256);
        int  x, y;

        for( y = 0; y < oDst->Height; ++y )
        {
            for( x = 0; x < oDst->Width; ++x )
            {
                // we do the same computation for all of R, G, B, A,
                // so we don't care which is at index 0, 1, 2 or 3
                // in most cases, however, we must care about that,
                // and use the r,g,b,a fields of the PIBlock structure
                // to index in PIBlock->c[]
                dst->c[0] = (src->c[0]*factor)>>8;
                dst->c[1] = (src->c[1]*factor)>>8;
                dst->c[2] = (src->c[2]*factor)>>8;
                dst->c[3] = (src->c[3]*factor)>>8;
                ++dst;
                ++src;
            }
        }
    }
}


////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// Aura interface


// sizes of some GUI components
#define REQUESTER_W        185
#define REQUESTER_H        83
#define POSX               103
#define SIZE               50

// ID's of GUI components
#define ID_FACTOR          10
#define ID_FACTOR_SLIDER   11
#define ID_SEP01           20
#define ID_PREVIEW         30
#define ID_SEP02           40
#define ID_APPLY           50

// ID's of the different keys
#define KEY_ID_FACTOR      10    // only the fade factor is keyable



/**************************************************************************************/
// all data needed by the plugin

static struct
{
    FadeParams  mParams;    // Fade parameters

    PIKeys*     mKeys;      // Keys

    DWORD       mReq;       // Identification of the requester.  (=0 closed, !=0 requester ID)

    void*       mLocalFile; // file containing localized messages

    int         mDoPreview; // should we do a preview ?
}
Data =
{
    { 0.0 },
    NULL,
    0,
    NULL,
    0
};


/**************************************************************************************/
//  Localisation

#define TXT_NAME            GetLocalString( iFilter, 100,    "SDK Fade" )

#define TXT_REQUESTER       GetLocalString( iFilter, 10000,  "Filter : Fade" )

#define TXT_FACTOR          GetLocalString( iFilter, 10010,  "Fade factor" )
#define TXT_PREVIEW         GetLocalString( iFilter, 10011,  "Preview" )
#define TXT_APPLY           GetLocalString( iFilter, 10012,  "Apply" )

#define TXT_HELP_FACTOR     GetLocalString( iFilter, 20010,  "Fade factor button" )
#define TXT_HELP_PREVIEW    GetLocalString( iFilter, 20011,  "Preview button" )
#define TXT_HELP_APPLY      GetLocalString( iFilter, 20012,  "Apply button" )

#define TXT_ERROR01         GetLocalString( iFilter, 30000,  "Can't Open Requester !" )


static char*
GetLocalString( PIFilter* iFilter, int iNum, char* iDefault )
{
    char*  str;

    if( Data.mLocalFile == NULL )
        return  iDefault;

    str = TVGetLocalString( iFilter, Data.mLocalFile, iNum );
    if( str == NULL  ||  strlen( str ) == 0 )
        return  iDefault;

    return  str;
}


/**************************************************************************************/
// Utility functions


// Puts the 'preview' button in the correct state
static void
DoPreviewButton( PIFilter* iFilter )
{
    if( Data.mDoPreview )
    {
        TVChangeButtonReq( iFilter, Data.mReq, ID_PREVIEW, PIRBF_BUTTON_CHECK | PIRBF_BUTTON_SELECT, NULL );
    }
    else
    {
        TVChangeButtonReq( iFilter, Data.mReq, ID_PREVIEW, PIRBF_BUTTON_CHECK, NULL );
    }
}


// Does a full screen preview
static void
DoPreview( PIFilter* iFilter )
{
    // If we don't want a preview, return !
    if( !Data.mDoPreview )
        return;

    // Send a George command to show a 'clock' mouse
    TVSendCmd( iFilter, "tv_lockmouse 2", NULL );

    // Do the computation, like usual
	if( Data.mParams.mFactor != 0.0 )
	{
		// If the processing is a 'no-op' (just copy the pixels),
		// we don't call the Fade function because in Aura,
		// iFilter->Undo and iFilter->Current always contains the same pixel values
		// when a preview is needed or when the filter has to be applied.
		Fade( iFilter->Undo, iFilter->Current, Data.mParams );
	}

    // Show the result on-screen
    TVUpdateDisplay( iFilter, iFilter->WorkArea_x1, iFilter->WorkArea_y1, iFilter->WorkArea_x2, iFilter->WorkArea_y2 );

    // Copy the data back from the 'undo' buffer in the 'current' buffer
    // This won't affect the displayed image
    memcpy( iFilter->Current->Data, iFilter->Undo->Data, iFilter->Current->Width*iFilter->Current->Height*sizeof(ULONG) );

    // Show again the normal mouse
    TVSendCmd( iFilter, "tv_unlockmouse", NULL );
}


/**************************************************************************************/
// Refresh function for the keys
// Refresh is called after a setval(), load(), moving a key, ...
// When iId==0, then all the keys have changed and must be refreshed on screen

static void
KeysRefresh( PIKeys* iKeys, int iId )
{
    // check for the correct ID (all in our case)
    if( iId == 0  ||  iId == KEY_ID_FACTOR )
    {
        iKeys->getval( iKeys, KEY_ID_FACTOR, &Data.mParams.mFactor );

        if( Data.mReq )
        {
            char  tmp[256];

            sprintf( tmp, "%.2f", Data.mParams.mFactor*100.0 );
            TVPutButtonString( (PIFilter*)iKeys->pidata, Data.mReq, ID_FACTOR, tmp );
        }
    }

    if( Data.mReq )
        DoPreview( (PIFilter*)iKeys->pidata );
}


/**************************************************************************************/
// The function to process the events of my requester.
// In this simple example this isn't really necessary, we could have
// processed all messages in PI_Msg, but this way of doing things
// is easier to extend
static int
Requester_Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    char  tmp[512];

    switch( iEvent )
    {
        case PICBREQ_OPEN:
        {
			// Build the requester.
            int  y = 5;

            Data.mReq = iReq;

            TVSetReqTitle( iFilter, Data.mReq, TXT_REQUESTER );

            // factor button
            sprintf( tmp, "%.2f", Data.mParams.mFactor*100.0 );
            TVAddButtonReq( iFilter, Data.mReq, POSX, y, SIZE, 0, ID_FACTOR, PIRBF_BUTTON_TEXT, tmp );                   // Text button
            TVAddButtonReq( iFilter, Data.mReq, POSX+SIZE+3, y, 0, 0, ID_FACTOR_SLIDER, PIRBF_BUTTON_MINISLIDER, NULL ); // Minislider
            TVPutButtonStringUnit( iFilter, Data.mReq, ID_FACTOR, "%" );                                                 // Text Unit
            TVChangeButtonName( iFilter, Data.mReq, ID_FACTOR, TXT_FACTOR, BUTTON_TEXT_OLEFT );                          // Text Align
            TVSetButtonInfoText( iFilter, Data.mReq, ID_FACTOR, TXT_HELP_FACTOR );                                       // Help Popup
			y += 20;
			
            // sep01
            TVAddButtonReq( iFilter, Data.mReq, 0, y, REQUESTER_W, 0, ID_SEP01, PIRBF_BUTTON_HSEPARATOR, NULL );
			y += 8;

            // preview button
            TVAddButtonReq( iFilter, Data.mReq, REQUESTER_W-20-9, y, 0, 0, ID_PREVIEW,
                            PIRBF_BUTTON_CHECK | ( Data.mDoPreview ? PIRBF_BUTTON_SELECT : 0), TXT_PREVIEW );
            TVSetButtonInfoText( iFilter, Data.mReq, ID_PREVIEW, TXT_HELP_PREVIEW );
			y += 20;

            // sep02
            TVAddButtonReq( iFilter, Data.mReq, 0, y, REQUESTER_W, 0, ID_SEP02, PIRBF_BUTTON_HSEPARATOR, NULL );
			y += 8;

            // apply button
            TVAddButtonReq( iFilter, Data.mReq, 9, y, REQUESTER_W-19, 0, ID_APPLY, PIRBF_BUTTON_ACTION, TXT_APPLY );
            TVSetButtonInfoText( iFilter, Data.mReq, ID_APPLY, TXT_HELP_APPLY );
			y += 20;

            DoPreview( iFilter );
        }
        break;

        case PICBREQ_CLOSE:
        {
            // requester doesn't exists anymore
            Data.mReq = 0;

            // Save the requester state (opened or closed)
            sprintf( tmp, "%d", (int)(iArgs[4]) );
            TVWriteUserString( iFilter, iFilter->PIName, "Open", tmp );

            // Save the keys
            if( Data.mKeys )
                Data.mKeys->save( Data.mKeys, NULL, iFilter->PIName );
        }
        break;

        case PICBREQ_BUTTON_UP:
        {
            switch( iArgs[0] )
            {
                case ID_FACTOR_SLIDER:
                    Data.mKeys->setval( Data.mKeys, KEY_ID_FACTOR, &Data.mParams.mFactor );
                    break;

                case ID_FACTOR:
                    TVGetButtonString( iFilter, Data.mReq, ID_FACTOR, tmp, 511 );
                    Data.mParams.mFactor = CLAMP( atof( tmp )/100.0, 0.0, 1.0 );
                    // Update the fade factor
                    Data.mKeys->setval( Data.mKeys, KEY_ID_FACTOR, &Data.mParams.mFactor );
                    break;

                case ID_PREVIEW:
                    Data.mDoPreview = !Data.mDoPreview;

                    if( Data.mDoPreview )
                    {
                        TVInstallFunction( iFilter, PIDRAW_PREVIEW );
                        DoPreview( iFilter );
                    }
                    else
                    {
                        TVCloseFunction( iFilter );
                    }

                    DoPreviewButton( iFilter );
                    break;

                case ID_APPLY:
                    if( Data.mDoPreview )
                        TVCloseFunction( iFilter );
                    TVExecute( iFilter );
                    break;
            }
        }
        break;

        case PICBREQ_MINISLIDER:
        {
            switch( iArgs[0] )
            {
                case ID_FACTOR_SLIDER:
                {
                    Data.mParams.mFactor += ((int*)iArgs)[1]/100.;
                    Data.mParams.mFactor = CLAMP( Data.mParams.mFactor, 0.0, 1.0 );
                    sprintf( tmp, "%.2f", Data.mParams.mFactor*100.0 );
                    TVPutButtonString( iFilter, Data.mReq, ID_FACTOR, tmp );
                }
                break;
            }
        }
        break;

        case PICBREQ_BUTTON_TEXT:
        {
            switch( iArgs[0] )
            {
                case ID_FACTOR:
                {
                    int  i;
                    TVGetButtonString( iFilter, Data.mReq, iArgs[0], tmp, 511 );
                    for( i = 0; tmp[i] != 0; i++ )
                    {
                        if( !isdigit( tmp[i]) )
                        {
                            memmove( &tmp[i], &tmp[i+1], strlen( &tmp[i] ) );
                            TVPutButtonString( iFilter, Data.mReq, iArgs[0], tmp );
                            break;
                        }
                    }
                }
                break;
            }
        }
        break;
    }

    return  1;
}


////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

// The functions directly called by Aura through the plugin interface



/**************************************************************************************/
// "About" function, you can also open a much nicer requester

void FAR PASCAL
PI_About( PIFilter* iFilter )
{
    char  text[256];

    sprintf( text,
             "%s V%d,%d\nby S�bastien Miglio\nCopyright TVPaint D�veloppement\n20 january 2000",
             iFilter->PIName, iFilter->PIVersion, iFilter->PIRevision );

    TVWarning( iFilter, text );
}


/**************************************************************************************/
// Function called FIRST for the initialization of the filter

int FAR PASCAL
PI_Open( PIFilter* iFilter )
{
    char  tmp[256];

    // load the .loc file
    // we don't really cares if it fails here, since we do in GetLocalString()
    Data.mLocalFile = TVOpenLocalFile( iFilter, "sdk-fade.loc", 0 );

    strcpy( iFilter->PIName, TXT_NAME );
    iFilter->PIVersion  = 1;
    iFilter->PIRevision = 0;

    // If this plugin was the one open at Aura shutdown, re-open it
    TVReadUserString( iFilter, iFilter->PIName, "Open", tmp, "0", 255 );
    if( atoi( tmp ) )
    {
        PI_Parameters( iFilter, NULL );
        DoPreview( iFilter );
    }

    return  1; // everything wen't well
}


/**************************************************************************************/
// Aura shutdown: we make all the necessary cleanup

void FAR PASCAL
PI_Close( PIFilter* iFilter )
{
    if( Data.mLocalFile )
    {
        TVCloseLocalFile( iFilter, Data.mLocalFile );
    }

    if( Data.mReq )
    {
        TVCloseReq( iFilter, Data.mReq );
    }

    if( Data.mKeys )
    {
        Data.mKeys->free( Data.mKeys );
    }
}


/**************************************************************************************/
// we have something to do !

int FAR PASCAL
PI_Parameters( PIFilter* iFilter, char* iArg )
{
    // If the keys are not created, we do it.
    if( Data.mKeys == NULL )
    {
        Data.mKeys = TVAllocKeys( iFilter, iFilter->PIName, TXT_NAME );  // Key allocation
        if( !Data.mKeys )
            return  0;

        Data.mKeys->pidata = iFilter;
        Data.mKeys->refresh = KeysRefresh; // Connect the refresh function

        Data.mParams.mFactor = 0.0;
        Data.mKeys->addparam( Data.mKeys, KEY_ID_FACTOR, TXT_FACTOR, KEY_TYPE_DOUBLE, &Data.mParams.mFactor );  // Key creation

        Data.mKeys->load( Data.mKeys, NULL, iFilter->PIName );
    }

    if( iArg )
    {
        FadeParams  saveParams = Data.mParams;

        // If this string exists, some parameters are send from an external
        // program (from George or a DDE command). In this case, DO NOT
        // open the user interface but run TVExecute() (after the
        // interpretation of the parameters in the string).

        double  val = 0.0;

        if( Data.mDoPreview )
            TVCloseFunction( iFilter );

        sscanf( iArg, "%lf", &val );

        Data.mParams.mFactor = CLAMP( val/100.0, 0.0, 1.0 );
        TVExecute( iFilter );

        Data.mParams = saveParams;
    }
    else
    {
        //char  tmp[256];
        //int   y = 5;

        // If the requester is not open, we open it.
        if( Data.mReq == 0 )
        {
            DWORD  req = TVOpenFilterReqEx( iFilter, REQUESTER_W, REQUESTER_H, Requester_Msg, Data.mKeys, PIRF_STANDARD_REQ, 0 );
            if( req == 0 )
            {
                TVWarning( iFilter, TXT_ERROR01 );
                return  0;
            }
        }
        else
        {
            TVReqToFront( iFilter, Data.mReq );
        }
    }

    return  1;
}


/**************************************************************************************/
// something happenned that needs our attention.

int FAR PASCAL
PI_Msg( PIFilter* iFilter, DWORD iEvent, DWORD iReq, DWORD* iArgs )
{
    switch( iEvent )
    {
        case PICMETA_CLOSE:
        {
			// We have to close our preview 'coz the user selected another tool.
            if( Data.mDoPreview )
            {
				Data.mDoPreview = 0;
				DoPreviewButton( iFilter );

				TVUpdateDisplay( iFilter, iFilter->WorkArea_x1, iFilter->WorkArea_y1, iFilter->WorkArea_x2, iFilter->WorkArea_y2 );
			}
        }
        break;

        case PICMETA_PREVIEW:
        {
			// We have to redo the preview 'coz the user changed something that affect it.
			// (Like changing the background mode...)
            DoPreview( iFilter );
        }
        break;
    }

    return  1;
}


/**************************************************************************************/
// Start of the 'execution' of the filter for a new sequence.
// - iNumImages contains the total number of frames to be processed.
// Here you should allocate memory that is used for all frames,
// and precompute all the stuff that doesn't change from frame to frame.

int FAR PASCAL
PI_SequenceStart( PIFilter* iFilter, int iNum )
{
    // In this simple example we don't have anything to allocate/precompute.

    // 1 means 'continue', 0 means 'error, abort' (like 'not enough memory')
    return  1;
}


// Here you should cleanup what you've done in PI_SequenceStart

void FAR PASCAL
PI_SequenceFinish( PIFilter* iFilter )
{
    // nothing special to cleanup
}


/**************************************************************************************/

int FAR PASCAL
PI_Start( PIFilter* iFilter, double iPos, double iSize )
{
    // In this simple example we don't have anything to allocate/precompute.

    // 1 means 'continue', 0 means 'error, abort' (like 'not enough memory')
    return  1;
}


void FAR PASCAL
PI_Finish( PIFilter* iFilter )
{
    // nothing special to cleanup
}


/**************************************************************************************/

int FAR PASCAL
PI_Work( PIFilter* iFilter )
{
    // Read the current value for the fade factor
    Data.mKeys->getval( Data.mKeys, KEY_ID_FACTOR, &Data.mParams.mFactor );

    // Apply the working function with the current parameters
    // iFilter->Undo is the source block (Read Only)
    // iFilter->Current is the destination block
	if( Data.mParams.mFactor != 0.0 )
	{
		// If the processing is a 'no-op' (just copy the pixels),
		// we don't call the Fade function because in Aura,
		// iFilter->Undo and iFilter->Current always contains the same pixel values
		// when a preview is needed or when the filter has to be applied.
		Fade( iFilter->Undo, iFilter->Current, Data.mParams );
	}

    TVUpdateDisplay( iFilter, iFilter->WorkArea_x1, iFilter->WorkArea_y1, iFilter->WorkArea_x2, iFilter->WorkArea_y2 );

    return  1;
}



