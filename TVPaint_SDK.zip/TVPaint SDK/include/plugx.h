/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/******************************************************************************/

// ===========================================================================
/** @file plugx.h
		
     @ingroup tvpaint90 
      @author Herv� ADAM & Eric Matecki
       $Date: 2008-07-23 09:22:06 +0200 (mer., 23 juil. 2008) $
         $Id: plugx.h 928 2008-07-23 07:22:06Z Hervé ADAM $
   @copyright (c) 1995-2008 TVPaint Developpement. All Rights Reserved.
*/
// ===========================================================================

#ifndef __plugx_HH
#define __plugx_HH


#define CB_RESERVED 128

#define CB_RESERVED1            (CB_RESERVED+1)
#define CB_EXECUTE				(CB_RESERVED+2)
#define CB_WORKON               (CB_RESERVED+3)
#define CB_WORKTRACE            (CB_RESERVED+4)
#define CB_WORKOFF              (CB_RESERVED+5)
#define CB_WARNING              (CB_RESERVED+6)
#define CB_DEMAND               (CB_RESERVED+7)
#define CB_DEMANDINT            (CB_RESERVED+8)
#define CB_DEMANDTEXT           (CB_RESERVED+9)
#define CB_UPDATEDISPLAY        (CB_RESERVED+10)
#define CB_SENDCMD              (CB_RESERVED+11)
#define CB_READLAYERDATA        (CB_RESERVED+12)
#define CB_WRITELAYERDATA       (CB_RESERVED+13)
#define CB_MAKEBRUSH     	  	(CB_RESERVED+14)
#define CB_PREVIEW_LINE         (CB_RESERVED+15)
#define CB_PREVIEW_HANDLE       (CB_RESERVED+16)

#define CB_DEMANDDOUBLE         (CB_RESERVED+17) // compil 57795
#define CB_PREVIEW_TEXT         (CB_RESERVED+18)



#define CB_OPENREQ              (CB_RESERVED+100)
#define CB_CLOSEREQ             (CB_RESERVED+101)
#define CB_SENDREQCMD           (CB_RESERVED+102)
#define CB_READREQDATA          (CB_RESERVED+103)
#define CB_WRITEREQDATA         (CB_RESERVED+104)
#define CB_OPENREQEX            (CB_RESERVED+105)
// compilation 39007
#define CB_OPENFILTERREQ        (CB_RESERVED+106) 

#define CB_OPENMETA				(CB_RESERVED+200)
#define CB_CLOSEMETA			(CB_RESERVED+201)

#define	CB_PACK_RLE				(CB_RESERVED+300)
#define	CB_UNPACK_RLE			(CB_RESERVED+301)


#define CB_POPUP				(CB_RESERVED+400)
#define	CB_COLOR_BLEND			(CB_RESERVED+500)
#define	CB_COLOR_BLEND_MODE		(CB_RESERVED+501)

#define	CB_WRITE_USER_STRING	(CB_RESERVED+600)
#define	CB_READ_USER_STRING		(CB_RESERVED+601)
#define	CB_ERASE_USER_SECTION	(CB_RESERVED+602)

#define	CB_WRITE_PROJECT_STRING		(CB_RESERVED+605)
#define	CB_READ_PROJECT_STRING		(CB_RESERVED+606)
#define	CB_ERASE_PROJECT_SECTION	(CB_RESERVED+607)

#define	CB_OPEN_STRING_FILE		(CB_RESERVED+610)
#define	CB_CLOSE_STRING_FILE	(CB_RESERVED+611)

#define	CB_READ_STRING_FILE		(CB_RESERVED+612)
#define	CB_WRITE_STRING_FILE	(CB_RESERVED+613)
#define	CB_ERASE_STRING_FILE_SECTION	(CB_RESERVED+614)

#define	CB_MAKE_IMAGE_DISPLAY	(CB_RESERVED+650)

/* compilation 31161 */
#define	CB_READ_PROJECT_IMAGE	(CB_RESERVED+651)

/* compilation 23989 */
#define	CB_READ_IMAGE			(CB_RESERVED+700)
#define	CB_ALLOC_PIBLOCK		(CB_RESERVED+710)
#define	CB_FREE_PIBLOCK			(CB_RESERVED+711)

/* compilation 25536 */
#define	CB_ALLOC_FILEREQ		(CB_RESERVED+800)
#define	CB_FREE_FILEREQ			(CB_RESERVED+801)
#define	CB_OPEN_FILEREQ			(CB_RESERVED+802)

/* compilation 29186 */
#define	CB_CREATE_ALIAS			(CB_RESERVED+820)

/* compilation 29687 */
#define	CB_WRAP_BLOCK			(CB_RESERVED+830)

/* compilation 30434 */
#define	CB_MULTITHREAD			(CB_RESERVED+840)


/* compilation 30532 */
#define	CB_ADD_DISPLAYDEVICE		(CB_RESERVED+1000)
#define	CB_ENUM_DISPLAYDEVICE		(CB_RESERVED+1001)
#define	CB_LOCK_DISPLAYDEVICE		(CB_RESERVED+1002)
#define	CB_UNLOCK_DISPLAYDEVICE		(CB_RESERVED+1003)

/* compilation 32108 */
#define	CB_LOCAL_OPEN				(CB_RESERVED+1100)
#define	CB_LOCAL_CLOSE				(CB_RESERVED+1101)
#define	CB_LOCAL_GET_STRING			(CB_RESERVED+1102)

/* compilation 32359 */
#define	CB_TEXT_TO_BLOCK			(CB_RESERVED+1200)

/* compilation 39155 */
#define	CB_ALLOC_KEYS				(CB_RESERVED+1300)

/* compilation 53076 */
#define	CB_ADD_VIDEODEVICE			(CB_RESERVED+1400)
#define	CB_ENUM_VIDEODEVICE			(CB_RESERVED+1401)

// compilation 53288
#define	CB_BLOCK_CMD				(CB_RESERVED+1500)

// compilation 53403
#define	CB_OPEN_FONT				(CB_RESERVED+1510)


// compilation 54284
#define	CB_PIXEL_CMD				(CB_RESERVED+1520)

// compilation 56803
#define	CB_DDBLIT					(CB_RESERVED+1530)

// compilation 57632
#define CB_OPEN_IMAGESEQUENCE		(CB_RESERVED+1540)
#define CB_ALLOC_PROFILE			(CB_RESERVED+1550)

//TVPaint 7
#define CB_HUD_CMD					(CB_RESERVED+1560)

//TVPaint 7.5
#define CB_PICK_COLOR				(CB_RESERVED+1570)

//TVPaint 8.0
#define	CB_GET_IMAGE_ID				(CB_RESERVED+1580)


//----------------------------------
// HUD CMD
#define PIHUDCMD_REDRAW			0
#define PIHUDCMD_LINE			1       
#define PIHUDCMD_SPLINE			2       
#define PIHUDCMD_TEXT			3       
#define PIHUDCMD_HANDLE			4       
#define PIHUDCMD_IMAGE			5


//----------------------------------
// BLOCK CMD
#define PIBCMD_STRETCH			1       // 1, src,dst
#define PIBCMD_BLUR				2       // 2, blck, w., h.

//----------------------------------
// PIXEL CMD
#define PIBCMD_RGBA_TO_YUV		1       // iRGBA,oYUV,(oAlpha),width
#define PIBCMD_YUV_TO_RGBA		2       // iYUV,iALPHA,oRGBA, w,
#define PIBCMD_RGBA_UNMULTIPLY	3       // iRGBA, oRGBA, w
#define PIBCMD_RGBA_PREMULTIPLY	4       // iRGBA, oRGBA, w

//----------------------------------
// TAG REQ
#define PIRT_INFO					1       /* * (32 tags) id  -> tag 2 3 4 5 -> x,y,w,h*/
#define PIRT_NAME					2       /* * id, name*/
#define PIRT_FRONT					3       /* * id   ->to front*/
#define PIRT_BACK					4       /* * id   ->to back*/
#define PIRT_MOVE					5       /* * id,x,y,   ->to back*/
#define PIRT_RESIZE					6		/* * req id x y w h */
#define PIRT_ADD_BUTTON				10      /* * id,x,y,w,h,type*/
#define PIRT_REMOVE_BUTTON			11      /* * id*/
#define PIRT_CHANGE_BUTTON			12      /* * id,flag */
#define PIRT_SET_INFO_TEXT			13      /* * id, *text */
#define PIRT_TEXT					20      /* * text,x,y,gmode,apen,bpen*/
#define PIRT_RECT					21      /* * x2,y2,x2,y2,gmode,color*/
#define PIRT_AADRAW					22      /* * x2,y2,x2,y2,r1,r2,gmode,color,cx1,cy1,cx2,cy2*/
#define PIRT_GET_BUTTON_STRING		24      /* * req,id,string,maxchar*/
#define PIRT_PUT_BUTTON_STRING		25      /* * req,id,string*/
#define PIRT_GRAB_COORD				26      /* * req, on/off */
#define PIRT_TEXT_CLIP				27      /* * text,x,y,gmode,apen,bpen,clipx1,clipy1,clipx2,clipy2*/
#define PIRT_GRAB_TICKS				28      /* * req, on/off */
#define PIRT_TEXT_LENGTH			29      /* * text,size*/
#define PIRT_PUT_BUTTON_UNIT		30		/* * id, *text */
#define PIRT_PUT_BUTTON_IMAGE		31		/* * req, id, PIBlock, flags */
#define PIRT_ADD_SLIDER				32		/* * req x y w h id flags maxx numx posx maxy numy posy*/
#define PIRT_CHANGE_SLIDER			33		/* * req id maxx numx posx maxy numy posy */
#define PIRT_CHANGE_BUTTON_NAME		34      /* * id, name*/
#define PIRT_CHANGE_BUTTON_FLAGS	35      /* * id, flags*/
#define PIRT_ADD_TABS				36		/* * req x y w h id num current names */
#define PIRT_CHANGE_TABS			37		/* * req id pos */
#define PIRT_GET_BUTTON_IMAGE		38		/* * req, id */
#define PIRT_REFRESH_BUTTON_IMAGE	39		/* * req, id, int x, int y, int w, int h */
#define PIRT_COMPASS_OPEN			40		/* * req, id, double val */
#define PIRT_COMPASS_CHANGE			41		/* * double val */
#define PIRT_COMPASS_CLOSE			42		/* * void */
#define PIRT_ADD_VIDEO_BUTTON		43		/* * iReq, iX, iY, iW, iH, iID, iVDev, iVMode  */
#define PIRT_SAVE_REQ_STATE			44		/* * iReq, iSection, iSubSection  */
#define PIRT_LOAD_REQ_STATE			45		/* * iReq, iSection, iSubSection  */
#define PIRT_DISPLAY_REQ			46		/* * iReq, Show/Hide  */


#endif //__plugx_HH
