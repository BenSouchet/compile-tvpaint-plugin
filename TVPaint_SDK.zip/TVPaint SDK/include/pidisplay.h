/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/******************************************************************************/

// ===========================================================================
/** @file pidisplay.h
		
     @ingroup tvpaint90
      @author Herv� ADAM & Eric Matecki
       $Date: 2008-07-23 09:22:06 +0200 (mer., 23 juil. 2008) $
         $Id: pidisplay.h 928 2008-07-23 07:22:06Z Hervé ADAM $
   @copyright (c) 2001-08 TVPaint Developpement. All Rights Reserved.
*/
// ===========================================================================

#ifndef __pidisplay_HH
#define __pidisplay_HH


#define	PIDISPLAY_VERSION 300	// TVPaint 65

#ifndef __videodevice_HH
#include "videodevice.h"
#endif


typedef	struct PIDisplay
{
	int	Version;				// plugins support
	const char *DeviceName;
	int	Width, Height;
	int	MinWidth, MinHeight;
	int	MaxWidth, MaxHeight;
	double AspectRatio;			// y_bitmap * AspectRatio = y_screen

	unsigned long	Flags;

	int		(*OpenDisplay) (struct PIDisplay *display, int Width, int Height);
	void	(*CloseDisplay)(struct PIDisplay *display);
	int		(*WritePIBlock)(struct PIDisplay *display, const PIBlock *source, int source_x, int source_y, int dest_x, int dest_y, int width, int height, unsigned long mode);
	int		(*WritePixel)  (struct PIDisplay *display, int dest_x, int dest_y, ULONG color, unsigned long mode);
	int		(*Clear)       (struct PIDisplay *display, ULONG color);
	int		(*RectFill)	   (struct PIDisplay *display, int dest_x, int dest_y, int width, int height, ULONG color, unsigned long mode);

	// Since AURA2.1: Version 200
	int		(*Cmd)(struct PIDisplay *, const char *cmd, char *result);
	int		(*WriteVideoBlock)  (struct PIDisplay *display, const VideoBlock *source, int source_x, int source_y, int dest_x, int dest_y, int width, int height);
	int		(*StretchVideoBlock)(struct PIDisplay *display, const VideoBlock *source, double source_x, double source_y, int dest_x, int dest_y, int dest_width, int dest_height, double ratio_x, double ratio_y);

	// Synchronous output
	int		(*OpenOutput)(struct PIDisplay *display);
	double	(*OutputVideoBlock)(struct PIDisplay *display, const VideoBlock *source, int dest_width, int dest_height);
	int		(*CloseOutput)(struct PIDisplay *display);

	// get the best video mode
	int		(*BestVideoMode)(struct PIDisplay *display, VideoInfo *oInfo);

	// Since Mirage1.2: Version 300
	//Enum video mode
	int		(*EnumVideoMode)( struct PIDisplay* display, int iMode, VideoInfo* oInfo );
	int		(*GetCurrentVideoMode)( struct PIDisplay* display );
	void	(*SetCurrentVideoMode)( struct PIDisplay* display, int iMode );

	ULONG	reserved[1017];		// must be 0
	
}PIDisplay;


#define	PIDISPLAY_MODE_COPY 0
#define	PIDISPLAY_MODE_EOR 1






#endif //pidisplay_HH
