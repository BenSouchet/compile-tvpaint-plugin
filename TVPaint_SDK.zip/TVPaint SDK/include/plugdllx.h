/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/******************************************************************************/

// ===========================================================================
/** @file plugdllx.h

     @ingroup tvpaint90
      @author Herv� ADAM & Eric Matecki
       $Date: 2010-03-24 14:42:35 +0100 (mer., 24 mars 2010) $
         $Id: plugdllx.h 2906 2010-03-24 13:42:35Z Hervé $
   @copyright (c) 1995-2008 TVPaint Developpement. All Rights Reserved.
*/
// ===========================================================================

#ifndef __plugdllx_HH
#define __plugdllx_HH


#ifdef __cplusplus
extern "C" {
#endif

#if	!defined(__NT__) && (defined(WIN32) || defined(_WIN32) || defined(WIN64) || defined(_WIN64) )
	#define	__NT__
#endif

#if	defined(WIN64) && !defined(_WIN64)
	#define	_WIN64
#endif

#ifndef	TVCHAR
// #define	TVCHAR unsigned char
#define	TVCHAR char
#endif

#ifdef CASABLANCA
	#define	STRNICMP	//on le defini toujours sous casa, puisque les 2 fonctions sont faites a la main dans casablanca.h/.cpp
#endif

#ifdef	__NT__

#include <windows.h>
#define	STRNICMP

#else

#define	FAR
#define	WINAPI
#define	PASCAL
#define	HANDLE	void *
#define	DWORD	int//unsigned long // min sizeof(pointer)
#define FARPROC INTPTR (*)()

#endif


/** Integral Ptr. Used to cast ptr to arithmetic type. */
#if defined(WIN64)

#define  INTPTR unsigned _int64

#elif defined(WIN32)

#define  INTPTR unsigned int __w64

#elif defined (_LP64)

#define INTPTR long long

#else

#define INTPTR int

#endif


#include	<stdlib.h>
#include	<string.h>
#include	"pikeys.h"


// ANSI/UNIX compatibility
#ifndef	STRNICMP
#define	strnicmp strncasecmp
#define	stricmp strcasecmp
#else
#define	strncasecmp strnicmp
#define	strcasecmp stricmp
#endif


#ifndef INT32
#define INT32 int
#endif

#ifndef	ULONG
#define	ULONG	unsigned int // pixel 4 bytes
#endif

#ifndef	ULONG32
#define	ULONG32	unsigned int // pixel 4 bytes
#endif


#ifndef MAX
#define	MAX(a, b) ((a)<(b) ? (b) : (a))
#define	MIN(a, b) ((a)>(b) ? (b) : (a))
#endif

#ifndef ABS
#define	ABS(a) ((a)<0 ? -(a) : (a))
#endif




// version 5.00 for TVPaint 5   / Aura 1.0
// version 5.01 for TVPaint 5.1 / Aura 1.0c
// version 6.00 for TVPaint 6   / Aura 2
// version 6.05 for TVPaint 6.5 / Aura 2.5
// version 6.06 for TVPaint 6.6 / Aura 2.5b
// version 7.00 for	TVPaint 7	(Mirage 1.0)
// version 7.01 for	TVPaint 7.1 (Mirage 1.01)
// version 7.02 for	TVPaint 7.2 (Mirage 1.50)
// version 7.05 for	TVPaint 8.0 (Animation)
// version 8.00 for	TVPaint 8.1 (Animation)
// version 9.00 for	TVPaint 9.0 (Animation)
#define PI_VERSION	9
#define PI_REVISION 0

#define CALLBACK_VERSION	1
#define CALLBACK_REVISION	0

typedef union PIPixel
{
    ULONG32   l;
    unsigned char   c[4];
#ifdef MACOSX
    struct
    {
        unsigned char Alpha;
        unsigned char Red;
        unsigned char Green;
        unsigned char Blue;
    };
#endif
#ifdef __NT__
    struct
    {
        unsigned char Blue;
        unsigned char Green;
        unsigned char Red;
        unsigned char Alpha;
    };
#endif
#ifdef LINUX
    struct
    {
        unsigned char Alpha;
        unsigned char Red;
        unsigned char Green;
        unsigned char Blue;
    };
#endif
} PIPixel;

/*----------------------------------*/
/* functions PI_Msg*/
#define PICBREQ_OPEN                    100     /* x,y,w,h            -> x,y,w and h are id window parameters when opening */
#define PICBREQ_CLOSE                   101     /* x,y,w,h,shutdown   -> x,y,w and h are id window parameters when quitting */
#define PICBREQ_DRAG                    102     /* x,y                -> x and y are new coords of the window id */
#define PICBREQ_KEY_DOWN                103     /* ascii              -> gives the key pressed (all non already assigned keys :) watch out, each opened window will receive this message */
#define PICBREQ_FKEY_DOWN               104     /* (ctrl)function key -> same as upper, but with function keys */

#define PICBREQ_RESIZE                  105     /* w, h, x, y */
#define PICBREQ_BUTTON_TEXT             106     /* */
#define PICBREQ_RESIZED                 107     /* w, h, x, y */
#define PICBREQ_PROJECT_CHANGE          110     /* remake preview, no arguments */
#define	PICBREQ_PROJECT_INACTIVATE		111		/* inactivate current project */
#define	PICBREQ_PROJECT_ACTIVATE		112		/* activate current project */
#define PICBREQ_HIDE	                113     /* */
#define PICBREQ_SHOW	                114     /* */
#define PICBREQ_COLLAPSE	            115     /* */
#define PICBREQ_UNCOLLAPSE	            116     /* */


#define PICBREQ_FILE_RESET				120     /* reset keys v2*/
#define PICBREQ_FILE_LOAD				121     /* load keys v2*/
#define PICBREQ_FILE_SAVE				122     /* save keys v2*/
#define PICBREQ_FILE_SAVE_AS			123     /* save_as keys v2*/
/******************/

#define PICBREQ_BUTTON_DOWN             200     /* req button ,x, y, mouse button, pressure, time (millisecondes), key ctrl*/
#define PICBREQ_BUTTON_UP               201     /* req button ,x, y, mouse button, pressure,time (millisecondes), key ctrl*/
#define PICBREQ_MOVE                    202     /* req button ,x, y, mouse button, pressure, time (millisecondes), key ctrl*/
#define PICBREQ_COORD                   210     /* mouse button ,x, y, screenx, screeny, pressure, time (millisecondes), key ctrl, reqx,reqy*/
#define PICBREQ_TICKS                   211     /* mouse button ,x, y, screenx, screeny, pressure, time (millisecondes), key ctrl, reqx, reqy, isiconic*/
#define PICBREQ_MINISLIDER              212     /* button id,delta, time (millisecondes), key ctrl*/
#define PICBREQ_SLIDER_MOVE             213     /* button id, posx,posy,mouse button,time (millisecondes), key ctrl */
#define PICBREQ_SLIDER_RELEASE          214     /* button id, posx,posy,mouse button,time (millisecondes), key ctrl */
#define PICBREQ_TABS_CHANGE				215     /* button id, tab,time (millisecondes), key ctrl */

#define PICBREQ_VIDEO_CHANGE_PREV		220     /* NULL */
#define PICBREQ_VIDEO_CHANGE			221     /* NULL */


#define PICB_HUD_REDRAW					300
#define PICB_PICK_COLOR					310     /* posx, posy, mouse button, pressure, ctrl, color */
#define	PICBREQ_ROOM_CHANGE				320		/* room name */


/*   meta function messages */
#define PICMETA_CLOSE                   1000    /**/
#define PICMETA_POINT                   1001    /* FX,FY,b,p*/
#define PICMETA_DRAW                    1002    /* FX,FY,b,p, ctrl   // left (1,-1), right (2,-2)*/
#define PICMETA_LINE                    1003    /* OFX,OFY,FX,FY,b*/
#define PICMETA_RECT                    1004    /* OFX,OFY,FX,FY,b*/
#define PICMETA_CIRCLE                  1005    /* OFX,OFY,FR,b*/
#define PICMETA_ELLIPSE                 1006    /* OFX,OFY,FA,FB,b*/
#define PICMETA_PREVIEW					1007    /* X Y W H */
#define PICMETA_KEYBOARD				1008    /* int Code, char* Buffer, int BufSize, int Qualifier, int MouseButtons */

/*----------------------------------*/
/* init MetaFunction*/
#define	PIDRAW_POINT					0
#define	PIDRAW_DRAW						1
#define	PIDRAW_LINE						2
#define	PIDRAW_RECT						3
#define	PIDRAW_CIRCLE					4
#define	PIDRAW_ELLIPSE					5
#define	PIDRAW_SPLINE					6
#define	PIDRAW_PREVIEW					7

#define	PIDRAW_FONC_MASK				0xffff
#define	PIDRAW_PREVIEW_BRUSH			(1<<16)
#define	PIDRAW_NO_INTERPOLATION			(1<<17)
#define	PIDRAW_REFRESH_PREVIEW			(1<<18)
#define	PIDRAW_KEYBOARD					(1<<19)

/*----------------------------------*/
#define	PITICKS_FLAG_OFF				(0)
#define	PITICKS_FLAG_ON					(1)
#define	PITICKS_FLAG_NO_WAIT			(666) // only with PIRF_LOCK_REQ
/*----------------------------------*/
/* ReadLayerData*/
#define CB_READ_BRUSH   				-4
#define CB_READ_DISPLAY 				-3
#define CB_READ_UNDO    				-2
#define CB_READ_SPARE   				-1
#define CB_READ_CURRENT 				0
#define CB_READ_FRONT					1
#define CB_READ_BACK					3

/*----------------------------------*/
/* WriteLayerData*/
#define CB_WRITE_QUIET					0
#define CB_WRITE_UPDATE					1

/*----------------------------------*/
/* FLAG BUTTON*/
#define PIRBF_BUTTON_NORMAL             (1<<0)
#define PIRBF_BUTTON_IMMEDIATE          (1<<1)
#define PIRBF_BUTTON_INVERT             (1<<2)
#define PIRBF_BUTTON_HIDE               (1<<3)
#define PIRBF_BUTTON_QUIET              (1<<4)
#define PIRBF_BUTTON_RIGHT              (1<<5)
#define PIRBF_BUTTON_REPEAT             (1<<6)
#define PIRBF_BUTTON_SELECT             (1<<7)

#define PIRBF_BUTTON_POPUP              (1<<8)
#define PIRBF_BUTTON_FLAT               (1<<9)
#define PIRBF_BUTTON_TEXT               (1<<10)
#define PIRBF_BUTTON_TEXT_INT           (1<<11)
#define PIRBF_BUTTON_TEXT_ACTIVE        (1<<12) /* for PIRBF_BUTTON_TEXT */

#define PIRBF_BUTTON_ACTION             (1<<13)
#define PIRBF_BUTTON_DRAG               (1<<14)
#define PIRBF_BUTTON_DIALOG             (1<<15)
#define PIRBF_BUTTON_STAT               (1<<16)
#define PIRBF_BUTTON_TEXT_LOCK          (1<<17) /* lock edition */
#define PIRBF_BUTTON_CHECK              (1<<18)
#define PIRBF_BUTTON_MINISLIDER         (1<<19)
#define PIRBF_BUTTON_HSEPARATOR         (1<<20)
#define PIRBF_BUTTON_VSEPARATOR         (1<<21)
#define PIRBF_BUTTON_FRAME              (1<<22)


/*----------------------------------*/
/* slider flags */
#define	PIRBF_SLIDER_HORIZONTAL (1<<0)
#define	PIRBF_SLIDER_VERTICAL	(1<<1)

/*----------------------------------*/
/* FLAG REQ*/
#define PIRF_STANDARD_REQ        (0)  /* drag+quit+depth */
#define PIRF_LOCK_REQ            (1<<0)  /* Lock*/
#define PIRF_NO_DRAG_REQ         (1<<1)  /* no move */
#define PIRF_NO_DEPTH_REQ        (1<<2)  /* no depth */
#define PIRF_NO_CLOSE_REQ        (1<<3)  /* no close */
#define PIRF_NO_SYSBUTTON_REQ	 (PIRF_NO_CLOSE_REQ|PIRF_NO_DEPTH_REQ|PIRF_NO_DRAG_REQ)
#define PIRF_CENTER_REQ          (1<<4)
#define PIRF_KEYGRAB_REQ         (1<<5)  /* only 456789 and ctrl F1-F12 */
#define PIRF_RESIZE_REQ          (1<<6)  /* button resize */
#define PIRF_HIDDEN_REQ			 (1<<19) /* invisible */
#define PIRF_COLLAPSABLE_REQ     (1<<20) /* button collapse */
#define PIRF_COLLAPSED_REQ		 (1<<21) /* collapsed */
#define PIRF_BINABLE_REQ		 (1<<23) /* binable */

/*----------------------------------*/
/* FLAG TEXT / gfx in req*/
#define PIGMODE_COLOR     (0)
#define PIGMODE_TRANS     (1<<0)
#define PIGMODE_REQBG     (1<<1)
#define PIGMODE_BUTBG     (1<<2)
#define PIGMODE_INVERT    (1<<3)


/*----------------------------------*/

#define	BUTTON_TEXT_ILEFT		(1<<0)	// inside left
#define	BUTTON_TEXT_IRIGHT		(1<<1)	// inside right
#define	BUTTON_TEXT_OLEFT		(1<<2)	// outside left
#define	BUTTON_TEXT_ORIGHT		(1<<3)	// outside right

#define	BUTTON_TEXT_ITOP		(1<<4)	//  inside top
#define	BUTTON_TEXT_IBOTTOM		(1<<5)	//  inside bottom
#define	BUTTON_TEXT_OTOP		(1<<6)	//  outside top
#define	BUTTON_TEXT_OBOTTOM		(1<<7)	//  outside bottom

/*----------------------------------*/
#define	PIPOPMODE_SEPARATOR (1<<0)
#define	PIPOPMODE_USE_APEN  (1<<1)
#define	PIPOPMODE_QUIET     (1<<2)
#define	PIPOPMODE_CHECK     (1<<3)
#define	PIPOPMODE_GHOST     (1<<4)
#define	PIPOPMODE_MULTI     (1<<5)

typedef struct  PIPopup
{
	const char 	*Name;
	int 	ID;				// >0 normal, < 0 not setectable
	INTPTR	Flags;
	int 	APen;
	INTPTR	Reserved[9];
} PIPopup;

/*----------------------------------*/
//wrap & color blend mode
#define	PIWRAP_MODE_BLEND		0
#define	PIWRAP_MODE_ADD			1
#define	PIWRAP_MODE_SUB			2
#define	PIWRAP_MODE_PRESERVE	3 //behind
#define	PIWRAP_MODE_MULTIPLY	4
#define	PIWRAP_MODE_SCREEN		5
#define	PIWRAP_MODE_REPLACE		6
#define	PIWRAP_MODE_COLORIZE	7
#define	PIWRAP_MODE_HUE         8
#define	PIWRAP_MODE_ERASE		9
#define	PIWRAP_MODE_SHADE		10
#define	PIWRAP_MODE_LIGHT		11
#define	PIWRAP_FAST				(1<<16)

/*----------------------------------*/

typedef struct  PIBlock
{
	INT32 	Width, Height;	// block size
	char  	r,g,b,a;		// offsets
	PIPixel *Data;			// Pixels Data
	INT32 	x,y;			// not used
	PIPixel	**Img;			// pixel=block->Img[y][x];
	void	(*free) (struct  PIBlock *);			// destroy
	void	(*clear)(struct  PIBlock *, ULONG32 col); // fill
	INTPTR	Reserved[1];	// reserved
} PIBlock;



#define PIFILTER_FLAG_HIDDEN (1<<0)

/*----------------------------------*/

typedef struct PIFilter
{
/*------------------- Public Plug In -------------------*/
	/* Host Info*/
	INT32   Version;
	INT32   Revision;
	TVCHAR ProgName[128];

	/* PlugIn Info*/
	INT32   PIVersion;
	INT32   PIRevision;
	TVCHAR PIName[128];

	void	*UserParametersPtr;
	int   UserParametersSize;


#ifdef	__NT__
	FARPROC	CallBack;
	INTPTR   TVWindow; // Windows HWND
#else
	INTPTR   (*CallBack)(struct PIFilter *, INTPTR , INTPTR *);
    void*   TVWindow;
#endif

	INT32   ScreenWidth, ScreenHeight;
	INT32   ImageWidth, ImageHeight;
	INT32	Reserved0;

	INT32	WorkArea_x1,WorkArea_y1,WorkArea_x2,WorkArea_y2;

	char    PlaneOffsetRed;
	char    PlaneOffsetGreen;
	char    PlaneOffsetBlue;
	char    PlaneOffsetAlpha;

	PIBlock *Current;  // Current Image Read/Write
	PIBlock *Undo;     // Current Image Read Only

	TVCHAR *ProgDir;
	TVCHAR *TempDir;

	INT32   BrushWidth, BrushHeight;

	void	*Reserved1;

	int		FilterFlags; //new Version 7.0


} PIFilter;


/*----------------------------------*/
/*----------------------------------*/
typedef struct  PIFileInfo
{
	int MaxIconSize;	// >= max(Width,Height)
	PIBlock	*Icon;
	TVCHAR TextInfo[2048];
	INTPTR	Reserved[16];
}PIFileInfo;


typedef struct  PIFileReq
{
	void	*Private;		// NULL
	TVCHAR 	*Title;			// "<Load" / ">Save"
	TVCHAR 	Pattern[4096];	// "*"
	TVCHAR	Path[8192];		// "/usr/user/herve/elephant/babar.jpg"
	int		Icon;			// 0/1 On/Off
#ifdef	__NT__
	FARPROC Info;
#else
	int	(*Info)(PIFilter *PiFilter, int full, TVCHAR *name, PIFileInfo *fileinfo);
#endif
	INTPTR	Reserved[16];	// fill with 0
} PIFileReq;

//----------------------------------
//----------------------------------
// TVPreviewLine() TVPreviewHandle()

#define	PREVLINE_RESTORE	0
#define	PREVLINE_INVERT		(1<<0)
#define	PREVLINE_NO_FIRST	(1<<1)
#define	PREVLINE_CHECK		(1<<2)
#define	PREVLINE_CROSS		(1<<3)
#define	PREVLINE_SELECTION	(1<<4)


// TVPreviewLine()
#define	PREVTEXT_RESTORE	0
#define	PREVTEXT_INVERT		(1<<0)

#define	PREVTEXT_HANDLE_BS		0		// Base Line
#define	PREVTEXT_HANDLE_TOP		(1<<16)
#define	PREVTEXT_HANDLE_BOTTOM	(1<<17)
#define	PREVTEXT_HANDLE_LEFT	(1<<18)
#define	PREVTEXT_HANDLE_RIGHT	(1<<19)


//HUD
#define HUD_TEXT_CENTER	0
#define HUD_TEXT_TOP	(1<<0)
#define HUD_TEXT_BOTTOM (1<<1)
#define HUD_TEXT_LEFT   (1<<2)
#define HUD_TEXT_RIGHT  (1<<3)


#define HUD_HANDLE_SQUARE 0
#define HUD_HANDLE_CROSS  1
#define HUD_HANDLE_PLUS	  2
#define HUD_HANDLE_CIRCLE 3
#define HUD_HANDLE_UP     4
#define HUD_HANDLE_DOWN   5
#define HUD_HANDLE_LEFT   6
#define HUD_HANDLE_RIGHT  7

//----------------------------------
//         PlugIn functions
//----------------------------------
int  FAR PASCAL PI_Open(PIFilter *);
void FAR PASCAL	PI_About(PIFilter *);
int  FAR PASCAL	PI_Parameters(PIFilter *, char *args);
int  FAR PASCAL PI_Msg(PIFilter *, INTPTR, INTPTR, INTPTR *);
void FAR PASCAL	PI_Close(PIFilter *);

int  FAR PASCAL	PI_SequenceStart(PIFilter *, int size);
int  FAR PASCAL	PI_Start(PIFilter *, double pos, double size);
int  FAR PASCAL	PI_Work(PIFilter *);
void FAR PASCAL	PI_Finish(PIFilter *);
void FAR PASCAL	PI_SequenceFinish(PIFilter *);

// Preview Animation
int FAR PASCAL PI_MakePrevAnim(PIFilter *PiFilter, int FirstImage, int LastImage, double FrameRate, void *extension);
int FAR PASCAL PI_PlayPrevAnim(PIFilter *PiFilter, void *extension);
int FAR PASCAL PI_RemovePrevAnim(PIFilter *PiFilter, void *extension);

//----------------------------------
//     Host functions (dllx.c)
//----------------------------------


// progress indicator
void	TVWorkOn(PIFilter *PiFilter, const char *text);
void	TVWorkOff(PIFilter *PiFilter);
int		TVWorkTrace(PIFilter *PiFilter,int pos, int size);


void	TVWarning(PIFilter *PiFilter, const char *warn);
int		TVDemand(PIFilter *PiFilter, const char *s, const char *yes, const char *no);
int		TVDemandInt(PIFilter *PiFilter, const char *s, int *val, int min, int max);
int		TVDemandText(PIFilter *PiFilter, const char *s, char *text, int max);
int		TVDemandDouble(PIFilter *PiFilter, const char *iTitle, double *ioVal, double iMin, double iMax);


int		TVSendCmd(PIFilter *PiFilter, const char *cmd, char *result);
int		TVExecute(PIFilter *PiFilter);

// pixels tranfers functions
int		TVReadLayerData(PIFilter *PiFilter, PIPixel *dest, int x,int y, int w, int h, int mod, int layer);
int		TVWriteLayerData(PIFilter *PiFilter, const PIPixel *source, int x,int y, int w, int h, int mod, int display);
void	TVUpdateDisplay(PIFilter *PiFilter, int x1, int y1, int x2 , int y2);

void	TVPreviewLine(PIFilter *PiFilter, double x1, double y1, double x2 , double y2, int mode);
void	TVPreviewHandle(PIFilter *PiFilter, double iX, double iY, double iSize ,int iMode);
void	TVPreviewText(PIFilter *PiFilter, double iX, double iY, const char* iText, int iMode);

//Hud
void	TVHudRedraw(PIFilter *PiFilter);
void	TVHudLine(PIFilter *PiFilter, float iX1, float iY1, float iX2, float iY2, PIPixel iColor);
void	TVHudSpline(PIFilter *PiFilter,  float iX1, float iY1, float iX12, float iY12, float iX2, float iY2, PIPixel iColor);
void	TVHudText(PIFilter *PiFilter,  float iX, float iY, const char* iText, int iAlign, PIPixel iColor, int iSelected);
void	TVHudHandle(PIFilter *PiFilter,  float iX, float iY, int iHandle, PIPixel iColor, int iSelected);
void	TVHudImage(PIFilter *PiFilter,  float iX, float iY, float iX1, float iY1, float iX2, float iY2, float iX3, float iY3, float iX4, float iY4, const PIBlock* iBlock);



// color blend and compression functions
ULONG32	TVMakeRGBAPixel(PIFilter *PiFilter,  int r,  int g,  int b,  int a);
int		TVPackRLE(PIFilter *PiFilter, const ULONG32 *source,  char *dest, int sourcesize);
int		TVUnpackRLE(PIFilter *PiFilter, const char *source,  ULONG32 *dest, int destsize);
void	TVColorBlend(PIFilter *PiFilter, const PIPixel *s1, int density1, const PIPixel *s2, int density2, PIPixel *dest, int w, int h, int mods1, int mods2,  int moddest);

//58171
void	TVColorBlendMode(PIFilter *PiFilter, const PIPixel *iSrc1, const PIPixel *iSrc2, PIPixel *oDest, int iSize, int iMode);

int		TVWrapPIBlock(PIFilter *PiFilter, const PIBlock *source, PIBlock *dest,	double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4);
// compilation 57671
int		TVWrapPIBlockMode(PIFilter *PiFilter, const PIBlock *source, PIBlock *dest,	double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4, int iTile, int iMode);


// requester and IU functions
INTPTR	TVOpenReq(PIFilter *PiFilter, int width, int height, int x, int y, INTPTR flags, const char *name);
INTPTR	TVOpenReqEx(PIFilter *PiFilter, int width, int height, int x, int y, INTPTR flags, const char *name,	int (*MessageFonc)(PIFilter *PiFilter, INTPTR, INTPTR, INTPTR *));
void	TVCloseReq(PIFilter *PiFilter, INTPTR req);
int		TVReqToBack(PIFilter *PiFilter, INTPTR req);
int		TVReqToFront(PIFilter *PiFilter, INTPTR req);
int		TVMoveReq(PIFilter *PiFilter, INTPTR req, int x, int y);
int		TVResizeReq(PIFilter *PiFilter, INTPTR req, int x, int y, int w, int h);
int		TVSetReqTitle(PIFilter *PiFilter, INTPTR req, const char *title);
int		TVInfoReq(PIFilter *PiFilter, INTPTR req, int *x,int *y,int *w,int *h);

void	TVSaveReqState( PIFilter *iPiFilter, INTPTR iReq, const char* iSection, const char* iSubSection );
void	TVLoadReqState( PIFilter *iPiFilter, INTPTR iReq, const char* iSection, const char* iSubSection );
int		TVDisplayReq(PIFilter *iPiFilter, INTPTR iReq, int iShow); // 0 Hide, 1 Show, 2 return current state

int		TVAddButtonReq(PIFilter *PiFilter, INTPTR req, int x,int y,int w,int h,int id,INTPTR flags,const char *name);
int		TVChangeButtonReq(PIFilter *PiFilter, INTPTR req, int id, INTPTR flags,const char *name);
int		TVRemoveButtonReq(PIFilter *PiFilter, INTPTR req, int id);
int		TVSetButtonInfoText(PIFilter *PiFilter, INTPTR req, int id, const char *text);
int		TVGetButtonString(PIFilter *PiFilter, INTPTR req,  int id, char *string, int maxchar);
int		TVPutButtonString(PIFilter *PiFilter, INTPTR req,  int id, const char *string);
int		TVPutButtonStringUnit(PIFilter *PiFilter, INTPTR req,  int id, const char *unit);
int		TVPutButtonImage(PIFilter *PiFilter, INTPTR req, int id, PIBlock *Image, INTPTR flags);
PIBlock* TVGetButtonImage(PIFilter *PiFilter, INTPTR req, int id, INTPTR flags);
int TVRefreshButtonImage(PIFilter *PiFilter, INTPTR req, int id, int x, int y, int w, int h);
// compilation 32174
int		TVChangeButtonFlags(PIFilter *PiFilter, INTPTR req, int id, INTPTR flags);
int		TVChangeButtonName(PIFilter *PiFilter, INTPTR req, int id, const char *name, INTPTR flags);

int		TVPopup(PIFilter *PiFilter, PIPopup *Popup,  int num, int startnum);

int		TVGrabCoords(PIFilter *PiFilter, INTPTR req, int flag);
int		TVGrabTicks(PIFilter *PiFilter, INTPTR req, int flag);

int		TVPickColor(PIFilter *PiFilter, PIPixel* result);

int		TVCreateFilterAlias(PIFilter *PiFilter, const char *alias, const char *params);

// Open filter req (single req)
INTPTR TVOpenFilterReq(PIFilter *PiFilter, int width, int height, int (*MessageFonc)(PIFilter *PiFilter, INTPTR, INTPTR, INTPTR *), PIKeys *keys, INTPTR reqflags);
INTPTR TVOpenFilterReqEx(PIFilter *PiFilter, int width, int height, int (*MessageFonc)(PIFilter *PiFilter, INTPTR, INTPTR, INTPTR *), PIKeys *keys, INTPTR reqflags, INTPTR menuflags);



// preference files
int		TVWriteUserString(PIFilter *iPiFilter, const char *section, const char *name, const char *string);
int		TVReadUserString(PIFilter *iPiFilter, const char *section, const char *name, char *string, const char *def, int maxchar);
int		TVEraseUserSection(PIFilter *iPiFilter, const char *iSection);

int		TVWriteProjectString(PIFilter *iPiFilter, const char *iSection, const char *iName, const char *iString);
int		TVReadProjectString(PIFilter *iPiFilter, const char *iSection, const char *iName, char *iString, const char *iDefault, int iMaxChar);
int		TVEraseProjectSection(PIFilter *iPiFilter, const char *iSection);


void	*TVOpenStringFile(PIFilter *PiFilter, const char *filename, INTPTR flags);
int		TVCloseStringFile(PIFilter *PiFilter, void *StringFile, INTPTR flags);
int		TVWriteStringFile(PIFilter *PiFilter, void *StringFile, const char *iSection, const char *iName, const char *iString);
int		TVReadStringFile(PIFilter *PiFilter, void *StringFile, const char *iSection,	const char *iName, char *oString, const char *iDefualt, int iMaxChar);
int		TVEraseStringFileSection(PIFilter *iPiFilter, void *iStringFile, const char *iSection);



// requester gfx functions
int 	TVTextReq(PIFilter *PiFilter, INTPTR req, int x,int y, const char *text,INTPTR mode, ULONG32 APen,ULONG32 BPen);
int		TVTextReqClip(PIFilter *PiFilter, INTPTR req, int x, int y, const char *text, INTPTR mode, ULONG32 APen, ULONG32 BPen, int clipx1, int clipy1, int clipx2, int clipy2);
int		TVTextLength(PIFilter *PiFilter, INTPTR req, const char *text,  int size);
int		TVRectangleReq(PIFilter *PiFilter, INTPTR req, int x1,int y1, int x2, int y2,INTPTR mode, ULONG32 APen);
int		TVWriteReqData(PIFilter *PiFilter, const PIPixel *source, int x,int y, int w, int h, int mod, INTPTR req);
int		TVReadReqData(PIFilter *PiFilter, PIPixel *dest, int x,int y, int w, int h, int mod, INTPTR req);
void	TVAADrawReq(PIFilter *PiFilter, INTPTR req, double x1,double y1, double x2, double y2, int r1, int r2, INTPTR mode, ULONG32 APen, int clipx1, int clipy1,  int clipx2,  int clipy2);

// meta functions
int		TVInstallFunction(PIFilter *PiFilter, int function);
int		TVCloseFunction(PIFilter *PiFilter);




// Images function
int		TVMakeDisplayImage(PIFilter *PiFilter, PIPixel *dest, int destsize, int imagenum,  int background);
int		TVMakeBrush(PIFilter *PiFilter, const PIPixel *Brush, int width, int height);
int		TVReadImage(PIFilter *PiFilter, const char *name, PIPixel *dest, int destwidth, int destheight);

int		TVReadProjectImage(PIFilter *PiFilter, PIBlock *dest, int projectid, int layerid, int imagenum);

int		TVTextBlock(PIFilter *PiFilter, PIBlock *piblock, int x, int y, const char *text, ULONG32 APen);

int		TVGetImageID(PIFilter *PiFilter, int iProjectID, int iLayerID, int iImagePosition, char* oImageID, char* oDataID);



// Pixel Block Allocations
PIBlock *TVAllocPIBlock(PIFilter *PiFilter, int Width,  int Height, INTPTR Flags);
void	TVFreePIBlock(PIFilter *PiFilter, PIBlock *piblock);


// file requester
int		TVAllocFileReq(PIFilter *PiFilter, PIFileReq *PiFileReq);
void	TVFreeFileReq(PIFilter *PiFilter, PIFileReq *PiFileReq);
int		TVOpenFileReq(PIFilter *PiFilter, PIFileReq *PiFileReq);

// multi thread
int TVRunMultiThread(PIFilter *PiFilter, int (*fonc)(void *thread, int start, int end, void *param), int start, int end, void *param);

// display devices
#include	"pidisplay.h"
int TVAddDisplayDevice(PIFilter *PiFilter, PIDisplay *device, unsigned long flags);
const char *TVEnumDisplayDevice(PIFilter *PiFilter, int num, unsigned long flags);
PIDisplay *TVLockDisplayDevice(PIFilter *PiFilter, const char *name,  unsigned long mode);
void TVUnlockDisplayDevice(PIFilter *PiFilter, PIDisplay *display);

// sliders
int TVAddSliderReq(PIFilter *PiFilter, INTPTR req, int x, int y, int w,int h, int id, INTPTR flags, int MaxX, int NumX, int PosX, int MaxY, int NumY, int PosY);

int TVChangeSliderReq(PIFilter *PiFilter, INTPTR req, int id, int MaxX, int NumX, int PosX, int MaxY, int NumY, int PosY);

// tabs
int TVAddTabs(PIFilter *PiFilter, INTPTR req, int x, int y, int w,int h, int id, int num,  int current,  const char **names);
int TVChangeTabs(PIFilter *PiFilter, INTPTR req, int id, int pos);


// localisation
void *TVOpenLocalFile(PIFilter *PiFilter, const char *name, unsigned long reserved);
void TVCloseLocalFile(PIFilter *PiFilter, void *localfile);
TVCHAR *TVGetLocalString(PIFilter *PiFilter, void *localfile, unsigned int line);

// keys
PIKeys *TVAllocKeys(PIFilter *PiFilter, const char *name, const char *nameid);


// compass
int TVCompassOpen(PIFilter *PiFilter, INTPTR req, int id, double val);
void TVCompassClose(PIFilter *PiFilter);
void TVCompassChange(PIFilter *PiFilter, double val);

//videodevice
#include	"videodevice.h"
VideoDevice *TVEnumVideoDevice(PIFilter *PiFilter, int DevNum);
void TVAddVideoDevice(PIFilter *PiFilter, VideoDevice *VDev);
int	 TVAddVideoButton(PIFilter *PiFilter, INTPTR req, int x,int y,int w,int h,int id, VideoDevice *VDev, int VideoInput, int VideoMode);

// PIBlock functions
int	 TVBlockBlur(PIFilter *PiFilter, PIBlock *blk, double bx, double by, int MirrorBorder);
int	 TVBlockStretch(PIFilter *PiFilter, const PIBlock *iSrc, PIBlock *oDst);

// Pixels functions
int	 TVRGBAToYUV(PIFilter* PiFilter, const PIPixel* iRGBA, unsigned char* oYUV, unsigned char* oAlpha, int iSize);
int	 TVYUVToRGBA(PIFilter* PiFilter, const unsigned char* iYUV, const unsigned char* iAlpha, PIPixel* oRGBA, int iSize);
int	 TVRGBAUnmultiply( PIFilter* PiFilter, const PIPixel* iRGBA, PIPixel* oRGBA, int iSize);
int	 TVRGBAPremultiply(PIFilter* PiFilter, const PIPixel* iRGBA, PIPixel* oRGBA, int iSize);

//DirectDraw function ------- Obsolete ----------------
typedef struct IDirectDrawSurface DDSurf;
int	TVDDBlit(PIFilter *PiFilter, INTPTR *iReq, int iButtonID, int iDst_X, int iDst_Y, int iDst_Width, int iDst_Height,
			 DDSurf *iSrc, int iSrc_X, int iSrc_Y, int iSrc_Width, int iSrc_Height);



#ifdef __cplusplus
}
#endif


#endif //plugdllx_HH

