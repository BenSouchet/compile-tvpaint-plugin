/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/******************************************************************************/

// ===========================================================================
/** @file piprofile.h
		
     @ingroup tvpaint90 
      @author Herv� ADAM & Eric Matecki
       $Date: 2008-07-23 09:22:06 +0200 (mer., 23 juil. 2008) $
         $Id: piprofile.h 928 2008-07-23 07:22:06Z Hervé ADAM $
   @copyright (c) 2002-08 TVPaint Developpement. All Rights Reserved.
*/
// ===========================================================================

#ifndef __piprofile_HH
#define __piprofile_HH

#ifndef __plugdllx_HH
#include "plugdllx.h"
#endif


#ifdef __cplusplus
extern "C" {
#endif

typedef struct PIProfile
{
	int Version; // sizeof(PIProfile)

//virtual
	void (*Refresh)(void* iUserData);
	void *UserData;

//public
	void (*Delete)(struct PIProfile* iProfile);
	int (*OpenEdit)(struct PIProfile* iProfile);
	int (*CloseEdit)(struct PIProfile* iProfile);

	int (*Load)(struct PIProfile* iProfile, void* iFile, const char* iSection);
	int (*Save)(struct PIProfile* iProfile, void* iFile, const char* iSection);

	int (*Evaluate)(struct PIProfile* iProfile, float* oDest, int iCount);

}PIProfile;

#define PIPROF_00	0 //horizontal at 0
#define PIPROF_01	1 //ascending ramp
#define PIPROF_10	2 //descending ramp
#define PIPROF_11	3 //horizontal at 1


PIProfile* TVAllocProfile(PIFilter* PiFilter, const char *iName, int iDefault);

#ifdef __cplusplus
}
#endif

#endif //__piprofile_HH
