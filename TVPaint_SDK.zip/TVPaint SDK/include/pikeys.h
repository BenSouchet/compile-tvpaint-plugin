/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/******************************************************************************/

// ===========================================================================
/** @file pikeys.h
        
     @ingroup tvpaint90
      @author Herv� ADAM & Eric Matecki & Sebastien Miglio
       $Date: 2008-07-23 09:22:06 +0200 (mer., 23 juil. 2008) $
         $Id: pikeys.h 928 2008-07-23 07:22:06Z Hervé ADAM $
   @copyright (c) 2002-08 TVPaint Developpement. All Rights Reserved.
*/
// ===========================================================================

#ifndef __pikeys_HH
#define __pikeys_HH



#define	PIKEYS_VERSION 1

//-----------------------------------------------------
// Filter Req Flags

#define FILTERREQ_NO_PATH		(1<<1)
#define FILTERREQ_NO_FILE		(1<<2)
#define FILTERREQ_NO_TBAR		(1<<3)
#define FILTERREQ_EXPORT		(1<<4)
#define FILTERREQ_MOTION		(1<<5)
#define FILTERREQ_CUSTOM_IO		(1<<6)
#define FILTERREQ_CREATE_ONLY	(1<<7)

//-----------------------------------------------------
typedef	struct KeyXYZ
{
	double x,y,z;
}KeyXYZ;

typedef	struct KeyHPB
{
	double h,p,b;
}KeyHPB;

typedef	struct KeyColor
{
	double r,g,b,a;
}KeyColor;

// need to be in sync with the ones in keys16.h
#define	KEY_TYPE_INT		0	// int
#define	KEY_TYPE_DOUBLE		1	// double
#define	KEY_TYPE_COLOR		2	// set: KeyColor(4*double), get: PIPixel
#define	KEY_TYPE_UCOLOR		3	// PIPixel
#define	KEY_TYPE_BOOL		4	// bool (int)
#define	KEY_TYPE_XYZ		5	// KeyXYZ
#define	KEY_TYPE_HPB		6	// KeyHPB

typedef	struct PIKeys
{
	char *name;

	// plugin refresh
	void (*refresh)(struct PIKeys *iKeys, int iID); // callback
	void *pidata;

	// host
	int	(*addparam)(struct PIKeys *iKeys, int iID, const char *iName, int iType, const void *iVal);

	int (*setval)(struct PIKeys *iKeys, int iID, const void *iVal);
	int (*getval)(struct PIKeys *iKeys, int iID, void *oRetVal);
	int (*getvalpos)(struct PIKeys *iKeys, int iID, double iPos, void *oRetVal);

	int	(*save)(struct PIKeys *iKeys, void *iParamFile, const char *iSection);
	int	(*load)(struct PIKeys *iKeys, void *iParamFile, const char *iSection);

	void (*free)(struct PIKeys *iKeys);

	void (*lock)(struct PIKeys *iKeys);
	void (*unlock)(struct PIKeys *iKeys);

	//Aura 2.5b
	void (*removeparam)(struct PIKeys *iKeys, int iID);
	int (*copyparam)(struct PIKeys *iKeysSrc, int iIDSrc, struct PIKeys *oKeysDst, int iIDDst, double iDeltaT);
	void (*renameparam)(struct PIKeys *iKeys, int iID, const char* iName);


	//Aura 2.6
	void (*posrefreshCB)(struct PIKeys *iKeys); // callback

}PIKeys;


//-----------------------------------------------------

// default ID for filters compatiblity

#define	KEY_OFFSET_RADIUS	(-4	)	// double
#define	KEY_OFFSET_H		(-5	)	// double
#define	KEY_OFFSET_P		(-6	)	// double
#define	KEY_OFFSET_B		(-7	)	// double
#define	KEY_OFFSET_COLOR	(-8	)	// KEY_TYPE_COLOR
#define	KEY_OFFSET_WIDTH	(-9	)	// double proportion
#define	KEY_OFFSET_HEIGHT	(-10)	// double proportion
#define	KEY_OFFSET_PRESSURE	(-11)	// double 0.<->1.
#define	KEY_OFFSET_ALTITUDE	(-12)	// double 0.<->1.
#define	KEY_OFFSET_AZIMUTH	(-13)	// double 0.<->1.
#define	KEY_OFFSET_FWHEEL	(-14)	// double 0.<->1.
#define	KEY_OFFSET_SPEED	(-15)	// double 0.<->1.
#define	KEY_OFFSET_DOWN		(-16)	// bool
#define	KEY_OFFSET_LINEAR	(-17)	// bool, obsolete
#define	KEY_OFFSET_NOISE	(-18)	// double distance
#define	KEY_OFFSET_MBLUR	(-19)	// double
#define	KEY_OFFSET_OPACITY	(-20)	// double
#define	KEY_OFFSET_XYZ		(-21)	// KeyXYZ
#define	KEY_OFFSET_HPB		(-22)	// KeyHPB
#define	KEY_OFFSET_QUAT		(-23)	// cQuaternion


#define	KEY_ID_START	(-65536)

#define KEY_OFFSET_MAX	19

#define	KEY_ID_RES		256

#define	KEY_ID_RADIUS_N(NUM)	(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_RADIUS)
#define	KEY_ID_H_N(NUM)			(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_H)
#define	KEY_ID_P_N(NUM)			(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_P)
#define	KEY_ID_B_N(NUM)			(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_B)
#define	KEY_ID_COLOR_N(NUM)		(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_COLOR)
#define	KEY_ID_WIDTH_N(NUM)		(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_WIDTH)
#define	KEY_ID_HEIGHT_N(NUM)	(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_HEIGHT)

#define	KEY_ID_PRESSURE_N(NUM)	(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_PRESSURE)
#define	KEY_ID_ALTITUDE_N(NUM)	(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_ALTITUDE)
#define	KEY_ID_AZIMUTH_N(NUM)	(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_AZIMUTH)
#define	KEY_ID_FWHEEL_N(NUM)	(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_FWHEEL)
#define	KEY_ID_SPEED_N(NUM)		(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_SPEED)
#define	KEY_ID_MBLUR_N(NUM)		(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_MBLUR)

#define	KEY_ID_DOWN_N(NUM)		(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_DOWN)
#define	KEY_ID_LINEAR_N(NUM)	(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_LINEAR)
#define	KEY_ID_NOISE_N(NUM)		(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_NOISE)
#define	KEY_ID_OPACITY_N(NUM)	(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_OPACITY)
#define	KEY_ID_XYZ_N(NUM)		(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_XYZ)
#define	KEY_ID_HPB_N(NUM)		(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_HPB)
#define	KEY_ID_QUAT_N(NUM)		(KEY_ID_START-(NUM)*KEY_ID_RES + KEY_OFFSET_QUAT)

#define	KEY_ID_XYZ		KEY_ID_XYZ_N(0)
#define	KEY_ID_HPB		KEY_ID_HPB_N(0)
#define	KEY_ID_RADIUS	KEY_ID_RADIUS_N(0)
#define	KEY_ID_H		KEY_ID_H_N(0)
#define	KEY_ID_P		KEY_ID_P_N(0)
#define	KEY_ID_B		KEY_ID_B_N(0)
#define	KEY_ID_COLOR	KEY_ID_COLOR_N(0)
#define	KEY_ID_WIDTH	KEY_ID_WIDTH_N(0)
#define	KEY_ID_HEIGHT	KEY_ID_HEIGHT_N(0)
#define	KEY_ID_PRESSURE	KEY_ID_PRESSURE_N(0)
#define	KEY_ID_ALTITUDE	KEY_ID_ALTITUDE_N(0)
#define	KEY_ID_AZIMUTH	KEY_ID_AZIMUTH_N(0)
#define	KEY_ID_FWHEEL	KEY_ID_FWHEEL_N(0)
#define	KEY_ID_SPEED	KEY_ID_SPEED_N(0)
#define	KEY_ID_DOWN		KEY_ID_DOWN_N(0)
#define	KEY_ID_LINEAR	KEY_ID_LINEAR_N(0) //obsolete
#define	KEY_ID_NOISE	KEY_ID_NOISE_N(0)
#define	KEY_ID_MBLUR	KEY_ID_MBLUR_N(0)
#define	KEY_ID_OPACITY	KEY_ID_OPACITY_N(0)

//-----------------------------------------------------


#endif //pikeys_HH
