/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/******************************************************************************/

// ===========================================================================
/** @file piimagesequence.h
		
     @ingroup tvpaint90 
      @author Herv� ADAM & Eric Matecki
       $Date: 2008-07-23 09:22:06 +0200 (mer., 23 juil. 2008) $
         $Id: piimagesequence.h 928 2008-07-23 07:22:06Z Hervé ADAM $
   @copyright (c) 2002-08 TVPaint Developpement. All Rights Reserved.
*/
// ===========================================================================

#ifndef __piimagesequence_HH
#define __piimagesequence_HH

#ifdef __cplusplus
extern "C" {
#endif

typedef struct PIImageSequence
{
	int			Version;	// sizeof(struct ImageSequence)
	const char* FileName;	
	int			Width;
	int			Height;
	int			ImageCount;
	double		FrameRate;

	void (*Close)    (struct PIImageSequence* iSeq);
	int  (*ReadImage)(struct PIImageSequence* iSeq, int iPosition, PIBlock* oDest);
}PIImageSequence;


#define ISEQ_FLAG_OPEN 0
#define ISEQ_FLAG_NO_SCAN 1

PIImageSequence* TVOpenImageSequence(PIFilter* PiFilter, const char* iFileName, int iFlags);

#ifdef __cplusplus
};
#endif

#endif //__piimagesequence_HH
