/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/******************************************************************************/

// ===========================================================================
/** @file videodevice.h

     @ingroup tvpaint90
      @author Herv� ADAM & Eric Matecki
       $Date: 2009-05-13 14:43:57 +0200 (mer., 13 mai 2009) $
         $Id: videodevice.h 1659 2009-05-13 12:43:57Z guillaume $
   @copyright (c) 2001 TVPaint Developpement. All Rights Reserved.
*/
// ===========================================================================

#ifndef __videodevice_HH
#define __videodevice_HH

#ifdef __cplusplus
extern "C" {
#endif

#define PIXTYPE_BGRA32	0	// RGBA 32 bits
#define PIXTYPE_UYVY	1	// 16 bits YUYV FOURCC('UYVY')
#define PIXTYPE_YUY2	2	// 16 bits UYVY FOURCC('YUY2')
#define PIXTYPE_BGR32	3	// RGB 32 bits

typedef struct VideoInfo
{
	char Name[1024];		// "Toaster Display In/Out/..."
	int Width,Height;		// 720, 576/488
	int BytesPerPixel;		// 2,4
	int PixelType;			// PIXTYPE_YUY2...
	double AspectRatio;		// NTSC PAL
	double FrameRate;		// 25 / 29.997 ...
	int	   FieldMode;		// 0 none, 1 odd first, 2 even first
	int Reserved[64];
}VideoInfo;

typedef struct VideoBlock
{
	int Width,Height;
	int Field;				// 0: all field, 1: lower/odd field, 2: upper/even field, 3: all fields
	int BytesPerPixel;
	int Pitch;
	int PixelType;			// PIXTYPE_YUY2...
	unsigned char *Data;
	int AlphaPitch;			// YUV Alpha
	unsigned char *Alpha0;	// First field
	unsigned char *Alpha1;	// First field
	unsigned char *Field0;	// First field
	unsigned char *Field1;  // Last field
	int	   FieldMode;		// 0 none, 1 lower/odd first, 2 upper/even first
	double AspectRatio;		// zero == 1.0
	int Reserved[64];
}VideoBlock;

typedef void * VideoDevID;

//#define VIDEODEVICE_VERSION 1
#define VIDEODEVICE_VERSION 2

typedef struct VideoDevice
{
	int Version;
	const char* DeviceName;
	const char*		(*EnumInputs)(struct VideoDevice *iVDev, int iInputNum);
	int				(*EnumModes)(struct VideoDevice *iVDev, int iInputNum, int iModeNum, VideoInfo *oDesc);
	VideoDevID		(*Start)(struct VideoDevice *iVDev, int iInputNumber, int iModeNumber, int (*iGrabThread)(VideoBlock *vblock, void *iUserData), void *iUserData);
	void			(*Stop)(struct VideoDevice *iVDev, VideoDevID iID);
	void			(*Configure)(struct VideoDevice *iVDev);

	// version 2
	const char*		(*EnumAcquireMode)(struct VideoDevice *iVDev, int iModeNum);
	struct PIBlock*	(*AcquireImage)(struct VideoDevice *iVDev, int iModeNum);
	//
	unsigned long	reserved[1022];	// must be 0
}VideoDevice;

VideoDevice* EnumVideoDevice(int iNum);
void AddVideoDevice(VideoDevice *iVDev);

#ifdef __cplusplus
};
#endif

#endif //videodevice_HH
