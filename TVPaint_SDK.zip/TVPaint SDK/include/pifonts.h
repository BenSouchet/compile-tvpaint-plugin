/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/******************************************************************************/

// ===========================================================================
/** @file pifonts.h
		
     @ingroup tvpaint90 
      @author Herv� ADAM & Eric Matecki
       $Date: 2008-07-23 09:22:06 +0200 (mer., 23 juil. 2008) $
         $Id: pifonts.h 928 2008-07-23 07:22:06Z Hervé ADAM $
   @copyright (c) 2002-08 TVPaint Developpement. All Rights Reserved.
*/
// ===========================================================================

#ifndef __pifonts_HH
#define __pifonts_HH

#ifdef __cplusplus
extern "C" {
#endif

typedef	struct PIFont
{
	int  Version;	// sizeof(PIFont)
	void (*Close)		(struct PIFont *iFont);
	void (*SetMatrix)	(struct PIFont *iFont, double iIX,   double iIY,  double iJX, double iJY);
	void (*CalcMatrix)	(struct PIFont *iFont, double iSize, double *ioX, double *ioY);
	void (*Draw)		(struct PIFont *iFont,  void *iUserParam,
												void (*iBegin)(void *iUserParam, double iX, double iY),
												void (*iLine) (void *iUserParam, double iX, double iY),
												void (*iEnd)  (void *iUserParam),
												wchar_t iCode, double iScale, double* oPDX, double* oPDY);
	void (*Size)		(struct PIFont *iFont, wchar_t iCode, double iScale, double* oJX,  double* oJY,	double* oPDX, double* oPDY,	double* oL,   double* oH);
	void (*Kerning)		(struct PIFont *iFont, wchar_t iC1, wchar_t iC2, double iScale, double *oKernX, double *oKernY);
	//Aura 3
	void (*Ascent)		(struct PIFont *iFont, double iScale, double *oAscentX, double *oAscentY);
	void (*Descent)		(struct PIFont *iFont, double iScale, double *oDescentX, double *oDescentY);

}PIFont;

PIFont *TVOpenPIFont(PIFilter *PiFilter, const char *iName, unsigned long iScript, unsigned long iStyle);

#ifdef __cplusplus
};
#endif

#endif //__pifonts_HH
