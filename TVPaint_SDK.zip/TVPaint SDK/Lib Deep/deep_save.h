/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/*                                                                            */
/******************************************************************************/

#ifndef __deep_save_HH
#define __deep_save_HH


#ifndef __aura_def_HH
#include "aura_def.h"
#endif

class cDeep_Save
{
public:
/**@name CONSTRUCTION/DESTRUCTION */
//@{
	/** The destructor. */
	virtual  ~cDeep_Save();

	/** The constructor. */
	cDeep_Save(const char *iFileName, int iWidth, int iHeight, double iFrameRate, int iDepth=32, double iAspectRatio = 1.0 );
//@}

	//Add frame at the end of the current file
	bool PutFrame(const RGBABlock *iBlock);
	//Add frame at the end of the current file using differential compression (XOR)
	bool PutFrameDiff(const RGBABlock *iBlock, const RGBABlock *iLast);
	bool Error() const;

protected:

private:
	bool SaveXLChunk(const RGBABlock *iBlock);

private:
	const char* mFileName;
	int mBufferSize;
	signed char* mBuffer;
	int mWidth;
	int mHeight;
	double mFrameRate;
	int mDepth;
	int mFile;
	int mOffsetNIMA;
	int mNumImages;
	unsigned int mLastKey;
	bool mError;
};

#endif //deep_save_HH
