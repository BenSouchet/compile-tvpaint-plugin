/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/*                                                                            */
/******************************************************************************/

#ifndef __deep_load_HH
#define __deep_load_HH


#ifndef __aura_def_HH
#include "aura_def.h"
#endif

class cDeep_Load
{
public:
/**@name Construction/Destruction */
//@{
	/** The destructor. */
	virtual  ~cDeep_Load();

	/** The constructor. */
	cDeep_Load(const char *iFileName);
//@}
	bool Error()        const;
	int Width()         const;
	int Height()        const;
	double FrameRate()  const;
	double AspectRatio()const;
	int ImageCount()    const;
	int Depth()         const;


	bool GetFrame(int iImage, RGBABlock *iBlock);



public:
	//Read file preview thumbnail (.dip and .aur)
	static RGBABlock* GetXS(const char *iFileName);


protected:

private:
	static const signed char* UnpackRLE(const signed char *iSrc, unsigned char *oDst, int iSize);

	void UncompressEOR24(const unsigned char* iBuffer);
	void UncompressEOR(const unsigned char* iBuffer);
	void Uncompress24(const unsigned char* iBuffer);
	void Uncompress(const unsigned char* iBuffer);

private:
	bool mError;
	int mFile;
	int mDepth;		/* 24 or 32 */
	int mImageCount;
	int mCurrentImage;
	int mWidth;
	int mHeight;
	double mFrameRate;
	double mAspectRatio;
	unsigned long mOffsetNIMA;
	unsigned long mOffsetBODY;
	RGBABlock *mLast;
	int mRed, mGreen, mBlue, mDensity;
	long	mNextBodyNum;
	long	mNextBodyPos;
	int mCompression;

};


#endif //__deep_load_HH
