/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/*                                                                            */
/******************************************************************************/

#ifndef __aura_def_HH
#define __aura_def_HH


#if	defined(WIN32) || defined(_WIN32)
#define LITTLEINDIAN
#else
TODO: define Endian
#endif




#ifndef __aura_HH

typedef union
{
	unsigned long   l;
	struct
	{
		unsigned char Blue,Green,Red,Alpha;
	}b;
}Pixel;

// components offset
#define PBLUE	0
#define PGREEN	1
#define PRED	2
#define PALPHA	3



struct RGBABlock
{
public:
	~RGBABlock()
	{
		delete[] Data;
		delete[] Img;
	}

	RGBABlock(int iWidth, int iHeight) :
		Width(iWidth),
		Height(iHeight),
		r(PRED),
		g(PGREEN),
		b(PBLUE),
		a(PALPHA),
		Data(new Pixel[iWidth*iHeight]),
		Img(new Pixel*[iHeight])
	{
		Reserved[0] = Reserved[1] = Reserved[2] = 0;
		for(int y=0; y<Height; y++)
		{
			Img[y] = &Data[Width*y];
		}
		for(int x=0; x<Width*Height; x++)
		{
			Data[x].l = 0;
		}
	}

public:

	int 	Width, Height;
	char  	r,g,b,a;		// offset
	Pixel	*Data;
	int 	x,y;			// nothing
	Pixel	**Img;			// y lines 
	long	Reserved[3];	// private
};

#endif //!__aura_HH

#ifdef LITTLEINDIAN
#define ALPHA_MASK 0xff000000
#else
#define ALPHA_MASK 0x000000ff
#endif


#endif //aura_def_HH
