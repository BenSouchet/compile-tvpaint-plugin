/******************************************************************************/
/*                                                                            */
/*          Copyright (c) TVPaint Developpement. All Rights Reserved.         */
/*                                                                            */
/******************************************************************************/

// ===========================================================================
/** @file dllx.c

     @ingroup tvpaint90
      @author Herv� ADAM & Eric Matecki
       $Date: 2012-08-21 15:42:27 +0200 (mar., 21 août 2012) $
         $Id: dllx.c 5639 2012-08-21 13:42:27Z Mike $
   @copyright (c) 1995-08 TVPaint Developpement. All Rights Reserved.
*/
// ===========================================================================

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef __plugdllx_HH
#include "plugdllx.h"
#endif
#ifndef __plugx_HH
#include "plugx.h"
#endif
#ifndef __pidisplay_HH
#include "pidisplay.h"
#endif
#ifndef __videodevice_HH
#include "videodevice.h"
#endif
#ifndef __pifonts_HH
#include "pifonts.h"
#endif
#ifndef __piimagesequence_HH
#include "piimagesequence.h"
#endif
#ifndef __piprofile_HH
#include "piprofile.h"
#endif


#if defined(WIN32) || defined(WIN64)
#include <malloc.h>
#endif

/*--------------------------------------------------------------------------*/
INTPTR TVOpenReq(PIFilter *PiFilter, int width, int height, int x, int y, INTPTR flags, const char *name)
{
	INTPTR   arg[16];

	arg[0]=width;
	arg[1]=height;
	arg[2]=x;
	arg[3]=y;
	arg[4]=flags;
	arg[5]=(INTPTR)name;

	return PiFilter->CallBack( PiFilter, CB_OPENREQ, &arg[0]);
}

/*--------------------------------------------------------------------------*/
INTPTR TVOpenFilterReq(PIFilter *PiFilter, int width, int height,
	int (*MessageFonc)(PIFilter *PiFilter, INTPTR,INTPTR, INTPTR *), PIKeys *keys, INTPTR reqflags)
{
	INTPTR   arg[16];

	arg[0]=width;
	arg[1]=height;
	arg[2]=(INTPTR)MessageFonc;
	arg[3]=(INTPTR)keys;
	arg[4]=reqflags;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;

	return PiFilter->CallBack( PiFilter, CB_OPENFILTERREQ, &arg[0]);
}

/*--------------------------------------------------------------------------*/
INTPTR TVOpenFilterReqEx(PIFilter *PiFilter, int width, int height,
	int (*MessageFonc)(PIFilter *PiFilter, INTPTR, INTPTR, INTPTR *), PIKeys *keys, INTPTR reqflags, INTPTR menuflags)
{
	INTPTR   arg[16];

	arg[0]=width;
	arg[1]=height;
	arg[2]=(INTPTR)MessageFonc;
	arg[3]=(INTPTR)keys;
	arg[4]=reqflags;
	arg[5]=menuflags;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;

	return PiFilter->CallBack( PiFilter, CB_OPENFILTERREQ, &arg[0]);
}

/*--------------------------------------------------------------------------*/
INTPTR TVOpenReqEx(PIFilter *PiFilter, int width, int height, int x, int y, INTPTR flags, const char *name,
	int (*MessageFonc)(PIFilter *PiFilter, INTPTR, INTPTR, INTPTR *))
{
	INTPTR   arg[16];

	arg[0]=width;
	arg[1]=height;
	arg[2]=x;
	arg[3]=y;
	arg[4]=flags;
	arg[5]=(INTPTR)name;
	arg[6]=(INTPTR)MessageFonc;
	arg[7]=0;
	arg[8]=0;
	arg[9]=0;
	arg[10]=0;
	return PiFilter->CallBack( PiFilter, CB_OPENREQEX, arg);
}

/*--------------------------------------------------------------------------*/
void TVCloseReq(PIFilter *PiFilter, INTPTR req)
{
	INTPTR   arg[6];

	arg[0]=req;
	PiFilter->CallBack( PiFilter, CB_CLOSEREQ, arg);
}

/*--------------------------------------------------------------------------*/
int TVSetReqTitle(PIFilter *PiFilter, INTPTR req, const char *title)
{
	INTPTR   arg[16];

	arg[0]=PIRT_NAME;
	arg[1]=req;
	arg[2]=(INTPTR)title;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;

	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int TVAddButtonReq(PIFilter *PiFilter,INTPTR req, int x,int y,int w,int h,int id,INTPTR flags, const char *name)
{
	INTPTR   arg[16];

	arg[0]=PIRT_ADD_BUTTON;
	arg[1]=req;
	arg[2]=x;
	arg[3]=y;
	arg[4]=w;
	arg[5]=h;
	arg[6]=id;
	arg[7]=flags;
	arg[8]=(INTPTR)name;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int TVGrabCoords(PIFilter *PiFilter, INTPTR req, int flag)
{
	INTPTR   arg[16];

	arg[0]=PIRT_GRAB_COORD;
	arg[1]=req;
	arg[2]=flag;
	arg[3]=0;
	arg[4]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int TVGrabTicks(PIFilter *PiFilter, INTPTR req, int flag)
{
	INTPTR   arg[16];

	arg[0]=PIRT_GRAB_TICKS;
	arg[1]=req;
	arg[2]=flag;
	arg[3]=0;
	arg[4]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int TVReqToFront(PIFilter *PiFilter, INTPTR req)
{
	INTPTR   arg[16];

	arg[0]=PIRT_FRONT;
	arg[1]=req;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int TVMoveReq(PIFilter *PiFilter, INTPTR req, int x,int y)
{
	INTPTR   arg[16];

	arg[0]=PIRT_MOVE;
	arg[1]=req;
	arg[2]=x;
	arg[3]=y;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int TVInfoReq(PIFilter *PiFilter, INTPTR req, int *x,int *y,int *w,int *h)
{
	INTPTR   arg[16];
	int r;

	arg[0]=PIRT_INFO;
	arg[1]=req;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	r=(int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
	if(r==0)return 0;
	if(x)*x = (int)arg[2];
	if(y)*y = (int)arg[3];
	if(w)*w = (int)arg[4];
	if(h)*h = (int)arg[5];
	return r;

}

/*--------------------------------------------------------------------------*/
int TVResizeReq(PIFilter *PiFilter, INTPTR req, int x, int y, int w, int h)
{
	INTPTR   arg[16];

	arg[0]=PIRT_RESIZE;
	arg[1]=req;
	arg[2]=x;
	arg[3]=y;
	arg[4]=w;
	arg[5]=h;
	arg[6]=0;

	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int TVReqToBack(PIFilter *PiFilter, INTPTR req)
{
	INTPTR   arg[16];

	arg[0]=PIRT_BACK;
	arg[1]=req;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int TVPackRLE(PIFilter *PiFilter, const ULONG32 *source,  char *dest, int sourcesize)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)source;
	arg[1]=(INTPTR)dest;
	arg[2]=(INTPTR)sourcesize;
	return (int)PiFilter->CallBack( PiFilter, CB_PACK_RLE, arg);
}

/*--------------------------------------------------------------------------*/
int TVUnpackRLE(PIFilter *PiFilter, const char *source,  ULONG32 *dest, int destsize)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)source;
	arg[1]=(INTPTR)dest;
	arg[2]=(INTPTR)destsize;
	return (int)PiFilter->CallBack( PiFilter, CB_UNPACK_RLE, arg);
}

/*--------------------------------------------------------------------------*/
int	TVChangeButtonReq(PIFilter *PiFilter, INTPTR req, int id, INTPTR flags, const char *name)
{
	INTPTR   arg[16];

	arg[0]=PIRT_CHANGE_BUTTON;
	arg[1]=req;
	arg[2]=id;
	arg[3]=flags;
	arg[4]=(INTPTR)name;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int	TVChangeButtonName(PIFilter *PiFilter, INTPTR req, int id, const char *name,INTPTR flags)
{
	INTPTR   arg[16];

	arg[0]=PIRT_CHANGE_BUTTON_NAME;
	arg[1]=req;
	arg[2]=id;
	arg[3]=(INTPTR)name;
	arg[4]=flags;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int	TVChangeButtonFlags(PIFilter *PiFilter, INTPTR req, int id, INTPTR flags)
{
	INTPTR   arg[16];

	arg[0]=PIRT_CHANGE_BUTTON_FLAGS;
	arg[1]=req;
	arg[2]=id;
	arg[3]=flags;
	arg[4]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int TVRemoveButtonReq(PIFilter *PiFilter, INTPTR req, int id)
{
	INTPTR   arg[16];

	arg[0]=PIRT_REMOVE_BUTTON;
	arg[1]=req;
	arg[2]=id;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int	TVSetButtonInfoText(PIFilter *PiFilter, INTPTR req, int id, const char *text)
{
	INTPTR   arg[16];

	arg[0]=PIRT_SET_INFO_TEXT;
	arg[1]=req;
	arg[2]=id;
	arg[3]=(INTPTR)text;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int TVTextLength(PIFilter *PiFilter, INTPTR req, const char *text,  int size)
{
	INTPTR   arg[16];

	arg[0]=PIRT_TEXT_LENGTH;
	arg[1]=req;
	arg[2]=(INTPTR)text;
	arg[3]=size;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);

}

/*--------------------------------------------------------------------------*/
int TVTextReq(PIFilter *PiFilter, INTPTR req, int x,int y,const char *text,INTPTR mode, ULONG32 iAPen,ULONG32 iBPen)
{
    INTPTR   arg[16];

	arg[0]=PIRT_TEXT;
	arg[1]=req;
	arg[2]=(INTPTR)text;
	arg[3]=x;
	arg[4]=y;
	arg[5]=mode;
	arg[6]=iAPen;
	arg[7]=iBPen;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);

}

/*--------------------------------------------------------------------------*/
int TVTextReqClip(PIFilter *PiFilter, INTPTR req, int x,int y,const char *text,INTPTR mode, ULONG32 iAPen,ULONG32 iBPen,
	int clipx1, int clipy1, int clipx2, int clipy2)
{
	INTPTR   arg[16];

	arg[0]=PIRT_TEXT_CLIP;
	arg[1]=req;
	arg[2]=(INTPTR)text;
	arg[3]=x;
	arg[4]=y;
	arg[5]=mode;
	arg[6]=iAPen;
	arg[7]=iBPen;
	arg[8]=clipx1;
	arg[9]=clipy1;
	arg[10]=clipx2;
	arg[11]=clipy2;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);

}

/*--------------------------------------------------------------------------*/
void	TVAADrawReq(PIFilter *PiFilter, INTPTR req, double x1,double y1, double x2, double y2,
	int r1, int r2, INTPTR mode, ULONG32 iAPen,
	int clipx1, int clipy1,  int clipx2,  int clipy2)
{
	INTPTR   arg[16];

	arg[0]=PIRT_AADRAW;
	arg[1]=req;
	arg[2]=(INTPTR)(x1*65536.);
	arg[3]=(INTPTR)(y1*65536.);
	arg[4]=(INTPTR)(x2*65536.);
	arg[5]=(INTPTR)(y2*65536.);
	arg[6]=r1;
	arg[7]=r2;
	arg[8]=mode;
	arg[9]=iAPen;
	arg[10]=clipx1;
	arg[11]=clipy1;
	arg[12]=clipx2;
	arg[13]=clipy2;
	PiFilter->CallBack( PiFilter,CB_SENDREQCMD, arg);
	return;
}

/*--------------------------------------------------------------------------*/
void	TVColorBlend(PIFilter *PiFilter, const PIPixel *s1, int density1, const PIPixel *s2, int density2,
	    PIPixel *dest, int w, int h, int mods1, int mods2,  int moddest)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)s1;
	arg[1]=(INTPTR)density1;
	arg[2]=(INTPTR)s2;
	arg[3]=(INTPTR)density2;
	arg[4]=(INTPTR)dest;
	arg[5]=(INTPTR)w;
	arg[6]=(INTPTR)h;
	arg[7]=(INTPTR)mods1;
	arg[8]=(INTPTR)mods2;
	arg[9]=(INTPTR)moddest;
	PiFilter->CallBack( PiFilter,CB_COLOR_BLEND, arg);
	return;
}

/*--------------------------------------------------------------------------*/
void	TVColorBlendMode(PIFilter *PiFilter, const PIPixel *iSrc1, const PIPixel *iSrc2, PIPixel *oDest, int iSize, int iMode)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)iSrc1;
	arg[1]=(INTPTR)iSrc2;
	arg[2]=(INTPTR)oDest;
	arg[3]= iSize;
	arg[4]= iMode;
	arg[5]= 0;
	arg[6]= 0;
	PiFilter->CallBack( PiFilter,CB_COLOR_BLEND_MODE, arg);
	return;
}


/*--------------------------------------------------------------------------*/
int TVRectangleReq(PIFilter *PiFilter, INTPTR req, int x1,int y1, int x2, int y2,INTPTR mode, ULONG32 iAPen)
{
	INTPTR   arg[16];

	arg[0]=PIRT_RECT;
	arg[1]=req;
	arg[2]=x1;
	arg[3]=y1;
	arg[4]=x2;
	arg[5]=y2;
	arg[6]=mode;
	arg[7]=iAPen;
	return (int)PiFilter->CallBack( PiFilter,CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
void TVWorkOn(PIFilter *PiFilter, const char *text)
{
	INTPTR   arg[2];

	arg[0]=(INTPTR)text;
	PiFilter->CallBack( PiFilter, CB_WORKON, arg);
}

/*---------------------------------------------------------------------------*/
void TVWorkOff(PIFilter *PiFilter)
{
	PiFilter->CallBack( PiFilter, CB_WORKOFF, NULL);
}

/*---------------------------------------------------------------------------*/
int TVWorkTrace(PIFilter *PiFilter,int pos, int size)
{
	INTPTR   arg[2];

	arg[0]=pos;
	arg[1]=size;
	return (int)PiFilter->CallBack( PiFilter, CB_WORKTRACE, arg);
}

/*---------------------------------------------------------------------------*/
void TVWarning(PIFilter *PiFilter, const char *warn)
{
	INTPTR   arg[1];

	arg[0]=(INTPTR)warn;
	PiFilter->CallBack( PiFilter, CB_WARNING, arg);
	return ;
}

/*---------------------------------------------------------------------------*/
int TVDemand(PIFilter *PiFilter, const char *s, const char *yes, const char *no)
{
	INTPTR   arg[8];

	arg[0]=(INTPTR)s;
	arg[1]=(INTPTR)yes;
	arg[2]=(INTPTR)no;
	return (int)PiFilter->CallBack( PiFilter, CB_DEMAND, arg);

}

/*---------------------------------------------------------------------------*/
int TVDemandInt(PIFilter *PiFilter, const char *s, int *val, int min, int max)
{
	INTPTR   arg[4];

	arg[0]=(INTPTR)s;
	arg[1]=(INTPTR)val;
	arg[2]=min;
	arg[3]=max;
	return (int)PiFilter->CallBack( PiFilter, CB_DEMANDINT, arg);
}

/*---------------------------------------------------------------------------*/
int TVDemandDouble(PIFilter *PiFilter, const char *iTitle, double *ioVal, double iMin, double iMax)
{
	INTPTR   arg[6];

	arg[0]=(INTPTR)iTitle;
	arg[1]=(INTPTR)ioVal;
	arg[2]=(INTPTR)&iMin;
	arg[3]=(INTPTR)&iMax;
	arg[4]=0;
	arg[5]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_DEMANDDOUBLE, arg);
}

/*---------------------------------------------------------------------------*/
int TVDemandText(PIFilter *PiFilter, const char *s, char *text, int max)
{
	INTPTR   arg[3];

	arg[0]=(INTPTR)s;
	arg[1]=(INTPTR)text;
	arg[2]=max;
	return (int)PiFilter->CallBack( PiFilter, CB_DEMANDTEXT, arg);

}

/*---------------------------------------------------------------------------*/
void TVUpdateDisplay(PIFilter *PiFilter, int x1, int y1, int x2 , int y2)
{
	INTPTR   arg[4];

	arg[0]=x1;
	arg[1]=y1;
	arg[2]=x2;
	arg[3]=y2;
	PiFilter->CallBack( PiFilter, CB_UPDATEDISPLAY, arg);


	return;
}

/*---------------------------------------------------------------------------*/
/* send George cmd,*/
/* error: return 0*/
/* result can be NULL */
/* return strlen result+1*/
int TVSendCmd(PIFilter *PiFilter, const char *cmd, char *result)
{
	INTPTR   arg[2];

	arg[0]=(INTPTR)cmd;
	arg[1]=(INTPTR)result;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDCMD, arg);

}

/*---------------------------------------------------------------------------*/
/* PIPixel *dest*/
/* source w,h*/
int	TVMakeBrush(PIFilter *PiFilter, const PIPixel *Brush, int width, int height)
{
	INTPTR   arg[8];

	arg[0]=(INTPTR)Brush;
	arg[1]=width;
	arg[2]=height;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;

	return (int)PiFilter->CallBack( PiFilter, CB_MAKEBRUSH, arg);

}

/*---------------------------------------------------------------------------*/
/* PIPixel *dest*/
/* source x,y*/
/* size w,h*/
/* pixels step mod*/
/* source:      		CB_READ_CURRENT current layer	*/
/*                      CB_READ_BRUSH 	brush			*/
/*                      CB_READ_DISPLAY display			*/
/*                      CB_READ_SPARE spare layer		*/
/*                      CB_READ_A layer A				*/
/*                      CB_READ_B layer B				*/
/*                      CB_READ_C layer C				*/
int TVReadLayerData(PIFilter *PiFilter, PIPixel *dest, int x,int y, int w, int h, int mod, int layer)
{
	INTPTR   arg[8];

	arg[0]=(INTPTR)dest;
	arg[1]=x;
	arg[2]=y;
	arg[3]=w;
	arg[4]=h;
	arg[5]=mod;
	arg[6]=layer;
	return (int)PiFilter->CallBack( PiFilter, CB_READLAYERDATA, arg);

}

/*---------------------------------------------------------------------------*/
int TVWriteLayerData(PIFilter *PiFilter, const PIPixel *source, int x,int y, int w, int h, int mod, int display)
{
	INTPTR	arg[7];


	arg[0]=(INTPTR)source;
	arg[1]=x;
	arg[2]=y;
	arg[3]=w;
	arg[4]=h;
	arg[5]=mod;
	arg[6]=display;
	return (int)PiFilter->CallBack( PiFilter, CB_WRITELAYERDATA, arg);
}

/*---------------------------------------------------------------------------*/
int TVWriteReqData(PIFilter *PiFilter, const PIPixel *source, int x,int y, int w, int h, int mod, INTPTR req)
{
	INTPTR	arg[16];

	arg[0]=(INTPTR)source;
	arg[1]=x;
	arg[2]=y;
	arg[3]=w;
	arg[4]=h;
	arg[5]=mod;
	arg[6]=req;
	return (int)PiFilter->CallBack( PiFilter, CB_WRITEREQDATA, arg);
}

/*---------------------------------------------------------------------------*/
int TVReadReqData(PIFilter *PiFilter, PIPixel *dest, int x,int y, int w, int h, int mod, INTPTR req)
{
	INTPTR	arg[16];

	arg[0]=(INTPTR)dest;
	arg[1]=x;
	arg[2]=y;
	arg[3]=w;
	arg[4]=h;
	arg[5]=mod;
	arg[6]=req;
	return (int)PiFilter->CallBack( PiFilter, CB_READREQDATA, arg);
}

/*---------------------------------------------------------------------------*/
int	TVExecute(PIFilter *PiFilter)
{
	INTPTR	arg[16];

	arg[0]=0;
	arg[1]=0;
	arg[2]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_EXECUTE	, arg);
}

/*---------------------------------------------------------------------------*/
int	TVInstallFunction(PIFilter *PiFilter, int function)
{
	INTPTR	arg[16];

	arg[0]=function;
	arg[1]=0;
	arg[2]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_OPENMETA, arg);
}

/*---------------------------------------------------------------------------*/
int	TVCloseFunction(PIFilter *PiFilter)
{
	INTPTR	arg[16];

	arg[0]=0;
	arg[1]=0;
	arg[2]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_CLOSEMETA, arg);
}

/*---------------------------------------------------------------------------*/
ULONG32 TVMakeRGBAPixel(PIFilter *PiFilter, int red, int green, int blue, int alpha)
{
PIPixel p;

    p.c[(int)(PiFilter->PlaneOffsetRed)]=red;
    p.c[(int)(PiFilter->PlaneOffsetGreen)]=green;
    p.c[(int)(PiFilter->PlaneOffsetBlue)]=blue;
    p.c[(int)(PiFilter->PlaneOffsetAlpha)]=alpha;

    return p.l;
}

/*---------------------------------------------------------------------------*/
int	TVPopup(PIFilter *PiFilter, PIPopup *Popup,  int num, int startnum)
{
	INTPTR	arg[16];

	arg[0]=(INTPTR)Popup;
	arg[1]=num;
	arg[2]=startnum;
	return (int)PiFilter->CallBack( PiFilter, CB_POPUP, arg);

}

/*---------------------------------------------------------------------------*/
int	TVGetButtonString(PIFilter *PiFilter, INTPTR req,  int id, TVCHAR *string, int maxchar)
{
	INTPTR   arg[16];

	arg[0]=PIRT_GET_BUTTON_STRING;
	arg[1]=req;
	arg[2]=id;
	arg[3]=(INTPTR)string;
	arg[4]=maxchar;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
int	TVPutButtonString(PIFilter *PiFilter, INTPTR req,  int id, const char *string)
{
	INTPTR   arg[16];

	arg[0]=PIRT_PUT_BUTTON_STRING;
	arg[1]=req;
	arg[2]=id;
	arg[3]=(INTPTR)string;
	arg[4]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
int	TVPutButtonStringUnit(PIFilter *PiFilter, INTPTR req,  int id, const char *unit)
{
	INTPTR   arg[16];

	arg[0]=PIRT_PUT_BUTTON_UNIT;
	arg[1]=req;
	arg[2]=id;
	arg[3]=(INTPTR)unit;
	arg[4]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
int	TVPutButtonImage(PIFilter *PiFilter, INTPTR req,  int id, PIBlock *Image, INTPTR flags)
{
	INTPTR   arg[16];

	arg[0]=PIRT_PUT_BUTTON_IMAGE;
	arg[1]=req;
	arg[2]=id;
	arg[3]=(INTPTR)Image;
	arg[4]=flags;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;
	arg[9]=0;
	arg[10]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
PIBlock* TVGetButtonImage(PIFilter *PiFilter, INTPTR req, int id, INTPTR flags)
{
	INTPTR   arg[16];

	arg[0]=PIRT_GET_BUTTON_IMAGE;
	arg[1]=req;
	arg[2]=id;
	arg[3]=flags;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;
	arg[9]=0;
	arg[10]=0;
	return (PIBlock*)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
int TVRefreshButtonImage(PIFilter *PiFilter, INTPTR req, int id, int x, int y, int w, int h)
{
	INTPTR   arg[16];

	arg[0]=PIRT_REFRESH_BUTTON_IMAGE;
	arg[1]=req;
	arg[2]=id;
	arg[3]=x;
	arg[4]=y;
	arg[5]=w;
	arg[6]=h;
	arg[7]=0;
	arg[8]=0;
	arg[9]=0;
	arg[10]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
int	TVWriteUserString(PIFilter *PiFilter, const char *section, const char *name, const char *string)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)section;
	arg[1]=(INTPTR)name;
	arg[2]=(INTPTR)string;
	arg[3]=0;
	arg[4]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_WRITE_USER_STRING, arg);
}

/*---------------------------------------------------------------------------*/
int	TVReadUserString(PIFilter *PiFilter, const char *section,
	const char *name, char *string, const char *def, int maxchar)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)section;
	arg[1]=(INTPTR)name;
	arg[2]=(INTPTR)string;
	arg[3]=(INTPTR)def;
	arg[4]=maxchar;
	return (int)PiFilter->CallBack( PiFilter, CB_READ_USER_STRING, arg);
}

/*---------------------------------------------------------------------------*/
int	TVEraseUserSection(PIFilter *PiFilter, const char *iSection)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)iSection;
	arg[1]=0;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_ERASE_USER_SECTION, arg);
}

/*---------------------------------------------------------------------------*/
int	TVWriteProjectString(PIFilter *PiFilter, const char *section, const char *name, const char *string)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)section;
	arg[1]=(INTPTR)name;
	arg[2]=(INTPTR)string;
	arg[3]=0;
	arg[4]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_WRITE_PROJECT_STRING, arg);
}

/*---------------------------------------------------------------------------*/
int	TVReadProjectString(PIFilter *PiFilter, const char *section,
	const char *name, char *string, const char *def, int maxchar)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)section;
	arg[1]=(INTPTR)name;
	arg[2]=(INTPTR)string;
	arg[3]=(INTPTR)def;
	arg[4]=maxchar;
	return (int)PiFilter->CallBack( PiFilter, CB_READ_PROJECT_STRING, arg);
}

/*---------------------------------------------------------------------------*/
int	TVEraseProjectSection(PIFilter *PiFilter, const char *iSection)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)iSection;
	arg[1]=0;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_ERASE_PROJECT_SECTION, arg);
}


/*---------------------------------------------------------------------------*/
/* destsize = PiFilter->ImageWidth*PiFilter->ImageHeight*sizeof(PIPixel) */
int TVMakeDisplayImage(PIFilter *PiFilter, PIPixel *dest, int destsize, int imagenum,  int background)
{
	INTPTR	arg[7];

	arg[0]=(INTPTR)dest;
	arg[1]=destsize;
	arg[2]=imagenum;
	arg[3]=background;
	arg[4]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_MAKE_IMAGE_DISPLAY, arg);
}

/*---------------------------------------------------------------------------*/
/* return: (imagewidth<<16) | (imageheight) */
/* if dest=NULL return image size */
int TVReadImage(PIFilter *PiFilter, const char *name, PIPixel *dest, int destwidth, int destheight)
{
	INTPTR	arg[8];

	arg[0]=(INTPTR)name;
	arg[1]=(INTPTR)dest;
	arg[2]=destwidth;
	arg[3]=destheight;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_READ_IMAGE, arg);
}

/*---------------------------------------------------------------------------*/
PIBlock *TVAllocPIBlock(PIFilter *PiFilter, int Width,  int Height, INTPTR Flags)
{
	INTPTR	arg[8];

	arg[0]=Width;
	arg[1]=Height;
	arg[2]=Flags;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (PIBlock *)PiFilter->CallBack( PiFilter, CB_ALLOC_PIBLOCK, arg);
}

/*---------------------------------------------------------------------------*/
void TVFreePIBlock(PIFilter *PiFilter, PIBlock *piblock)
{
	INTPTR	arg[8];

	arg[0]=(INTPTR)piblock;
	arg[1]=0;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	PiFilter->CallBack( PiFilter, CB_FREE_PIBLOCK, arg);
}

/*---------------------------------------------------------------------------*/
int TVAllocFileReq(PIFilter *PiFilter, PIFileReq *PiFileReq)
{
	INTPTR	arg[8];

	arg[0]=(INTPTR)PiFileReq;
	arg[1]=0;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_ALLOC_FILEREQ, arg);
}

/*---------------------------------------------------------------------------*/
void TVFreeFileReq(PIFilter *PiFilter, PIFileReq *PiFileReq)
{
	INTPTR	arg[8];

	arg[0]=(INTPTR)PiFileReq;
	arg[1]=0;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	PiFilter->CallBack( PiFilter, CB_FREE_FILEREQ, arg);
}

/*---------------------------------------------------------------------------*/
int TVOpenFileReq(PIFilter *PiFilter, PIFileReq *PiFileReq)
{
	INTPTR	arg[8];

	arg[0]=(INTPTR)PiFileReq;
	arg[1]=0;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_OPEN_FILEREQ, arg);
}

/*--------------------------------------------------------------------------*/
int	TVCreateFilterAlias(PIFilter *PiFilter, const char *alias, const char *params)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)alias;
	arg[1]=(INTPTR)params;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_CREATE_ALIAS, arg);
}

/*---------------------------------------------------------------------------*/
int	TVWrapPIBlock(PIFilter *PiFilter, const PIBlock *source, PIBlock *dest,
	double x1, double y1, double x2, double y2,
	double x3, double y3, double x4, double y4)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)source;
	arg[1]=(INTPTR)dest;
	arg[2]=(INTPTR)(x1*65536.);
	arg[3]=(INTPTR)(y1*65536.);
	arg[4]=(INTPTR)(x2*65536.);
	arg[5]=(INTPTR)(y2*65536.);
	arg[6]=(INTPTR)(x3*65536.);
	arg[7]=(INTPTR)(y3*65536.);
	arg[8]=(INTPTR)(x4*65536.);
	arg[9]=(INTPTR)(y4*65536.);
	arg[10]=0;
	arg[11]=0;
	arg[12]=0;
	arg[13]=0;
	arg[14]=0;
	arg[15]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_WRAP_BLOCK, arg);

}

/*---------------------------------------------------------------------------*/
int	TVWrapPIBlockMode(PIFilter *PiFilter, const PIBlock *source, PIBlock *dest,
	double x1, double y1, double x2, double y2,
	double x3, double y3, double x4, double y4, int iTile, int iMode)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)source;
	arg[1]=(INTPTR)dest;
	arg[2]=(INTPTR)(x1*65536.);
	arg[3]=(INTPTR)(y1*65536.);
	arg[4]=(INTPTR)(x2*65536.);
	arg[5]=(INTPTR)(y2*65536.);
	arg[6]=(INTPTR)(x3*65536.);
	arg[7]=(INTPTR)(y3*65536.);
	arg[8]=(INTPTR)(x4*65536.);
	arg[9]=(INTPTR)(y4*65536.);
	arg[10]=(INTPTR)iTile;
	arg[11]=(INTPTR)iMode;
	arg[12]=0;
	arg[13]=0;
	arg[14]=0;
	arg[15]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_WRAP_BLOCK, arg);

}



/*---------------------------------------------------------------------------*/
void *TVOpenStringFile(PIFilter *PiFilter, const char *filename, INTPTR flags)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)filename;
	arg[1]=(INTPTR)flags;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	return (void*)PiFilter->CallBack( PiFilter, CB_OPEN_STRING_FILE, arg);
}

/*---------------------------------------------------------------------------*/
int TVCloseStringFile(PIFilter *PiFilter, void *StringFile, INTPTR flags)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)StringFile;
	arg[1]=(INTPTR)flags;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_CLOSE_STRING_FILE, arg);
}

/*---------------------------------------------------------------------------*/
int TVWriteStringFile(PIFilter *PiFilter, void *StringFile, const char *section,
	const char *name, const char *string)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)StringFile;
	arg[1]=(INTPTR)section;
	arg[2]=(INTPTR)name;
	arg[3]=(INTPTR)string;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_WRITE_STRING_FILE, arg);
}

/*---------------------------------------------------------------------------*/
int TVReadStringFile(PIFilter *PiFilter, void *StringFile, const char *section,
	const char *line, char *string, const char *def, int maxchar)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)StringFile;
	arg[1]=(INTPTR)section;
	arg[2]=(INTPTR)line;
	arg[3]=(INTPTR)string;
	arg[4]=(INTPTR)def;
	arg[5]=(INTPTR)maxchar;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_READ_STRING_FILE, arg);
}

/*---------------------------------------------------------------------------*/
int TVEraseFileSection(PIFilter *PiFilter, void *iStringFile, const char *iSection); //MOUAIS: ca marche pas sans ca ?!?!?!?!?!?!?!
int TVEraseFileSection(PIFilter *PiFilter, void *iStringFile, const char *iSection)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)iStringFile;
	arg[1]=(INTPTR)iSection;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_ERASE_STRING_FILE_SECTION, arg);
}

/*---------------------------------------------------------------------------*/
int TVRunMultiThread(PIFilter *PiFilter, int (*fonc)(void *thread, int start, int end, void *param),
	int start, int end, void *param)
{
	INTPTR   arg[8];

	if((PiFilter->Version>5) ||
		(PiFilter->Version==5 && PiFilter->Revision>=1))
	{
		arg[0]=(INTPTR)fonc;
		arg[1]=(INTPTR)start;
		arg[2]=(INTPTR)end;
		arg[3]=(INTPTR)param;
		arg[4]=0;
		arg[5]=0;
		arg[6]=0;
		arg[7]=0;
		return (int)PiFilter->CallBack( PiFilter, CB_MULTITHREAD, arg);
	}
	else
	{
		return fonc(NULL, start, end, param);
	}

}

/*---------------------------------------------------------------------------*/
int TVAddDisplayDevice(PIFilter *PiFilter, PIDisplay *device, unsigned long flags)
{
	INTPTR   arg[8];

	arg[0]=(INTPTR)device;
	arg[1]=(INTPTR)flags;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_ADD_DISPLAYDEVICE, arg);

}

/*---------------------------------------------------------------------------*/
const char *TVEnumDisplayDevice(PIFilter *PiFilter, int num, unsigned long flags)
{
	INTPTR   arg[8];

	arg[0]=(INTPTR)num;
	arg[1]=flags;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (char*)PiFilter->CallBack( PiFilter, CB_ENUM_DISPLAYDEVICE, arg);

}

/*---------------------------------------------------------------------------*/
PIDisplay *TVLockDisplayDevice(PIFilter *PiFilter, const char *name, unsigned long mode)
{
	INTPTR   arg[8];

	arg[0]=(INTPTR)name;
	arg[1]=mode;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (PIDisplay*)PiFilter->CallBack( PiFilter, CB_LOCK_DISPLAYDEVICE, arg);
}

/*---------------------------------------------------------------------------*/
void TVUnlockDisplayDevice(PIFilter *PiFilter, PIDisplay *display)
{
	INTPTR   arg[8];

	arg[0]=(INTPTR)display;
	arg[1]=0;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	PiFilter->CallBack( PiFilter, CB_UNLOCK_DISPLAYDEVICE, arg);
}

/*---------------------------------------------------------------------------*/
int TVAddTabs(PIFilter *PiFilter, INTPTR req, int x, int y, int w,int h,
	int id, int num,  int current,  const char **names)
{
	INTPTR   arg[32];

	arg[0]=PIRT_ADD_TABS;
	arg[1]=req;
	arg[2]=x;
	arg[3]=y;
	arg[4]=w;
	arg[5]=h;
	arg[6]=id;
	arg[7]=num;
	arg[8]=current;
	arg[9]=(INTPTR)names;
	arg[10]=0;
	arg[11]=0;
	arg[12]=0;
	arg[13]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
int TVChangeTabs(PIFilter *PiFilter, INTPTR req, int id, int pos)
{
	INTPTR   arg[32];

	arg[0]=PIRT_CHANGE_TABS;
	arg[1]=req;
	arg[2]=id;
	arg[3]=pos;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
int TVCompassOpen(PIFilter *PiFilter, INTPTR req, int id, double val)
{
	INTPTR   arg[32];

	arg[0]=PIRT_COMPASS_OPEN;
	arg[1]=req;
	arg[2]=id;
	arg[3]=(long)(val*65536.);
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
void TVCompassChange(PIFilter *PiFilter, double val)
{
	INTPTR   arg[32];

	arg[0]=PIRT_COMPASS_CHANGE;
	arg[1]=(INTPTR)(val*65536.);
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
void TVCompassClose(PIFilter *PiFilter)
{
	INTPTR   arg[32];

	arg[0]=PIRT_COMPASS_CLOSE;
	arg[1]=0;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
int TVAddSliderReq(PIFilter *PiFilter, INTPTR req, int x, int y, int w,int h,
	int id, INTPTR flags,
	int MaxX, int NumX, int PosX,
	int MaxY, int NumY, int PosY)
{
	INTPTR   arg[32];

	arg[0]=PIRT_ADD_SLIDER;
	arg[1]=req;
	arg[2]=x;
	arg[3]=y;
	arg[4]=w;
	arg[5]=h;
	arg[6]=id;
	arg[7]=flags;
	arg[8]=MaxX;
	arg[9]=NumX;
	arg[10]=PosX;
	arg[11]=MaxY;
	arg[12]=NumY;
	arg[13]=PosY;
	arg[14]=0;
	arg[15]=0;
	arg[16]=0;
	arg[17]=0;
	arg[18]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
int TVChangeSliderReq(PIFilter *PiFilter, INTPTR req, int id,
	int MaxX, int NumX, int PosX,
	int MaxY, int NumY, int PosY)
{
	INTPTR   arg[16];

	arg[0]=PIRT_CHANGE_SLIDER;
	arg[1]=req;
	arg[2]=id;
	arg[3]=MaxX;
	arg[4]=NumX;
	arg[5]=PosX;
	arg[6]=MaxY;
	arg[7]=NumY;
	arg[8]=PosY;
	arg[9]=0;
	arg[10]=0;
	arg[11]=0;
	arg[12]=0;
	arg[13]=0;
	arg[14]=0;
	arg[15]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*---------------------------------------------------------------------------*/
int TVReadProjectImage(PIFilter *PiFilter, PIBlock *dest, int projectid, int layerid, int imagenum)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)dest;
	arg[1]=(INTPTR)projectid;
	arg[2]=(INTPTR)layerid;
	arg[3]=(INTPTR)imagenum;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_READ_PROJECT_IMAGE, arg);
}

/*---------------------------------------------------------------------------*/
int TVGetImageID(PIFilter *PiFilter, int iProjectID, int iLayerID, int iImagePosition, char* oImageID, char* oDataID)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)iProjectID;
	arg[1]=(INTPTR)iLayerID;
	arg[2]=(INTPTR)iImagePosition;
	arg[3]=(INTPTR)oImageID;
	arg[4]=(INTPTR)oDataID;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_GET_IMAGE_ID, arg);
}


/*---------------------------------------------------------------------------*/
void *TVOpenLocalFile(PIFilter *PiFilter, const char *name, unsigned long reserved)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)name;
	arg[1]=(INTPTR)reserved;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (void*)PiFilter->CallBack( PiFilter, CB_LOCAL_OPEN, arg);
}

/*---------------------------------------------------------------------------*/
void  TVCloseLocalFile(PIFilter *PiFilter, void *localfile)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)localfile;
	arg[1]=0;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	PiFilter->CallBack( PiFilter, CB_LOCAL_CLOSE, arg);
}

/*---------------------------------------------------------------------------*/
TVCHAR *TVGetLocalString(PIFilter *PiFilter, void *localfile, unsigned int line)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)localfile;
	arg[1]=(INTPTR)line;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (TVCHAR *)PiFilter->CallBack( PiFilter, CB_LOCAL_GET_STRING, arg);
}

/*---------------------------------------------------------------------------*/
int TVTextBlock(PIFilter *PiFilter, PIBlock *piblock, int x, int y, const char *text, ULONG32 iAPen)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)piblock;
	arg[1]=x;
	arg[2]=y;
	arg[3]=(INTPTR)text;
	arg[4]=iAPen;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_TEXT_TO_BLOCK, arg);
}

/*---------------------------------------------------------------------------*/
PIKeys *TVAllocKeys(PIFilter *PiFilter, const char *name, const char *nameid)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)name;
	arg[1]=(INTPTR)nameid;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (PIKeys *)PiFilter->CallBack( PiFilter, CB_ALLOC_KEYS, arg);
}

/*---------------------------------------------------------------------------*/
VideoDevice *TVEnumVideoDevice(PIFilter *PiFilter, int DevNum)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)DevNum;
	arg[1]=0;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	return (VideoDevice *)PiFilter->CallBack( PiFilter, CB_ENUM_VIDEODEVICE, arg);
}

/*---------------------------------------------------------------------------*/
void TVAddVideoDevice(PIFilter *PiFilter, VideoDevice *VDev)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)VDev;
	arg[1]=0;
	arg[2]=0;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	PiFilter->CallBack( PiFilter, CB_ADD_VIDEODEVICE, arg);
}

/*---------------------------------------------------------------------------*/
int	 TVAddVideoButton(PIFilter *PiFilter, INTPTR req, int x,int y,int w,int h,int id, VideoDevice *VDev, int VideoInput, int VideoMode)
{
	INTPTR   arg[16];

	arg[0]=PIRT_ADD_VIDEO_BUTTON;
	arg[1]=req;
	arg[2]=x;
	arg[3]=y;
	arg[4]=w;
	arg[5]=h;
	arg[6]=id;
	arg[7]=(INTPTR)VDev;
	arg[8]=VideoInput;
	arg[9]=VideoMode;
	return (int)PiFilter->CallBack( PiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
int	 TVBlockStretch(PIFilter *PiFilter, const PIBlock *src, PIBlock *dst)
{
	INTPTR   arg[16];

	arg[0]=PIBCMD_STRETCH;
	arg[1]=(INTPTR)src;
	arg[2]=(INTPTR)dst;
	arg[3]=0;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_BLOCK_CMD, arg);

}


/*--------------------------------------------------------------------------*/
void	TVHudRedraw(PIFilter *PiFilter)
{
	INTPTR   arg[16];

	arg[0]= PIHUDCMD_REDRAW;
	arg[1] = 0;
	arg[2] = 0;
	arg[3] = 0;
	arg[4] = 0;
	arg[5] = 0;
	arg[6] = 0;
	arg[7] = 0;

	PiFilter->CallBack( PiFilter, CB_HUD_CMD, arg);
}

/*--------------------------------------------------------------------------*/
void TVHudImage(PIFilter *PiFilter,  float iX, float iY, float iX1, float iY1, float iX2, float iY2, float iX3, float iY3, float iX4, float iY4, const PIBlock* iBlock)
{
	INTPTR   arg[16];

	arg[0] = PIHUDCMD_IMAGE;
	*(float*)&arg[1] = iX;
	*(float*)&arg[2] = iY;
	*(float*)&arg[3] = iX1;
	*(float*)&arg[4] = iY1;
	*(float*)&arg[5] = iX2;
	*(float*)&arg[6] = iY2;
	*(float*)&arg[7] = iX3;
	*(float*)&arg[8] = iY3;
	*(float*)&arg[9] = iX4;
	*(float*)&arg[10] = iY4;
	arg[11] = (INTPTR)iBlock;

	PiFilter->CallBack( PiFilter, CB_HUD_CMD, arg);
}
/*--------------------------------------------------------------------------*/
void TVHudLine(PIFilter *PiFilter, float iX1, float iY1, float iX2 , float iY2, PIPixel iColor)
{
	INTPTR   arg[16];

	arg[0] = PIHUDCMD_LINE;
	*(float*)&arg[1] = iX1;
	*(float*)&arg[2] = iY1;
	*(float*)&arg[3] = iX2;
	*(float*)&arg[4] = iY2;
	arg[5] = (INTPTR)iColor.l;
	arg[6] = 0;
	arg[7] = 0;

	PiFilter->CallBack( PiFilter, CB_HUD_CMD, arg);
}

/*--------------------------------------------------------------------------*/
void TVHudSpline(PIFilter *PiFilter,  float iX1, float iY1, float iX12, float iY12, float iX2, float iY2, PIPixel iColor)
{
	INTPTR   arg[16];

	arg[0] = PIHUDCMD_SPLINE;
	*(float*)&arg[1] = iX1;
	*(float*)&arg[2] = iY1;
	*(float*)&arg[3] = iX12;
	*(float*)&arg[4] = iY12;
	*(float*)&arg[5] = iX2;
	*(float*)&arg[6] = iY2;
	arg[7] = (INTPTR)iColor.l;
	arg[8] = 0;
	arg[9] = 0;

	PiFilter->CallBack( PiFilter, CB_HUD_CMD, arg);
}

/*--------------------------------------------------------------------------*/
void TVHudText(PIFilter *PiFilter,  float iX, float iY, const char* iText, int iAlign, PIPixel iColor, int iSelected)
{
	INTPTR   arg[16];

	arg[0] = PIHUDCMD_TEXT;
	*(float*)&arg[1] = iX;
	*(float*)&arg[2] = iY;
	arg[3] = (INTPTR)iText;
	arg[4] = (INTPTR)iAlign;
	arg[5] = (INTPTR)iColor.l;
	arg[6] = iSelected;
	arg[7] = 0;
	arg[8] = 0;

	PiFilter->CallBack( PiFilter, CB_HUD_CMD, arg);
}


void TVHudHandle(PIFilter *PiFilter, float iX, float iY, int iHandle, PIPixel iColor, int iSelected)
{
	INTPTR   arg[16];

	arg[0] = PIHUDCMD_HANDLE;
	*(float*)&arg[1] = iX;
	*(float*)&arg[2] = iY;
	arg[3] = (INTPTR)iHandle;
	arg[4] = (INTPTR)iColor.l;
	arg[5] = iSelected;
	arg[6] = 0;
	arg[7] = 0;
	arg[8] = 0;

	PiFilter->CallBack( PiFilter, CB_HUD_CMD, arg);
}

/*--------------------------------------------------------------------------*/
int	 TVBlockBlur(PIFilter *PiFilter, PIBlock *blk, double bx, double by, int MirrorBorder)
{
	INTPTR   arg[16];

	arg[0]=PIBCMD_BLUR;
	arg[1]=(INTPTR)blk;
	arg[2]=(INTPTR)(bx*65536);
	arg[3]=(INTPTR)(by*65536);
	arg[4]=MirrorBorder;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_BLOCK_CMD, arg);
}

/*--------------------------------------------------------------------------*/
PIFont *TVOpenPIFont(PIFilter *PiFilter, const char *iName, unsigned long iScript, unsigned long iStyle)
{
	INTPTR   arg[16];

	arg[0]=(INTPTR)iName;
	arg[1]=(INTPTR)iName;
	arg[2]=(INTPTR)iScript;
	arg[3]=(INTPTR)iStyle;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;
	return (PIFont*)PiFilter->CallBack( PiFilter, CB_OPEN_FONT, arg);
}

/*--------------------------------------------------------------------------*/
int	 TVRGBAToYUV(PIFilter* PiFilter, const PIPixel* iRGBA, unsigned char* oYUV, unsigned char* oAlpha, int iSize)
{
	INTPTR   arg[16];

	arg[0]=PIBCMD_RGBA_TO_YUV;
	arg[1]=(INTPTR)iRGBA;
	arg[2]=(INTPTR)oYUV;
	arg[3]=(INTPTR)oAlpha;
	arg[4]=iSize;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_PIXEL_CMD, arg);
}

/*--------------------------------------------------------------------------*/
int	 TVYUVToRGBA(PIFilter* PiFilter, const unsigned char* iYUV, const unsigned char* iAlpha, PIPixel* oRGBA, int iSize)
{
	INTPTR   arg[16];

	arg[0]=PIBCMD_YUV_TO_RGBA;
	arg[1]=(INTPTR)iYUV;
	arg[2]=(INTPTR)iAlpha;
	arg[3]=(INTPTR)oRGBA;
	arg[4]=iSize;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_PIXEL_CMD, arg);
}

/*--------------------------------------------------------------------------*/
int	 TVRGBAUnmultiply(PIFilter* PiFilter, const PIPixel* iRGBA, PIPixel* oRGBA, int iSize)
{
	INTPTR   arg[16];

	arg[0]=PIBCMD_RGBA_UNMULTIPLY;
	arg[1]=(INTPTR)iRGBA;
	arg[2]=(INTPTR)oRGBA;
	arg[3]=iSize;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_PIXEL_CMD, arg);
}

/*--------------------------------------------------------------------------*/
int	 TVRGBAPremultiply(PIFilter* PiFilter, const PIPixel* iRGBA, PIPixel* oRGBA, int iSize)
{
	INTPTR   arg[16];

	arg[0]=PIBCMD_RGBA_PREMULTIPLY;
	arg[1]=(INTPTR)iRGBA;
	arg[2]=(INTPTR)oRGBA;
	arg[3]=iSize;
	arg[4]=0;
	arg[5]=0;
	arg[6]=0;
	arg[7]=0;
	arg[8]=0;
	return (int)PiFilter->CallBack( PiFilter, CB_PIXEL_CMD, arg);
}

/*--------------------------------------------------------------------------*/
int	TVDDBlit(PIFilter *PiFilter, INTPTR *iReq, int iButtonID,
			 int iDst_X, int iDst_Y, int iDst_Width, int iDst_Height,
			 DDSurf *iSrc,
			 int iSrc_X, int iSrc_Y, int iSrc_Width, int iSrc_Height)
{
	INTPTR   arg[16];

	arg[0] = (INTPTR)iReq;
	arg[1] = (INTPTR)iButtonID;
	arg[2] = (INTPTR)iDst_X;
	arg[3] = (INTPTR)iDst_Y;
	arg[4] = (INTPTR)iDst_Width;
	arg[5] = (INTPTR)iDst_Height;
	arg[6] = (INTPTR)iSrc;
	arg[7] = (INTPTR)iSrc_X;
	arg[8] = (INTPTR)iSrc_Y;
	arg[9] = (INTPTR)iSrc_Width;
	arg[10] = (INTPTR)iSrc_Height;

	return (int)PiFilter->CallBack( PiFilter, CB_DDBLIT, arg);

}



/*--------------------------------------------------------------------------*/
void	TVPreviewLine(PIFilter *PiFilter, double iX1, double iY1, double iX2 , double iY2, int iMode)
{
	INTPTR   arg[16];

	arg[0] = (INTPTR)(iX1*65536);
	arg[1] = (INTPTR)(iY1*65536);
	arg[2] = (INTPTR)(iX2*65536);
	arg[3] = (INTPTR)(iY2*65536);
	arg[4] = (INTPTR)iMode;
	arg[5] = 0;
	arg[6] = 0;
	arg[7] = 0;
	arg[8] = 0;

	PiFilter->CallBack( PiFilter, CB_PREVIEW_LINE, arg);
}

/*--------------------------------------------------------------------------*/
void	TVPreviewText(PIFilter *iPiFilter, double iX, double iY, const char* iText, int iMode)
{
	INTPTR   arg[16];

	arg[0] = (INTPTR)(iX*65536);
	arg[1] = (INTPTR)(iY*65536);
	arg[2] = (INTPTR)iText;
	arg[3] = (INTPTR)iMode;
	arg[4] = 0;
	arg[5] = 0;
	arg[6] = 0;
	arg[7] = 0;
	arg[8] = 0;

	iPiFilter->CallBack( iPiFilter, CB_PREVIEW_TEXT, arg);
}

/*--------------------------------------------------------------------------*/
void	TVPreviewHandle(PIFilter *iPiFilter, double iX, double iY, double iSize ,int iMode)
{
	INTPTR   arg[16];

	arg[0] = (INTPTR)(iX*65536);
	arg[1] = (INTPTR)(iY*65536);
	arg[2] = (INTPTR)(iSize*65536);
	arg[3] = (INTPTR)iMode;
	arg[4] = 0;
	arg[5] = 0;
	arg[6] = 0;
	arg[7] = 0;
	arg[8] = 0;

	iPiFilter->CallBack( iPiFilter, CB_PREVIEW_HANDLE, arg);
}

/*--------------------------------------------------------------------------*/
PIImageSequence* TVOpenImageSequence(PIFilter* iPiFilter, const char* iFileName, int iFlags)
{
	INTPTR   arg[16];

	arg[0] = (INTPTR)(iFileName);
	arg[1] = (INTPTR)(iFlags);
	arg[2] = 0;
	arg[3] = 0;
	arg[4] = 0;
	arg[5] = 0;
	arg[6] = 0;
	arg[7] = 0;

	return (PIImageSequence*)iPiFilter->CallBack( iPiFilter, CB_OPEN_IMAGESEQUENCE, arg);
}
/*--------------------------------------------------------------------------*/
PIProfile* TVAllocProfile(PIFilter* iPiFilter, const char* iName, int iFlags)
{
	INTPTR   arg[16];

	arg[0] = (INTPTR)(iName);
	arg[1] = iFlags;
	arg[2] = 0;
	arg[3] = 0;
	arg[4] = 0;
	arg[5] = 0;
	arg[6] = 0;
	arg[7] = 0;

	return (PIProfile*)iPiFilter->CallBack( iPiFilter, CB_ALLOC_PROFILE, arg);
}


/*--------------------------------------------------------------------------*/
int TVPickColor(PIFilter *iPiFilter, PIPixel* oResult )
{
	INTPTR   arg[16];

	arg[0] = (INTPTR)oResult;
	arg[1] = 0;
	arg[2] = 0;
	arg[3] = 0;
	arg[4] = 0;
	arg[5] = 0;
	arg[6] = 0;
	arg[7] = 0;

	return (int)iPiFilter->CallBack( iPiFilter, CB_PICK_COLOR, arg);
}


/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
void TVSaveReqState(PIFilter *iPiFilter, INTPTR iReq, const char *iSection, const char *iSubSection)
{
	INTPTR   arg[16];

	arg[0] = PIRT_SAVE_REQ_STATE;
	arg[1] = iReq;
	arg[2] = (INTPTR)iSection;
	arg[3] = (INTPTR)iSubSection;
	arg[4] = 0;
	arg[5] = 0;

	iPiFilter->CallBack( iPiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
void TVLoadReqState(PIFilter *iPiFilter, INTPTR iReq, const char *iSection, const char *iSubSection)
{
	INTPTR   arg[16];

	arg[0] = PIRT_LOAD_REQ_STATE;
	arg[1] = iReq;
	arg[2] = (INTPTR)iSection;
	arg[3] = (INTPTR)iSubSection;
	arg[4] = 0;
	arg[5] = 0;

	iPiFilter->CallBack( iPiFilter, CB_SENDREQCMD, arg);
}

/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
int TVDisplayReq(PIFilter *iPiFilter, INTPTR iReq, int iDisplay)
{
	INTPTR   arg[16];

	arg[0] = PIRT_DISPLAY_REQ;
	arg[1] = iReq;
	arg[2] = (INTPTR)iDisplay;
	arg[3] = 0;
	arg[4] = 0;
	arg[5] = 0;

	return (int)iPiFilter->CallBack( iPiFilter, CB_SENDREQCMD, arg);
}

