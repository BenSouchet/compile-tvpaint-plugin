#include        <ctype.h>
#include        <time.h>
#include        <stdio.h>
#include        <stdlib.h>
#include        <string.h>
#include        <fcntl.h>
#include        <limits.h>
#include        <conio.h>

#include        <windows.h>
#include        <ddeml.h>

/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/

/*
                        The DDE variables
*/

static  DWORD		idInst = 0L;            //  Instance of app for DDEML
static  HSZ			hszService=0;
static  HSZ			hszTopic=0;
static  HCONV		hConv = NULL;           //	Handle of established conversation

static  HINSTANCE	hInst;

static  char		*result=0;

static  HDDEDATA	EXPENTRY        DDECallback (	WORD wType, WORD wFmt, HCONV hConvX, HSZ hsz1,
													HSZ hsz2, HDDEDATA hData, DWORD dwData1,
													DWORD dwData2 );

/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/

void    Warn(char *w)
{
	MessageBox(0,w,"WARNING",MB_OK+MB_SYSTEMMODAL+MB_ICONEXCLAMATION);
}

/*****************************************************************************/
/************ Connection managment with Aura *********************************/
/*****************************************************************************/

void    FreeHConv(void)
{
    if(hConv)DdeDisconnect(hConv);
     hConv=0;

	DdeUninitialize(idInst);
}

int     DoConnect(char *server, char *topic)
{

	FreeHConv();

    if ( DdeInitialize( (LPDWORD)&idInst, (PFNCALLBACK)DDECallback, APPCMD_CLIENTONLY, 0L) != DMLERR_NO_ERROR )
    {
    	return 0;
    }

	hszService = DdeCreateStringHandle(idInst, server, CP_WINANSI);
    hszTopic   = DdeCreateStringHandle(idInst, topic, CP_WINANSI);

    hConv = DdeConnect( idInst, hszService, hszTopic, (PCONVCONTEXT)NULL );

	DdeFreeStringHandle(idInst, hszService);
	DdeFreeStringHandle(idInst, hszTopic);


	if(hConv)
	{
		return 1;
	}
	else
    {
		FreeHConv();
		return 0;
	}
}
static  HDDEDATA EXPENTRY DDECallback ( WORD wType, WORD wFmt, HCONV hConvX, HSZ hsz1,
									  HSZ hsz2, HDDEDATA hData, DWORD dwData1, DWORD dwData2 )
{
    hConvX=hConvX;
    wFmt=wFmt;
    hsz1=hsz1;
    hsz2=hsz2;
    dwData1=dwData1;
    dwData2=dwData2;
    hData=hData;

    switch ( wType )
    {
        case XTYP_DISCONNECT:
            FreeHConv();
            return (HDDEDATA) NULL;

		case XTYP_ERROR:
			break;

        case XTYP_XACT_COMPLETE:
			// compare transaction identifier, indicate transaction complete
			break;
    }

    return (HDDEDATA) NULL;
}
/*****************************************************************************/
/*****************************************************************************/

static void     RemoveBraket(char far *s, char *d)
{
int	braket=0;

	while(isspace(*s))*d++=*s++;
	if(*s=='[')
	{
        braket++;
        s++;
        while(braket && *s)
        {
			if(*s=='[')braket++;
			if(*s==']')braket--;
			if(braket)*d++=*s++;
		}
		*d=0;
	}
	else
    {
		while(*s)*d++=*s++;
		*d=0;
    }
}

/*****************************************************************************/
/*****************************************************************************/

int     ExecuteDde(char *msg)
{
HSZ				msgz;
BYTE far        *cres;
DWORD           csize;
int             ret=0;
HDDEDATA        res;


	if(!hConv)
    {
        Warn("No DDE connexion");
        return 1;
    }

    if(*msg==0)return 0;

	msgz = DdeCreateStringHandle(idInst, msg, CP_WINANSI);

    if(!msgz)
    {
		char temp[2048];
		sprintf(temp,"DdeCreateStringHandle fail %d",strlen(msg));
		Warn(temp);
		return 1;
    }
                                                                    
	res=DdeClientTransaction(NULL,0,hConv,msgz,CF_TEXT,XTYP_REQUEST,/* 2 min */120000,NULL);

    if(!res)
    {
        char *temp=(char*)malloc(strlen(msg)+256);
        if(temp)
        {
            strcpy(temp,msg);
            strcat(temp,"\n");
            strcat(temp,"DDE connexion error !");
            Warn(temp);
            free(temp);
        }
        return 1; // DdeGetLastError(idInst);
    }
    else
    if((int)res == 1)
    {
        char *temp=(char*)malloc(strlen(msg)+256);
        if(temp)
        {
            strcpy(temp,msg);
            strcat(temp,"\n");
            strcat(temp,"Unknown command !");
            Warn(temp);
            free(temp);
        }
		DdeFreeStringHandle(idInst, msgz);
		return 1;
    }
    else
    {
        cres=DdeAccessData(res,&csize);

        if(cres)
        {
            if (result) free(result);

            if (cres[0]=='B' &&
                cres[1]=='R' &&
                cres[2]=='E' &&
                cres[3]=='A' &&
                cres[4]=='K' &&
                cres[5]==0 )
            {
                Warn("User break!");
                ret=1;
            }
            else
            {
                result=(char*)malloc(strlen(cres)+1);

                if(result)
				{
                    RemoveBraket(cres,result);
                    ret=0;
                }
            }
            DdeUnaccessData(res);
		}
		DdeFreeDataHandle(res);
		DdeFreeStringHandle(idInst, msgz);
	}
	return ret;

}

/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/

void EndDde(void)
{
    if (result) free(result);
    result=0;
    FreeHConv();
}

/****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/

static int random(unsigned int v)
{
	return rand()%v;
}

static long h[69][69];
static const int rdiv[]={63,31,15,7,3,1,0};

void Fractal(void)
{
int	sw,aw,a2;
int	l;
int	xz,yz,yg;

	h[0][0]=0;
    h[0][64]=0;
    h[64][0]=0;

    sw=32;aw=64;a2=32;
    for(l=1;l<=6;l++)
    {
        yz=0;yg=0;

        do
        {
            if(yg++%2==0)
            {
                xz=sw;
                do{
					h[xz][yz]=(h[xz-a2][yz]+h[xz+a2][yz])/2+((random(65530)&rdiv[l-1])-(rdiv[l]));
					xz+=aw;
                }while (xz<64-yz);

            }
			else
			{
                xz=0;
                do{
                    h[xz][yz]=(h[xz][yz-a2]+h[xz][yz+a2])/2+((random(65530)&rdiv[l-1])-(rdiv[l]));
					xz+=a2;
                    h[xz][yz]=(h[xz-a2][yz+a2]+h[xz+a2][yz-a2])/2+((random(65530)&rdiv[l-1])-(rdiv[l]));
					xz+=a2;
				}while (xz<=64-yz);
			}
			yz+=a2;
        }while (yz<64);

        aw/=2;
        a2/=2;
        sw/=2;
    }
}


static void GetColor(int *r,int *g,int *b,int y)
{
	if(y<16)
    {
		*r=255-y*8;
		*g=220;
		*b=200-y*8;
    }
	else
    {
		*r=y*2;
        *g=255;
        *b=y*2;
    }
}



#define BUFSIZE 254

static  char cmdbuf[BUFSIZE+256];
static int cmdsize=0;

static int AddCmd(char *cmd)
{
int l=strlen(cmdbuf)+2;
int r=0;

	if(l+cmdsize>=BUFSIZE)
	{
		cmdsize	= 0;
		r=ExecuteDde(cmdbuf);
		cmdbuf[0]='\0';
	}

	strcat(cmdbuf,"[");
	strcat(cmdbuf,cmd);
	strcat(cmdbuf,"]");

	cmdsize += l;


	return r;
}


static int FlushCmd(void)
{
int r=0;
	if(cmdsize)
	{
		cmdsize	= 0;
		r=ExecuteDde(cmdbuf);
		cmdbuf[0]='\0';
	}
	return r;

}

#define HEIGHT  2

void Draw_Fractal(void)
{
    int x,y;
    int     point[8];
    char    command[2048];
    int r,g,b;
    int     yy,yy1,yy2,yy3,yy4;
    long    d;
    int     stop=0;

	stop = AddCmd("tv_LockUser");
    
    for(y=0;y<64 && !stop;y++)
    {
        for(x=0;x<64-y && !stop;x++)
        {
            point[0]=x*10+y*5;
            point[1]=y*4+60;
            yy1=h[x][y]*HEIGHT;
            if(yy1>0)
            {
				point[1]-=yy1;
            }
            point[2]=point[0]+10;
            point[3]=y*4+60;
            yy2=h[x+1][y]*HEIGHT;
            if(yy2>0)
            {
				point[3]-=yy2;
            }
            point[4]=point[0]+5;
            point[5]=y*4+64;
            yy3=h[x][y+1]*HEIGHT;
            if(yy3>0)
            {
				point[5]-=yy3;
            }

            point[6]=point[4]+10;
            point[7]=y*4+64;
            yy4=h[x+1][y+1]*HEIGHT;
            if(yy4>0)
            {
				point[7]-=yy4;
           	}
            yy=yy1+yy2+yy3;
            if(yy<0)
            {
                d=255+yy*8;
                r=d;
                g=d;
                b=255-(d<0 ? -d/3 : 0);
            }
            else
            {

				GetColor(&r,&g,&b,yy);
                d=((yy2-yy1)-(yy3-yy1))*16 + 128;
                r=(long)r*d/255L;
                g=(long)g*d/255L;
                b=(long)b*d/255L;
            }

			sprintf(command,"tv_SetAPen %d %d %d",r,g,b);
			stop = AddCmd(command);
			if(stop)break;

			stop = AddCmd("tv_AreaInit");
            sprintf(command,"tv_AreaMove %d %d",point[0],point[1]);
			stop = AddCmd(command);

            sprintf(command,"tv_AreaMove %d %d",point[2],point[3]);
			stop = AddCmd(command);

            sprintf(command,"tv_AreaMove %d %d",point[4],point[5]);
			stop = AddCmd(command);

			stop = AddCmd("tv_AreaDraw");
			if(stop)break;

			if(x<63-y && !stop)
            {
                yy=yy2+yy3+yy4;
                if(yy<0)
                {
                    d=255+yy*8;
                    r=d;
                    g=d;
                    b=255-(d<0 ? -d/3 : 0);
                }
                else
                {
                    GetColor(&r,&g,&b,yy);
                    d=((yy2-yy1)-(yy3-yy1))*16 + 128;
                    r=(long)r*d/255L;
                    g=(long)g*d/255L;
                    b=(long)b*d/255L;
                }
                sprintf(command,"tv_SetAPen %d %d %d",r,g,b);
				stop = AddCmd(command);

				stop = AddCmd("tv_AreaInit");

                sprintf(command,"tv_AreaMove %d %d",point[2],point[3]);
				stop = AddCmd(command);

                sprintf(command,"tv_AreaMove %d %d",point[4],point[5]);
				stop = AddCmd(command);

                sprintf(command,"tv_AreaMove %d %d",point[6],point[7]);
				stop = AddCmd(command);

				stop=AddCmd("tv_AreaDraw");
				if(stop)break;
			}

		}
    }

	stop = AddCmd("tv_UnlockUser");
	
	
	if(!stop)FlushCmd();

}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
time_t	t;

	if (hPrevInstance) return 0;

    hInst=hInstance;

    lpCmdLine=lpCmdLine;
    nCmdShow=nCmdShow;

    srand(time(&t));

	if (!DoConnect("TVPaint","Commands"))
	{
    	Warn("Cannot connect to TVPaint");
        return 0;
    }

	Fractal();
    Draw_Fractal();

    EndDde();

    return  0; 
}
